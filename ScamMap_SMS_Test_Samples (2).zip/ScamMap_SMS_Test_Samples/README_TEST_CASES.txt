SCAMMAP – SYNTHETIC SMS EVIDENCE TEST CASES

All messages and numbers in this pack are fictional test data.
Do not call, message, or visit any number or URL shown in the samples.
The .test domain is reserved for testing and is not a real public website.

1. MATCHED – sender and text match
   Reported phone number: +91 9000012345
   Pasted SMS text: Your bank account will be blocked today. Verify KYC immediately at http://bank-kyc-example.test to avoid suspension.
   Upload screenshot: 01_matched_otp_scam.png
   Expected evidence result: MATCHED (assuming OCR extracts the sender and text correctly)

2. MISMATCHED – sender number differs
   Reported phone number: +91 9000012345
   Pasted SMS text: Your bank account will be blocked today. Verify KYC immediately at http://bank-kyc-example.test to avoid suspension.
   Upload screenshot: 02_mismatched_sender.png
   Expected evidence result: MISMATCHED – screenshot sender does not match reported number

3. MISMATCHED – message text differs
   Reported phone number: +91 9000012345
   Pasted SMS text: Your bank account will be blocked today. Verify KYC immediately at http://bank-kyc-example.test to avoid suspension.
   Upload screenshot: 03_mismatched_message.png
   Expected evidence result: MISMATCHED – screenshot SMS text does not match submitted message

4. MATCHED – payment request example
   Reported phone number: +91 9123456780
   Pasted SMS text: UPI payment failed. To receive your refund, call our support team on 9123456780 and share the transaction reference.
   Upload screenshot: 04_matched_payment_scam.png
   Expected evidence result: MATCHED (assuming OCR extracts the sender and text correctly)

TESTING NOTES
- Submit each report with the exact reported phone number and pasted SMS text above.
- Upload the corresponding PNG screenshot.
- The expected result assumes OCR can read the screenshot accurately.
- A mismatch should affect public verification/scoring as designed; retain the underlying report for audit.
- These samples test consistency between the report and screenshot. They do not prove that a message is genuinely fraudulent.