"""Train an auxiliary screenshot/report consistency model from the 36 synthetic samples.
Run: python scripts/train_report_match_model.py
This model is advisory only; deterministic OCR checks remain authoritative.
"""
from pathlib import Path
import json
import joblib
import pandas as pd
from difflib import SequenceMatcher
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data/ml/report_match_dataset/manifest.csv"
OUT = ROOT / "app/models/report_match_classifier.joblib"

def pair_text(row):
    submitted = str(row.submitted_message_text).lower()
    ocr = str(row.ocr_expected_message_text).lower()
    target = re.sub(r"\D", "", str(row.reported_target_number))
    sender = re.sub(r"\D", "", str(row.screenshot_sender_number))
    similarity = SequenceMatcher(None, re.sub(r"\W+", "", submitted),
                                 re.sub(r"\W+", "", ocr)).ratio()
    return (" [TEXT_SIMILARITY] " + f"{similarity:.3f}" +
            " [TEXT_MATCH_FLAG] " + str(similarity >= 0.68) +
            " [SENDER_MATCH_FLAG] " + str(bool(target and target == sender)) +
            " [SUBMITTED] " + submitted +
            " [SCREENSHOT OCR] " + ocr +
            " [REPORTED TARGET] " + target +
            " [VISIBLE SENDER] " + sender)

def main():
    df = pd.read_csv(DATA, dtype=str).fillna("")
    required = {"submitted_message_text", "ocr_expected_message_text",
                "reported_target_number", "screenshot_sender_number",
                "expected_sender_text_result"}
    if len(df) != 36 or not required.issubset(df.columns):
        raise ValueError("Expected the 36-row ScamMap scenario manifest")
    # Keep exact duplicate screenshot uploads as a single evidence sample for training.
    df = df.drop_duplicates(subset=["sha256_file_hash"], keep="first")
    df = df[df.expected_sender_text_result.isin(["MATCHED", "MESSAGE_MISMATCH", "SENDER_MISMATCH"])]
    df["label"] = df.expected_sender_text_result.map(
        {"MATCHED": "MATCH_CANDIDATE", "MESSAGE_MISMATCH": "MISMATCH_CANDIDATE",
         "SENDER_MISMATCH": "MISMATCH_CANDIDATE"})
    X = df.apply(pair_text, axis=1)
    y = df["label"]
    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5),
                                  sublinear_tf=True, max_features=12000)),
        ("classifier", LogisticRegression(max_iter=2000, class_weight="balanced",
                                          random_state=42))
    ])
    cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    scores = cross_val_score(pipeline, X, y, cv=cv, scoring="accuracy")
    pipeline.fit(X, y)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, OUT)
    metrics = {
        "training_rows_after_exact_duplicate_deduplication": int(len(df)),
        "class_counts": {str(k): int(v) for k, v in y.value_counts().items()},
        "three_fold_cv_accuracy_mean": round(float(scores.mean()), 4),
        "fold_scores": [round(float(v), 4) for v in scores],
        "dataset": "36 synthetic screenshot/report scenarios",
        "warning": "Synthetic hackathon test data only. Not validated for real-world fraud or authenticity. Advisory only; never overrides deterministic evidence checks."
    }
    (OUT.parent / "report_match_training_metrics.json").write_text(
        json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))

if __name__ == "__main__":
    main()
