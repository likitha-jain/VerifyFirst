"""Generate a fresh Ed25519 ScamMap licence keypair.

Run from the ScamMap project root:
    python scripts/generate_license_keys.py

The private key is written to secrets/license_private_key.pem and must remain
offline/secret. The public key is printed as base64 for SCAMMAP_PUBLIC_KEY.
"""
from __future__ import annotations

import base64
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

ROOT = Path(__file__).resolve().parents[1]
PRIVATE_DIR = ROOT / "secrets"
PRIVATE_PATH = PRIVATE_DIR / "license_private_key.pem"
PUBLIC_PATH = PRIVATE_DIR / "license_public_key.txt"


def main() -> None:
    PRIVATE_DIR.mkdir(parents=True, exist_ok=True)
    if PRIVATE_PATH.exists() or PUBLIC_PATH.exists():
        raise SystemExit(
            "Key file already exists. Back it up securely and move/delete both files "
            "before generating a replacement. Never overwrite a production key by accident."
        )

    private_key = ed25519.Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_raw = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    public_b64 = base64.b64encode(public_raw).decode("ascii")

    PRIVATE_PATH.write_bytes(private_pem)
    try:
        PRIVATE_PATH.chmod(0o600)
    except OSError:
        pass
    PUBLIC_PATH.write_text(public_b64 + "\n", encoding="utf-8")

    print("Generated a new Ed25519 licence keypair.")
    print(f"PRIVATE KEY (keep secret): {PRIVATE_PATH}")
    print(f"PUBLIC KEY (safe to configure on app server): {PUBLIC_PATH}")
    print("\nAdd this line to your .env:")
    print(f"SCAMMAP_PUBLIC_KEY={public_b64}")
    print("\nDo not upload, email, commit, or deploy the private key with the public app.")


if __name__ == "__main__":
    main()
