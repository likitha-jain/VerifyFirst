"""Sign a ScamMap licence using an offline Ed25519 private key.

Example:
    python scripts/issue_license.py --licensee "Hackathon Demo" --days 30 --output data/license.json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from app.license import sign_license, to_ist_iso
import time
from datetime import datetime, timedelta, timezone


def main() -> None:
    parser = argparse.ArgumentParser(description="Issue a signed ScamMap licence")
    parser.add_argument("--private-key", default="secrets/license_private_key.pem")
    parser.add_argument("--licensee", default="ScamMap Demo")
    parser.add_argument("--days", type=int, default=30)
    parser.add_argument("--output", default="data/license.json")
    args = parser.parse_args()
    if args.days < 1:
        parser.error("--days must be at least 1")

    key_path = Path(args.private_key)
    if not key_path.is_file():
        raise SystemExit(f"Private key not found: {key_path}")
    key = serialization.load_pem_private_key(key_path.read_bytes(), password=None)
    if not isinstance(key, ed25519.Ed25519PrivateKey):
        raise SystemExit("The supplied key is not an Ed25519 private key")

    expiry = datetime.now(timezone.utc) + timedelta(days=args.days)
    licence = sign_license(key, args.licensee, to_ist_iso(expiry))
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(licence, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Signed licence saved to: {output}")
    print(f"Licensee: {args.licensee}")
    print(f"Expires: {licence['expires_at']}")
    print("Copy this licence to the app server's configured SCAMMAP_LICENSE_FILE path.")


if __name__ == "__main__":
    main()
