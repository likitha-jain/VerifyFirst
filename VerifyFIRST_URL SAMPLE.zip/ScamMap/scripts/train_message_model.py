"""Train the prototype text classifier. Run: python scripts/train_message_model.py"""
from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"data/ml/ScamMap_Messaging_Test_Dataset_50.csv"
OUT=ROOT/"app/models"
def main():
 df=pd.read_csv(DATA,dtype=str).fillna("")
 if len(df)!=50 or not {"message_text","ground_truth"}.issubset(df.columns): raise ValueError("Expected unchanged 50-row dataset and required columns")
 X=df.message_text.astype(str); y=df.ground_truth.astype(str)
 features=FeatureUnion([("word",TfidfVectorizer(ngram_range=(1,2),sublinear_tf=True,max_features=5000)),("char",TfidfVectorizer(analyzer="char_wb",ngram_range=(3,5),sublinear_tf=True,max_features=8000))])
 model=Pipeline([("features",features),("classifier",LogisticRegression(max_iter=1500,class_weight="balanced",random_state=42))])
 cv=StratifiedKFold(n_splits=5,shuffle=True,random_state=42); scores=cross_val_score(model,X,y,cv=cv,scoring="accuracy")
 model.fit(X,y); OUT.mkdir(parents=True,exist_ok=True); joblib.dump(model,OUT/"message_classifier.joblib")
 metrics={"records":len(df),"class_counts":{str(k):int(v) for k,v in y.value_counts().items()},"five_fold_cv_accuracy_mean":round(float(scores.mean()),4),"fold_scores":[round(float(v),4) for v in scores],"warning":"Synthetic 50-row prototype only; not validated for real-world scam detection."}
 (OUT/"training_metrics.json").write_text(json.dumps(metrics,indent=2),encoding="utf-8"); print(json.dumps(metrics,indent=2))
if __name__=="__main__": main()
