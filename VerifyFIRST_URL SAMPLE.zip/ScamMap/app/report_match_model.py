"""Advisory-only screenshot/report text-pair model."""
from pathlib import Path
from difflib import SequenceMatcher
import re
import joblib

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "app/models/report_match_classifier.joblib"

def _pair_text(submitted_text: str, ocr_text: str,
               reported_target: str, visible_sender: str) -> str:
    submitted = str(submitted_text or "").lower()
    ocr = str(ocr_text or "").lower()
    target = re.sub(r"\D", "", str(reported_target or ""))
    sender = re.sub(r"\D", "", str(visible_sender or ""))
    similarity = SequenceMatcher(None, re.sub(r"\W+", "", submitted),
                                  re.sub(r"\W+", "", ocr)).ratio()
    return (" [TEXT_SIMILARITY] " + f"{similarity:.3f}" +
            " [TEXT_MATCH_FLAG] " + str(similarity >= 0.68) +
            " [SENDER_MATCH_FLAG] " + str(bool(target and target == sender)) +
            " [SUBMITTED] " + submitted +
            " [SCREENSHOT OCR] " + ocr +
            " [REPORTED TARGET] " + target +
            " [VISIBLE SENDER] " + sender)

def assess_report_match(submitted_text: str, ocr_text: str,
                        reported_target: str = "", visible_sender: str = "") -> dict:
    if not MODEL_PATH.exists():
        return {"available": False, "assessment": "NOT_RUN",
                "message": "Auxiliary model is not trained."}
    try:
        model = joblib.load(MODEL_PATH)
        probabilities = model.predict_proba([_pair_text(
            submitted_text, ocr_text, reported_target, visible_sender
        )])[0]
        labels = model.classes_
        idx = int(probabilities.argmax())
        model_label = str(labels[idx])
        submitted = re.sub(r"\\W+", "", str(submitted_text or "").lower())
        ocr = re.sub(r"\\W+", "", str(ocr_text or "").lower())
        text_similarity = SequenceMatcher(None, submitted, ocr).ratio() if submitted and ocr else 0.0
        target_digits = re.sub(r"\\D", "", str(reported_target or ""))
        sender_digits = re.sub(r"\\D", "", str(visible_sender or ""))
        sender_conflict = bool(target_digits and sender_digits and target_digits not in sender_digits)
        # Conservative guard: obvious text/sender contradictions are surfaced even
        # if the small synthetic ML model is overconfident on an unfamiliar example.
        rule_mismatch = bool(submitted and ocr and text_similarity < 0.68) or sender_conflict
        label = "MISMATCH_CANDIDATE" if rule_mismatch else model_label
        return {
            "available": True,
            "assessment": label,
            "model_assessment": model_label,
            "confidence": round(float(probabilities[idx]), 4),
            "text_similarity": round(text_similarity, 4),
            "sender_conflict": sender_conflict,
            "advisory_only": True,
            "message": ("A possible text/sender mismatch was detected; manual verification is still required."
                        if label == "MISMATCH_CANDIDATE" else
                        "The auxiliary model sees a possible match; this does not prove screenshot authenticity.")
        }
    except Exception:
        return {"available": False, "assessment": "NOT_RUN",
                "message": "Auxiliary assessment was unavailable."}
