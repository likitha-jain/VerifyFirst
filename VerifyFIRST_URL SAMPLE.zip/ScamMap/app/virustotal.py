"""VirusTotal URL reputation integration.

The API key is supplied by server configuration (VT_API_KEY). This module
never exposes the key to the browser and never fetches the submitted URL.
"""
from __future__ import annotations

import asyncio
import base64
import time
from typing import Any

import httpx

VT_BASE = "https://www.virustotal.com/api/v3"
_CACHE_TTL_SECONDS = 15 * 60
_CACHE_MAX_ITEMS = 500
_cache: dict[str, tuple[float, dict[str, Any]]] = {}
_cache_lock = asyncio.Lock()
_vt_semaphore = asyncio.Semaphore(4)
_inflight: dict[str, asyncio.Task] = {}


def _url_id(url: str) -> str:
    return base64.urlsafe_b64encode(url.encode("utf-8")).decode("ascii").rstrip("=")


def _risk(stats: dict[str, Any], phishing: int) -> str:
    if int(stats.get("malicious", 0) or 0) > 0:
        return "HIGH"
    if int(stats.get("suspicious", 0) or 0) > 0 or phishing > 0:
        return "MEDIUM"
    if int(stats.get("harmless", 0) or 0) > 0 or int(stats.get("undetected", 0) or 0) > 0:
        return "NO_DETECTION"
    return "UNKNOWN"


def _format_report(attributes: dict[str, Any], source: str) -> dict[str, Any]:
    stats = attributes.get("last_analysis_stats") or attributes.get("stats") or {}
    engines = attributes.get("last_analysis_results") or attributes.get("results") or {}
    phishing = sum(
        1 for item in engines.values()
        if "phishing" in str(item.get("result") or "").lower()
    )
    counts = {
        "malicious": int(stats.get("malicious", 0) or 0),
        "suspicious": int(stats.get("suspicious", 0) or 0),
        "phishing": phishing,
        "harmless": int(stats.get("harmless", 0) or 0),
        "undetected": int(stats.get("undetected", 0) or 0),
    }
    return {
        "status": "success",
        "provider": "VirusTotal",
        "source": source,
        "risk": _risk(stats, phishing),
        "evidence": counts,
        "total_engines": sum(int(value or 0) for value in stats.values()),
        "message": {
            "HIGH": "One or more security vendors flagged this URL as malicious.",
            "MEDIUM": "One or more suspicious or phishing indicators were reported.",
            "NO_DETECTION": "No malicious detections were present in the available report. This does not prove the URL is safe.",
            "UNKNOWN": "The available report does not contain enough information to assess this URL.",
        }[_risk(stats, phishing)],
    }


async def _check_url_reputation_uncached(url: str, api_key: str) -> dict[str, Any]:
    """Return cached VirusTotal URL intelligence, or fetch/submit a scan."""
    if not api_key:
        return {
            "status": "not_configured",
            "provider": "VirusTotal",
            "message": "External URL intelligence is not configured.",
        }

    now = time.monotonic()
    async with _cache_lock:
        cached = _cache.get(url)
        if cached and now - cached[0] < _CACHE_TTL_SECONDS:
            return dict(cached[1])
        if cached:
            _cache.pop(url, None)

    headers = {"accept": "application/json", "x-apikey": api_key}
    url_id = _url_id(url)

    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(15.0)) as client:
            response = await client.get(f"{VT_BASE}/urls/{url_id}", headers=headers)

            if response.status_code == 404:
                submitted = await client.post(
                    f"{VT_BASE}/urls",
                    headers=headers,
                    data={"url": url},
                )
                submitted.raise_for_status()
                analysis_id = submitted.json()["data"]["id"]

                # Keep the request bounded. A pending scan can be checked again
                # by the user later; cache only completed results.
                attributes = None
                for attempt in range(5):
                    await asyncio.sleep(2)
                    analysis_response = await client.get(
                        f"{VT_BASE}/analyses/{analysis_id}", headers=headers
                    )
                    analysis_response.raise_for_status()
                    analysis = analysis_response.json()["data"]["attributes"]
                    if analysis.get("status") == "completed":
                        attributes = analysis
                        break

                if attributes is None:
                    return {
                        "status": "pending",
                        "provider": "VirusTotal",
                        "message": "URL submitted to VirusTotal. Analysis is still processing; check again shortly.",
                    }
                result = _format_report(attributes, "new_scan")
            else:
                response.raise_for_status()
                attributes = response.json()["data"]["attributes"]
                result = _format_report(attributes, "existing_report")

        async with _cache_lock:
            if len(_cache) >= _CACHE_MAX_ITEMS:
                oldest_key = min(_cache, key=lambda key: _cache[key][0])
                _cache.pop(oldest_key, None)
            _cache[url] = (time.monotonic(), result)
        return result

    except httpx.HTTPStatusError as exc:
        code = exc.response.status_code
        if code == 429:
            message = "VirusTotal rate limit reached. Try again later."
        elif code in (401, 403):
            message = "VirusTotal authentication or permission check failed."
        else:
            message = "VirusTotal could not return a URL report."
        return {"status": "error", "provider": "VirusTotal", "message": message}
    except (httpx.RequestError, asyncio.TimeoutError):
        return {
            "status": "error",
            "provider": "VirusTotal",
            "message": "VirusTotal is temporarily unreachable.",
        }
    except (KeyError, TypeError, ValueError):
        return {
            "status": "error",
            "provider": "VirusTotal",
            "message": "VirusTotal returned an unexpected response.",
        }


async def check_url_reputation(url: str, api_key: str) -> dict[str, Any]:
    """Coalesce identical in-flight lookups and cap concurrent VT work."""
    if not api_key:
        return await _check_url_reputation_uncached(url, api_key)
    async with _cache_lock:
        cached = _cache.get(url)
        if cached and time.monotonic() - cached[0] < _CACHE_TTL_SECONDS:
            return dict(cached[1])
        task = _inflight.get(url)
        if task is None:
            async def run():
                async with _vt_semaphore:
                    return await _check_url_reputation_uncached(url, api_key)
            task = asyncio.create_task(run())
            _inflight[url] = task
    try:
        return dict(await asyncio.shield(task))
    finally:
        async with _cache_lock:
            if _inflight.get(url) is task and task.done():
                _inflight.pop(url, None)
