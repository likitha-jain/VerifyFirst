"""Small SQLite data layer.  One file, no ORM, easy to audit."""

from __future__ import annotations

import sqlite3
import json
import time
import uuid
from pathlib import Path
from typing import Any, Iterable

SCHEMA = """
CREATE TABLE IF NOT EXISTS cases (
    case_id          TEXT PRIMARY KEY,
    identifier_type  TEXT NOT NULL,
    identifier_value TEXT NOT NULL,
    created_ts       REAL NOT NULL,
    UNIQUE (identifier_type, identifier_value)
);

CREATE TABLE IF NOT EXISTS reports (
    seq              INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id        TEXT NOT NULL UNIQUE,
    case_id          TEXT NOT NULL,
    occurred_at      TEXT NOT NULL,
    occurred_ts      REAL NOT NULL,
    reported_at      TEXT NOT NULL,
    reporter_id      TEXT NOT NULL,
    ip_prefix        TEXT NOT NULL,
    channel          TEXT NOT NULL,
    scam_type        TEXT NOT NULL,
    scam_type_raw    TEXT,
    identifier_type  TEXT NOT NULL,
    identifier_value TEXT NOT NULL,
    pincode          TEXT NOT NULL,
    locality         TEXT NOT NULL,
    city             TEXT NOT NULL,
    note             TEXT NOT NULL DEFAULT '',
    note_norm        TEXT NOT NULL DEFAULT '',
    note_hash        TEXT NOT NULL DEFAULT '',
    has_screenshot   INTEGER NOT NULL DEFAULT 0,
    amount_lost_inr  INTEGER NOT NULL DEFAULT 0,
    created_ts       REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_reports_identifier
    ON reports(identifier_type, identifier_value, occurred_ts);
CREATE INDEX IF NOT EXISTS idx_reports_occurred ON reports(occurred_ts);
CREATE INDEX IF NOT EXISTS idx_reports_area ON reports(pincode, occurred_ts);
CREATE INDEX IF NOT EXISTS idx_reports_reporter ON reports(reporter_id);
CREATE INDEX IF NOT EXISTS idx_reports_ip ON reports(ip_prefix);

CREATE TABLE IF NOT EXISTS challenges (
    challenge_id     TEXT PRIMARY KEY,
    identifier_type  TEXT NOT NULL,
    identifier_value TEXT NOT NULL,
    claimant_name    TEXT NOT NULL,
    contact_email    TEXT NOT NULL,
    proof_note       TEXT NOT NULL DEFAULT '',
    status           TEXT NOT NULL DEFAULT 'under_review',
    created_ts       REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_challenges_identifier
    ON challenges(identifier_type, identifier_value, status);

CREATE TABLE IF NOT EXISTS sms_messages (
    report_id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL,
    message_text TEXT NOT NULL,
    normalized_text TEXT NOT NULL,
    text_hash TEXT NOT NULL,
    extracted_identifiers TEXT NOT NULL DEFAULT '[]',
    created_ts REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sms_hash ON sms_messages(text_hash);
CREATE INDEX IF NOT EXISTS idx_sms_created ON sms_messages(created_ts);

CREATE TABLE IF NOT EXISTS sms_evidence (
    evidence_id TEXT PRIMARY KEY,
    report_id TEXT NOT NULL UNIQUE,
    image_hash TEXT NOT NULL,
    file_name TEXT NOT NULL DEFAULT '',
    image_format TEXT NOT NULL,
    image_size INTEGER NOT NULL,
    image_width INTEGER NOT NULL,
    image_height INTEGER NOT NULL,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    ocr_text TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL,
    reason TEXT NOT NULL,
    created_ts REAL NOT NULL,
    FOREIGN KEY(report_id) REFERENCES reports(report_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sms_evidence_hash ON sms_evidence(image_hash);
CREATE INDEX IF NOT EXISTS idx_sms_evidence_status ON sms_evidence(status);

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Daily anonymous-session quota. Only a SHA-256 hash of the random cookie
-- token is stored; the raw session token never enters the database.
CREATE TABLE IF NOT EXISTS report_session_usage (
    session_hash TEXT NOT NULL,
    usage_day    TEXT NOT NULL,
    report_count INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (session_hash, usage_day)
);
"""


class DuplicateReport(Exception):
    pass


class Database:
    def __init__(self, path: str | Path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.init()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=20.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout = 20000")
        return conn

    def init(self) -> None:
        conn = self.connect()
        try:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.executescript(SCHEMA)
            conn.commit()
        finally:
            conn.close()

    # -- cases -------------------------------------------------------------
    def get_or_create_case(self, identifier_type: str, identifier_value: str) -> tuple[str, bool]:
        conn = self.connect()
        try:
            row = conn.execute(
                "SELECT case_id FROM cases WHERE identifier_type = ? AND identifier_value = ?",
                (identifier_type, identifier_value),
            ).fetchone()
            if row:
                return row["case_id"], True
            case_id = "case_" + uuid.uuid4().hex[:12]
            try:
                with conn:
                    conn.execute(
                        "INSERT INTO cases (case_id, identifier_type, identifier_value, created_ts)"
                        " VALUES (?, ?, ?, ?)",
                        (case_id, identifier_type, identifier_value, time.time()),
                    )
                return case_id, False
            except sqlite3.IntegrityError:
                row = conn.execute(
                    "SELECT case_id FROM cases WHERE identifier_type = ? AND identifier_value = ?",
                    (identifier_type, identifier_value),
                ).fetchone()
                if row:
                    return row["case_id"], True
                raise
        finally:
            conn.close()

    # -- reports -----------------------------------------------------------
    def insert_report(self, report: dict[str, Any]) -> None:
        columns = (
            "report_id", "case_id", "occurred_at", "occurred_ts", "reported_at",
            "reporter_id", "ip_prefix", "channel", "scam_type", "scam_type_raw",
            "identifier_type", "identifier_value", "pincode", "locality", "city",
            "note", "note_norm", "note_hash", "has_screenshot", "amount_lost_inr",
            "created_ts",
        )
        values = tuple(report.get(c) for c in columns)
        conn = self.connect()
        try:
            with conn:
                conn.execute(
                    f"INSERT INTO reports ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})",
                    values,
                )
        except sqlite3.IntegrityError as exc:
            if "reports.report_id" in str(exc) or "UNIQUE" in str(exc):
                raise DuplicateReport(report.get("report_id")) from exc
            raise
        finally:
            conn.close()

    def reports_for_identifier(self, identifier_type: str, identifier_value: str) -> list[dict[str, Any]]:
        conn = self.connect()
        try:
            rows = conn.execute(
                "SELECT * FROM reports WHERE identifier_type = ? AND identifier_value = ?"
                " ORDER BY occurred_ts ASC, seq ASC",
                (identifier_type, identifier_value),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def reports_since(self, since_ts: float) -> list[dict[str, Any]]:
        conn = self.connect()
        try:
            rows = conn.execute(
                "SELECT * FROM reports WHERE occurred_ts >= ? ORDER BY occurred_ts ASC, seq ASC",
                (since_ts,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def all_reports(self) -> list[dict[str, Any]]:
        conn = self.connect()
        try:
            rows = conn.execute(
                "SELECT r.*, e.status AS sms_evidence_status "
                "FROM reports r LEFT JOIN sms_evidence e ON e.report_id = r.report_id "
                "ORDER BY r.occurred_ts ASC, r.seq ASC"
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def report_by_id(self, report_id: str) -> dict[str, Any] | None:
        conn = self.connect()
        try:
            row = conn.execute("SELECT * FROM reports WHERE report_id = ?", (report_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    def sms_message_by_report(self, report_id: str) -> dict[str, Any] | None:
        conn = self.connect()
        try:
            row = conn.execute("SELECT * FROM sms_messages WHERE report_id = ?", (report_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    def insert_sms_evidence(self, evidence: dict[str, Any]) -> bool:
        """Atomically detect reused image hashes and insert evidence metadata.

        Returns True when the image hash was already present. The evidence is
        still retained against this report, but cannot become MATCHED.
        """
        conn = self.connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            duplicate = conn.execute(
                "SELECT 1 FROM sms_evidence WHERE image_hash = ? LIMIT 1",
                (evidence["image_hash"],),
            ).fetchone() is not None

            # Perceptual-hash comparison catches resized/recompressed or
            # lightly edited copies. It is a screening signal, not proof of fraud.
            incoming_meta = json.loads(evidence.get("metadata_json") or "{}")
            incoming_phash = incoming_meta.get("perceptual_hash")
            near_duplicate = False
            if incoming_phash:
                prior_rows = conn.execute(
                    "SELECT metadata_json FROM sms_evidence ORDER BY created_ts DESC LIMIT 1000"
                ).fetchall()
                for prior in prior_rows:
                    try:
                        prior_hash = json.loads(prior["metadata_json"] or "{}").get("perceptual_hash")
                        if prior_hash and len(prior_hash) == len(incoming_phash):
                            distance = (int(prior_hash, 16) ^ int(incoming_phash, 16)).bit_count()
                            if distance <= 6:
                                near_duplicate = True
                                break
                    except (ValueError, TypeError, json.JSONDecodeError):
                        continue

            # Detect a sudden coordinated burst of the same exact SMS against
            # the same identifier. Reports are retained but moved out of public
            # results for review; report volume never increases trust.
            report = conn.execute(
                "SELECT identifier_type, identifier_value FROM reports WHERE report_id = ?",
                (evidence["report_id"],),
            ).fetchone()
            burst_report_ids = []
            if report:
                burst_rows = conn.execute(
                    "SELECT sm.report_id, r.reporter_id FROM sms_messages sm "
                    "JOIN reports r ON r.report_id = sm.report_id "
                    "WHERE sm.text_hash = (SELECT text_hash FROM sms_messages WHERE report_id = ?) "
                    "AND r.identifier_type = ? AND r.identifier_value = ? "
                    "AND sm.created_ts >= ?",
                    (evidence["report_id"], report["identifier_type"], report["identifier_value"], evidence["created_ts"] - 900),
                ).fetchall()
                unique_reporters = {row["reporter_id"] for row in burst_rows}
                if len(unique_reporters) >= 4:
                    burst_report_ids = [row["report_id"] for row in burst_rows]

            if duplicate:
                evidence["status"] = "INCONCLUSIVE"
                evidence["reason"] = "DUPLICATE_SCREENSHOT"
            elif near_duplicate:
                evidence["status"] = "INCONCLUSIVE"
                evidence["reason"] = "NEAR_DUPLICATE_SCREENSHOT"
            elif burst_report_ids:
                evidence["status"] = "INCONCLUSIVE"
                evidence["reason"] = "COORDINATED_BURST_REVIEW"
                placeholders = ",".join("?" for _ in burst_report_ids)
                conn.execute(
                    f"UPDATE sms_evidence SET status='INCONCLUSIVE', reason='COORDINATED_BURST_REVIEW' "
                    f"WHERE report_id IN ({placeholders})",
                    tuple(burst_report_ids),
                )
            conn.execute(
                "INSERT INTO sms_evidence (evidence_id, report_id, image_hash, file_name, image_format, image_size, image_width, image_height, metadata_json, ocr_text, status, reason, created_ts) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                tuple(evidence[k] for k in ("evidence_id", "report_id", "image_hash", "file_name", "image_format", "image_size", "image_width", "image_height", "metadata_json", "ocr_text", "status", "reason", "created_ts")),
            )
            conn.commit()
            return duplicate
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def sms_evidence_hash_exists(self, image_hash: str) -> bool:
        conn = self.connect()
        try:
            return conn.execute("SELECT 1 FROM sms_evidence WHERE image_hash = ? LIMIT 1", (image_hash,)).fetchone() is not None
        finally:
            conn.close()

    def sms_evidence_summary_for_identifier(self, identifier_type: str, identifier_value: str) -> dict[str, int]:
        conn = self.connect()
        try:
            rows = conn.execute(
                "SELECT CASE WHEN sm.report_id IS NULL THEN 'NON_SMS' ELSE COALESCE(e.status, 'MISSING') END AS evidence_status, COUNT(*) AS n "
                "FROM reports r LEFT JOIN sms_messages sm ON sm.report_id = r.report_id "
                "LEFT JOIN sms_evidence e ON e.report_id = r.report_id "
                "WHERE r.identifier_type = ? AND r.identifier_value = ? "
                "GROUP BY evidence_status", (identifier_type, identifier_value)
            ).fetchall()
            result = {"sms_total": 0, "matched": 0, "mismatched": 0, "inconclusive": 0, "missing": 0, "non_sms": 0}
            for row in rows:
                status = row["evidence_status"]
                count = int(row["n"])
                if status == "NON_SMS": result["non_sms"] += count
                else:
                    result["sms_total"] += count
                    key = {"MATCHED": "matched", "MISMATCHED": "mismatched", "INCONCLUSIVE": "inconclusive", "MISSING": "missing"}.get(status, "inconclusive")
                    result[key] += count
            return result
        finally:
            conn.close()

    def report_count(self) -> int:
        conn = self.connect()
        try:
            row = conn.execute("SELECT COUNT(*) AS n FROM reports").fetchone()
            return int(row["n"])
        finally:
            conn.close()


    def insert_sms_message(self, message: dict[str, Any]) -> None:
        conn = self.connect()
        try:
            with conn:
                conn.execute(
                    "INSERT INTO sms_messages (report_id, case_id, message_text, normalized_text, text_hash, extracted_identifiers, created_ts) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (message["report_id"], message["case_id"], message["message_text"], message["normalized_text"], message["text_hash"], message["extracted_identifiers"], message["created_ts"]),
                )
        finally:
            conn.close()

    def sms_messages(self, limit: int = 500) -> list[dict[str, Any]]:
        conn = self.connect()
        try:
            rows = conn.execute(
                "SELECT sm.case_id, sm.normalized_text, sm.text_hash, sm.created_ts, "
                "COALESCE(e.status, 'MISSING') AS evidence_status "
                "FROM sms_messages sm "
                "JOIN reports r ON r.report_id = sm.report_id "
                "LEFT JOIN sms_evidence e ON e.report_id = sm.report_id "
                "ORDER BY sm.created_ts DESC LIMIT ?",
                (max(1, min(1000, int(limit))),),
            ).fetchall()
            return [dict(row) for row in rows]
        finally:
            conn.close()

    # -- challenges --------------------------------------------------------
    def add_challenge(self, challenge: dict[str, Any]) -> None:
        conn = self.connect()
        try:
            with conn:
                conn.execute(
                    "INSERT INTO challenges (challenge_id, identifier_type, identifier_value,"
                    " claimant_name, contact_email, proof_note, status, created_ts)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        challenge["challenge_id"], challenge["identifier_type"],
                        challenge["identifier_value"], challenge["claimant_name"],
                        challenge["contact_email"], challenge["proof_note"],
                        challenge.get("status", "under_review"), challenge["created_ts"],
                    ),
                )
        finally:
            conn.close()

    def active_challenge(self, identifier_type: str, identifier_value: str) -> dict[str, Any] | None:
        conn = self.connect()
        try:
            row = conn.execute(
                "SELECT * FROM challenges WHERE identifier_type = ? AND identifier_value = ?"
                " AND status = 'under_review' ORDER BY created_ts DESC LIMIT 1",
                (identifier_type, identifier_value),
            ).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    def challenges(self) -> list[dict[str, Any]]:
        conn = self.connect()
        try:
            rows = conn.execute("SELECT * FROM challenges ORDER BY created_ts DESC").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # -- anonymous-session daily quota ------------------------------------
    def session_report_count(self, session_hash: str, usage_day: str) -> int:
        conn = self.connect()
        try:
            row = conn.execute(
                "SELECT report_count FROM report_session_usage "
                "WHERE session_hash = ? AND usage_day = ?",
                (session_hash, usage_day),
            ).fetchone()
            return int(row["report_count"]) if row else 0
        finally:
            conn.close()

    def reserve_session_report(self, session_hash: str, usage_day: str, limit: int) -> tuple[bool, int]:
        """Atomically reserve one of the session's daily report slots."""
        conn = self.connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT report_count FROM report_session_usage "
                "WHERE session_hash = ? AND usage_day = ?",
                (session_hash, usage_day),
            ).fetchone()
            current = int(row["report_count"]) if row else 0
            if current >= limit:
                conn.rollback()
                return False, current
            new_count = current + 1
            conn.execute(
                "INSERT INTO report_session_usage (session_hash, usage_day, report_count) "
                "VALUES (?, ?, ?) ON CONFLICT(session_hash, usage_day) "
                "DO UPDATE SET report_count = excluded.report_count",
                (session_hash, usage_day, new_count),
            )
            conn.commit()
            return True, new_count
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def release_session_report(self, session_hash: str, usage_day: str) -> int:
        """Return a reserved slot if report insertion fails."""
        conn = self.connect()
        try:
            with conn:
                conn.execute(
                    "UPDATE report_session_usage SET report_count = "
                    "CASE WHEN report_count > 0 THEN report_count - 1 ELSE 0 END "
                    "WHERE session_hash = ? AND usage_day = ?",
                    (session_hash, usage_day),
                )
                row = conn.execute(
                    "SELECT report_count FROM report_session_usage "
                    "WHERE session_hash = ? AND usage_day = ?",
                    (session_hash, usage_day),
                ).fetchone()
                return int(row["report_count"]) if row else 0
        finally:
            conn.close()

    # -- reset -------------------------------------------------------------
    def reset(self) -> int:
        conn = self.connect()
        try:
            row = conn.execute("SELECT COUNT(*) AS n FROM reports").fetchone()
            count = int(row["n"])
            with conn:
                conn.execute("DELETE FROM sms_evidence")
                conn.execute("DELETE FROM reports")
                conn.execute("DELETE FROM cases")
                conn.execute("DELETE FROM challenges")
                conn.execute("DELETE FROM sms_messages")
                conn.execute("DELETE FROM report_session_usage")
            return count
        finally:
            conn.close()

    # -- meta --------------------------------------------------------------
    def get_meta(self, key: str) -> str | None:
        conn = self.connect()
        try:
            row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
            return row["value"] if row else None
        finally:
            conn.close()

    def set_meta(self, key: str, value: str) -> None:
        conn = self.connect()
        try:
            with conn:
                conn.execute(
                    "INSERT INTO meta (key, value) VALUES (?, ?)"
                    " ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                    (key, value),
                )
        finally:
            conn.close()

    def max_meta_float(self, key: str, candidate: float) -> float:
        """Persist the largest value ever seen. Returns the stored value."""
        conn = self.connect()
        try:
            with conn:
                row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
                current = float(row["value"]) if row else 0.0
                if candidate > current:
                    conn.execute(
                        "INSERT INTO meta (key, value) VALUES (?, ?)"
                        " ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                        (key, str(candidate)),
                    )
                    return candidate
                return current
        finally:
            conn.close()

    def clear_meta(self, key: str) -> None:
        conn = self.connect()
        try:
            with conn:
                conn.execute("DELETE FROM meta WHERE key = ?", (key,))
        finally:
            conn.close()

    def bulk_insert_reports(self, reports: Iterable[dict[str, Any]]) -> None:
        for report in reports:
            self.insert_report(report)
