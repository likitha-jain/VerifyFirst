"""Identifier normalisation, validation and privacy-safe masking.

One identifier can be typed many ways.  Every identifier is stored in exactly
one canonical form so that lookups cannot be bypassed by adding spaces, a
country code, ``www.`` or a tracking parameter.
"""

from __future__ import annotations

import re
from urllib.parse import urlsplit

IDENTIFIER_TYPES = ("phone", "upi", "url", "sender_id")
TYPE_LABELS = {
    "phone": "Phone number",
    "upi": "UPI ID",
    "url": "Link",
    "sender_id": "SMS sender",
}


class IdentifierError(ValueError):
    """Raised when an identifier cannot possibly be valid."""


_PHONE_CHARS = re.compile(r"^[+0-9()\-.\s]+$")
_UPI_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{1,255}@[a-z][a-z0-9.-]{1,63}$")
_SENDER_RE = re.compile(r"^[A-Z0-9]{5,8}$")
_SENDER_PREFIX_RE = re.compile(r"^(?:[A-Z]{2})[- ]([A-Z0-9]{5,8})$")
_IPV4_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")
_HOST_RE = re.compile(r"^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$")


def _digits(value: str) -> str:
    return re.sub(r"\D", "", value)


def normalize_phone(raw: str) -> str:
    if raw is None:
        raise IdentifierError("phone number is missing")
    text = str(raw).strip()
    if not text or len(text) > 40 or not _PHONE_CHARS.fullmatch(text):
        raise IdentifierError("not a valid phone number")

    d = _digits(text)
    if not d:
        raise IdentifierError("not a valid phone number")

    # International / trunk prefixes.
    if d.startswith("0091"):
        d = d[4:]
    elif d.startswith("00"):
        d = d[2:]
    if len(d) >= 12 and d.startswith("91"):
        d = d[2:]
    if len(d) == 11 and d.startswith("0"):
        d = d[1:]

    national = d

    if len(national) == 10 and national[0] in "123456789":
        pass
    elif 8 <= len(national) <= 12 and national.startswith(("1800", "1860")):
        # Toll-free numbers are not 10-digit mobiles.
        pass
    elif len(national) == 4 and national.startswith("19"):
        # Short helplines such as 1930 and 1909.
        pass
    else:
        raise IdentifierError("not a valid Indian phone number")

    if len(set(national)) == 1:
        raise IdentifierError("junk phone number")
    if len(national) >= 8 and len(set(national)) < 3:
        raise IdentifierError("junk phone number")

    return "+91" + national


def normalize_upi(raw: str) -> str:
    if raw is None:
        raise IdentifierError("UPI ID is missing")
    text = re.sub(r"\s+", "", str(raw)).lower()
    if len(text) > 320 or not _UPI_RE.fullmatch(text):
        raise IdentifierError("not a valid UPI ID")
    local, domain = text.split("@", 1)
    if local.startswith(".") or local.endswith(".") or ".." in local:
        raise IdentifierError("not a valid UPI ID")
    if domain.startswith((".", "-")) or domain.endswith((".", "-")) or ".." in domain:
        raise IdentifierError("not a valid UPI ID")
    return text


def normalize_url(raw: str) -> str:
    if raw is None:
        raise IdentifierError("link is missing")
    text = str(raw).strip()
    if not text or len(text) > 2048 or any(c.isspace() for c in text):
        raise IdentifierError("not a valid link")
    if "://" not in text:
        text = "https://" + text

    try:
        parts = urlsplit(text)
    except ValueError as exc:
        raise IdentifierError("not a valid link") from exc

    if parts.scheme.lower() not in ("http", "https"):
        raise IdentifierError("only http and https links are accepted")

    host = (parts.hostname or "").lower().strip(".")
    if host.startswith("www."):
        host = host[4:]
    if not host or len(host) > 253:
        raise IdentifierError("not a valid link")
    if not (_HOST_RE.fullmatch(host) or _IPV4_RE.fullmatch(host)):
        raise IdentifierError("not a valid link")
    if _IPV4_RE.fullmatch(host):
        for octet in host.split("."):
            if int(octet) > 255:
                raise IdentifierError("not a valid link")

    path = re.sub(r"/{2,}", "/", parts.path or "")
    if path == "/":
        path = ""
    if path.endswith("/"):
        path = path[:-1]

    port = ""
    try:
        if parts.port and parts.port not in (80, 443):
            port = f":{parts.port}"
    except ValueError as exc:
        raise IdentifierError("not a valid link") from exc

    # Query strings and fragments are tracking noise; the PRD requires them gone.
    return f"https://{host}{port}{path}"


def normalize_sender(raw: str) -> str:
    if raw is None:
        raise IdentifierError("SMS sender is missing")
    text = re.sub(r"\s+", "", str(raw)).upper()
    match = _SENDER_PREFIX_RE.fullmatch(text)
    if match:
        text = match.group(1)
    if not _SENDER_RE.fullmatch(text) or not any(ch.isalpha() for ch in text):
        raise IdentifierError("not a valid SMS sender ID")
    return text


def normalize_identifier(identifier_type: str, raw: str) -> str:
    kind = str(identifier_type or "").strip().lower()
    if kind not in IDENTIFIER_TYPES:
        raise IdentifierError("identifier_type must be phone, upi, url or sender_id")
    if kind == "phone":
        return normalize_phone(raw)
    if kind == "upi":
        return normalize_upi(raw)
    if kind == "url":
        return normalize_url(raw)
    return normalize_sender(raw)


def detect_type(raw: str) -> str:
    """Best-effort type detection used by the UI; users can always override it."""
    text = str(raw or "").strip()
    if not text:
        return "phone"
    if re.match(r"^(https?://)", text, re.I):
        return "url"
    if "@" in text and "://" not in text:
        return "upi"
    if re.fullmatch(r"[+\d][\d\s().-]*", text):
        return "phone"
    if "." in text and re.search(r"\.[a-z]{2,}(?:/|$|\?)", text, re.I):
        return "url"
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 -]{4,11}", text):
        return "sender_id"
    return "phone"


def mask_value(identifier_type: str, canonical: str) -> str:
    """Mask an identifier until at least three different people reported it."""
    if identifier_type == "phone":
        national = canonical[3:] if canonical.startswith("+91") else canonical
        n = len(national)
        if n <= 2:
            return "X" * n
        if n <= 4:
            return national[0] + "X" * (n - 2) + national[-1]
        if n == 10:
            return national[:2] + "XXXXX" + national[-3:]
        return national[:2] + "X" * (n - 5) + national[-3:]

    if identifier_type == "upi":
        local, _, domain = canonical.partition("@")
        return (local[0] if local else "") + "***@" + domain

    if identifier_type == "url":
        parts = urlsplit(canonical)
        host = parts.hostname or ""
        labels = host.split(".")
        first = labels[0] if labels else host
        rest = ".".join(labels[1:])
        masked = (first[:3] if len(first) >= 3 else first) + "***"
        if rest:
            masked += "." + rest
        if parts.path:
            masked += "/..."
        return masked

    if identifier_type == "sender_id":
        if len(canonical) <= 2:
            return canonical[0] + "****" if canonical else "****"
        return canonical[:2] + "*" * (len(canonical) - 2)

    return "***"


def pretty_identifier(identifier_type: str, canonical: str) -> str:
    """Human-readable canonical form (used by the UI, not by the API contract)."""
    if identifier_type == "phone" and canonical.startswith("+91"):
        national = canonical[3:]
        if len(national) == 10:
            return f"+91 {national[:5]} {national[5:]}"
    return canonical


def validate_reporter_id(value: str | None) -> str:
    text = str(value or "").strip()
    if not text or len(text) > 128:
        raise IdentifierError("reporter_id is required")
    return text


def sanitize_ip_prefix(value: str | None) -> str:
    """Store a network prefix only - never a full address."""
    text = str(value or "").strip()
    if not text:
        return "unknown"
    if _IPV4_RE.fullmatch(text):
        return ".".join(text.split(".")[:3])
    if ":" in text:
        return ":".join(text.split(":")[:3])
    return text[:32]
