from pathlib import Path
import joblib
ROOT=Path(__file__).resolve().parents[1]
MODEL_PATH=ROOT/"app/models/message_classifier.joblib"
class MessageModelNotReady(RuntimeError): pass
def predict_message(text: str) -> dict:
 if not MODEL_PATH.exists(): raise MessageModelNotReady("Model not trained. Run: python scripts/train_message_model.py")
 model=joblib.load(MODEL_PATH); probs=model.predict_proba([text])[0]; labels=model.classes_; i=int(probs.argmax()); label=str(labels[i])
 note=("Resembles an unsupported coordinated-report allegation. Do not count it as verified scam evidence." if label=="COORDINATED_UNVERIFIED_REPORT" else "Resembles a synthetic scam-message example. This is a screening signal, not proof.")
 return {"predicted_class":label,"confidence":round(float(probs[i]),4),"class_probabilities":{str(k):round(float(v),4) for k,v in zip(labels,probs)},"interpretation":note,"model_scope":"50 synthetic examples; prototype only"}
