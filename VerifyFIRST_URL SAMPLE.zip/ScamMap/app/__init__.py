"""Community Scam Map application package."""
