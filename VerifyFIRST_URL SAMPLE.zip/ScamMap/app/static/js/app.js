/* ============================================================
   ScamMap front-end
   No framework, no build step. All identifiers stay in memory;
   localStorage only holds an anonymous reporter ID, area and language.
   ============================================================ */

'use strict';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

const state = {
  meta: null,
  license: null,
  licenseFetchedAt: 0,
  licenseLoaded: false,
  map: { clusters: [] },
  alerts: [],
  page: 'check',
  lang: localStorage.getItem('sm_lang') || 'en',
  area: localStorage.getItem('sm_area') || '560102',
  lookupType: 'auto',
  reportType: 'auto',
  mapCity: 'All India',
  mapPin: null,
  alertPin: '',
  recent: [],
  lastLookup: null,
  lastReport: null,
  report: { channel: 'Phone call', scam: '', when: 'now', area: null },
  licensePolling: false,
  countdownExpired: false,
  leafletMap: null,
  leafletMarkers: null,
  leafletHeat: null,
  leafletHeatVisible: true,
  leafletLastCity: null,
};

const I18N = {
  en: {
    'nav.check': 'Check', 'nav.report': 'Report a scam', 'nav.map': 'Scam map', 'nav.alerts': 'Alerts',
    'nav.license': 'Licence', 'nav.trust': 'Trust rules', 'nav.report.short': 'Report', 'nav.map.short': 'Map',
    'nav.alerts.short': 'Alerts', 'nav.license.short': 'Licence',
    'side.live': 'Trust engine live', 'side.known': 'high-credibility reports', 'side.areas': 'areas active',
    'side.how': 'How reports are scored', 'side.api': 'API connected', 'side.licence': 'Licence valid',
    'side.helpline': 'Cybercrime portal',
    'top.check': 'Lookup', 'top.check.title': 'Check an identifier', 'top.report': 'Report a scam',
    'top.report.title': 'Report a scam', 'top.map': 'Area intelligence', 'top.map.title': 'Scam map',
    'top.alerts': 'Signal, not noise', 'top.alerts.title': 'Unusual activity',
    'top.license': 'Server', 'top.license.title': 'Licence & server',
    'top.trust': 'The hard half', 'top.trust.title': 'Trust rules',
    'hero.eyebrow': 'Community-powered · 100% anonymous',
    'hero.title': 'Check before<br><span class="gradient-text">you trust.</span>',
    'hero.sub': 'See if a phone number, UPI ID, link or SMS sender has been reported near you — before you pay, call back or click.',
    'hero.metric.reports': 'reports this week', 'hero.metric.areas': 'areas with reports',
    'hero.metric.alerts': 'unusual patterns',
    'hero.trust': 'Built for Ravi, Priya and every family that deserves a warning before the loss.',
    'check.label': 'Look up an identifier', 'check.private': 'Private',
    'check.placeholder': 'Paste a number, UPI ID, link or sender',
    'check.button': 'Check now', 'check.recent': 'Recent',
    'check.privacy': 'We never show who reported. Areas only, never exact locations.',
    'type.auto': 'Auto', 'type.phone': 'Phone', 'type.upi': 'UPI', 'type.url': 'Link', 'type.sender': 'SMS',
    'home.kicker': 'Why this exists', 'home.how.title': 'Built for the moment after the call',
    'home.how.note': 'No login. No names. No exact addresses.',
    'home.f1.title': 'Report in under 60 seconds',
    'home.f1.body': 'Pick how they reached you, paste the identifier, choose your area. That is it.',
    'home.f1.tag': 'Anonymous by default',
    'home.f2.title': 'See the last 7 days',
    'home.f2.body': "Reports are grouped by area on the map — never at a reporter's doorstep.",
    'home.f2.tag': 'Area-level only',
    'home.f3.title': 'Fake reports do not count',
    'home.f3.body': 'One person, one Wi-Fi or one copy-pasted message cannot label an innocent business.',
    'home.f3.tag': 'Asymmetric trust rules',
    'home.feed.kicker': 'Live this week', 'home.feed.title': 'What people are reporting',
    'home.alerts.kicker': 'Unusual only', 'home.alerts.title': 'Alerts near you', 'home.alerts.all': 'View all',
    'home.helpline.title': 'Already lost money?',
    'home.helpline.body': 'Call 1930 now. The faster you report, the better the chance of freezing the transfer.',
    'report.eyebrow': 'Anonymous · area only', 'report.title': 'Report a scam',
    'report.sub': 'Five quick taps. No login, no name, no exact address. Your warning can protect the next person.',
    'report.time': 'Under 60 seconds',
    'report.channel.title': 'How did they reach you?',
    'report.channel.sub': 'Choose the channel. Icons work on their own.',
    'report.type.title': 'What kind of scam?',
    'report.type.sub': 'Pick the closest match. You can add details later.',
    'report.id.title': 'What did they use?',
    'report.id.sub': 'A number, UPI ID, link or SMS sender. Any format is fine.',
    'report.id.placeholder': '+91 98765 43210, name@okaxis, https://…',
    'report.area.title': 'Where are you?',
    'report.area.sub': 'We save the area only — never your street or exact location.',
    'report.area.label': 'Area',
    'report.area.privacy': "Only the area is stored. The map uses the area's map point, never a reporter's location.",
    'report.when.label': 'When',
    'when.now': 'Just now', 'when.hour': 'Last hour', 'when.today': 'Today',
    'when.yesterday': 'Yesterday', 'when.custom': 'Pick a time',
    'report.note.title': 'Tell us what happened', 'report.note.optional': 'optional',
    'report.note.sub': 'Your own words help more than a copy-pasted message.',
    'report.note.placeholder': 'What did they say or send? Anything that would help the next person spot it.',
    'report.note.hint': 'Personal details make the report stronger',
    'report.screenshot': 'I have a screenshot', 'report.amount': 'Amount lost (₹)',
    'report.consent': 'Your report is anonymous. We store only your area, never your name, phone number or exact location.',
    'report.submit': 'Post anonymous report',
    'report.aside.title': 'Your identity stays out of it',
    'report.aside.1': 'No name, phone number or login',
    'report.aside.2': 'Area only — never a precise location',
    'report.aside.3': 'Notes are never shown in lookup results',
    'report.aside.4': 'Numbers stay masked until 3 people report',
    'report.aside.next': 'What happens next?',
    'report.aside.next1': 'Your report joins a case for that identifier.',
    'report.aside.next2': 'Trust rules score it for independence and quality.',
     'report.aside.next3': 'Independent reports strengthen internal evidence, but reports alone never verify an identifier.',
    'report.aside.meter': 'A single report never labels anyone publicly',
     'success.title': 'Thank you. Your report has been received.',
     'success.sub': 'Your anonymous report is received. The identifier remains not verified until independently confirmed.',
    'success.case': 'Case', 'success.merged': 'Joined existing case',
    'success.check': 'Check this identifier', 'success.again': 'Report another',
    'map.eyebrow': 'Area-level intelligence', 'map.title': 'Scam map',
    'map.sub': "Every report from the last 7 days, grouped by area. Never a reporter's location.",
    'map.window': 'Last 7 days', 'map.refresh': 'Refresh',
    'map.crit': 'Critical', 'map.high': 'High', 'map.med': 'Medium',
    'map.empty.title': 'No reports in this view',
    'map.empty.body': 'Try another city, or be the first to report a scam in your area.',
    'map.empty.cta': 'Report a scam',
    'map.privacy': 'Area map points only. No reporter coordinates are stored or shown.',
    'map.select.title': 'Select an area',
    'map.select.body': 'Tap a marker to see the report count and top scam type.',
    'map.list.title': 'Areas with reports',
    'alerts.eyebrow': 'Only when something is unusual', 'alerts.title': 'Alerts',
    'alerts.sub': 'A spike or a brand-new scam type. Never a notification for every report.',
    'alerts.refresh': 'Refresh',
    'alerts.how.kicker': 'Signal, not noise', 'alerts.how.title': 'How alerts work',
    'alerts.how.spike.title': 'A real spike',
    'alerts.how.spike.body': 'At least 5 reports in 24 hours, and at least double the daily average of the previous 7 days.',
    'alerts.how.new.title': 'A new type',
    'alerts.how.new.body': 'A scam type seen in the last 24 hours that has not appeared in that area for 30 days.',
    'alerts.how.fake.title': 'Fakes stay quiet',
    'alerts.how.fake.body': 'Reports ignored by the trust rules never set off an alert, even in a large burst.',
    'licence.eyebrow': 'Prepaid-style server licence', 'licence.title': 'Licence & server',
    'licence.sub': 'Signed with Ed25519, checked on every request, renewable without a restart.',
    'licence.json': 'GET /license', 'licence.docs': 'API docs',
    'licence.licensed': 'Licensed to', 'licence.remaining': 'remaining',
    'licence.expires': 'Expires', 'licence.server': 'Server time', 'licence.id': 'Licence ID',
    'licence.renew.kicker': 'No restart needed', 'licence.renew.title': 'Upload a renewed licence',
    'licence.renew.body': 'Drop the signed JSON file here. The server verifies the signature and keeps all existing reports.',
    'licence.renew.drop': 'Choose a licence file', 'licence.renew.drop2': 'or drag and drop it',
    'licence.renew.verify': 'Signature checked against the public key built into the server.',
    'licence.demo.kicker': 'Demo tools', 'licence.demo.title': 'Practise the four-step demo',
    'licence.demo.badge': 'Demo mode',
    'licence.demo.body': 'Issue a short licence, watch the app lock, then renew it. Reports are never deleted.',
    'licence.demo.five': 'Issue 5-minute licence', 'licence.demo.year': 'Issue 1-year licence',
    'licence.demo.seed': 'Load demo data', 'licence.demo.reset': 'Reset all reports',
    'licence.demo.note': 'Disable demo endpoints with DEMO_MODE=0 and ALLOW_DEMO_LICENSE_ISSUE=0 before handing this to a customer.',
    'licence.steps.kicker': 'Judging demo', 'licence.steps.title': 'Four steps, live',
    'licence.steps.1.title': 'Show the app working',
    'licence.steps.1.body': 'Open GET /license and show who it is licensed to and when it expires.',
    'licence.steps.2.title': 'Upload a 5-minute licence',
    'licence.steps.2.body': 'The countdown starts. Nothing restarts.',
    'licence.steps.3.title': 'Watch a lookup fail',
    'licence.steps.3.body': 'Every API except /health and /license returns 403 LICENSE_EXPIRED. The app shows the locked screen.',
    'licence.steps.4.title': 'Renew and continue',
    'licence.steps.4.body': 'Upload a long licence. The app works again within a minute, with all old data intact.',
    'trust.eyebrow': 'The hard half', 'trust.title': 'How we stop fake reports',
    'trust.sub': 'A single person, one Wi-Fi or one copy-pasted message must never label an innocent business. A real wave of unrelated people must still be believed.',
    'trust.badge': 'Asymmetric trust',
    'trust.flow.1': 'Normalise', 'trust.flow.1b': 'One identifier, every format',
    'trust.flow.2': 'Score', 'trust.flow.2b': 'History, words, network, timing',
    'trust.flow.3': 'Collapse', 'trust.flow.3b': 'One person stays one person',
    'trust.flow.4': 'Decide', 'trust.flow.4b': '3 credible people to confirm',
    'trust.r1.title': 'One person, one report',
    'trust.r1.body': 'Six reports from the same reporter ID count as one person. The report count is shown, but the verdict uses distinct identities.',
    'trust.r1.tag': 'Identity collapse',
    'trust.r2.title': 'One Wi-Fi, one person',
    'trust.r2.body': 'Three or more reporter IDs on the same IP prefix within 24 hours collapse into one identity. 22 fake accounts become 1.',
    'trust.r2.tag': 'Network clustering',
    'trust.r3.title': 'Reputation compounds',
    'trust.r3.body': 'New accounts start at 0.60. Reporters whose earlier reports were corroborated by others rise to 0.90–1.00. Repeated reports against verified businesses fall to 0.20.',
    'trust.r3.tag': 'Reporter history',
    'trust.r4.title': 'Own words beat copy-paste',
    'trust.r4.body': 'Detailed, personal notes score up to 0.95. Empty notes 0.50. Exact or near-duplicate notes 0.12. Junk notes 0.08.',
    'trust.r4.tag': 'Note quality',
    'trust.r5.title': 'Bursts are suspicious, not proof',
    'trust.r5.body': 'A sudden burst of new accounts with scripted notes is down-weighted. A real wave with detailed, varied notes still counts.',
    'trust.r5.tag': 'Coordination signal',
    'trust.r6.title': 'Junk never enters',
    'trust.r6.body': '“12345”, “test”, repeated digits and malformed links are rejected with 400 before scoring. Unknown scam types become “other”.',
    'trust.r6.tag': 'Validation',
    'trust.threshold.kicker': 'The decision', 'trust.threshold.title': 'Public lookup statuses',
    'trust.v.known': 'Independent evidence contributes to an internal credibility score',
    'trust.v.knownb': 'This score never automatically labels an identifier as a scam.',
    'trust.v.sus': 'Community reports received; identifier is NOT VERIFIED',
    'trust.v.susb': 'Reports alone do not verify an identifier; masking depends on credible independent reports.',
    'trust.v.none': 'Nobody has reported this identifier',
    'trust.v.noneb': 'Still no guarantee. Verify through an official channel.',
    'trust.v.ver': 'An independently verified contact or business',
    'trust.v.verb': 'Verification comes from the trusted registry, never from report volume.',
    'trust.privacy.kicker': 'Non-negotiable', 'trust.privacy.title': 'Privacy commitments',
    'trust.p1': 'Reporters stay anonymous. No names, phone numbers or exact locations are stored.',
    'trust.p2': 'Numbers are masked until at least 3 credible, independent reporters support the evidence.',
    'trust.p3': 'The app says “reported”, never “this person is a fraud”.',
    'trust.p4': 'No personal data is scraped from social media or people-search sites.',
    'trust.p5': 'Access logs are disabled so lookup URLs never write a phone number to disk.',
    'trust.try.kicker': 'See it for yourself', 'trust.try.title': 'Try the demo scenarios',
    'trust.try.body': 'Load the demo data, then check these identifiers. The bombing target has 18 reports but only one distinct person.',
    'footer.love': 'Built for safer communities. Anonymous by design.', 'footer.trust': 'Trust rules',
    'verdict.known': 'Known scam', 'verdict.suspicious': 'Suspicious', 'verdict.none': 'No reports yet',
    'verdict.verified': 'Verified',
    'verdict.known.sub': 'Reported by {n} people near you',
    'verdict.suspicious.sub': 'Reported by {n} people, but not enough independent trust to confirm.',
    'verdict.suspicious.challenged': 'A business has disputed this listing. It is under review.',
    'verdict.none.sub': 'No one in this community has reported this identifier yet. Stay careful.',
    'verdict.verified.sub': 'A verified business or helpline. Always verify through an official channel.',
    'result.reports': 'Reports', 'result.people': 'Distinct people', 'result.trusted': 'Trusted',
    'result.lastseen': 'Last seen', 'result.hidden': 'Hidden until 3 different people report it',
    'result.report': 'Report this', 'result.challenge': 'This is my business', 'result.copy': 'Copy warning',
    'result.evidence': 'Recent evidence', 'result.privacy': 'No reporter names, notes or exact locations are ever shown.',
    'result.noevidence': 'No public evidence yet.',
    'result.checked': 'You checked', 'result.copied': 'Warning copied to clipboard',
    'result.challenge.banner': 'This listing is under review after a business dispute.',
    'scam.other': 'Other', 'channel.phone': 'Phone call', 'channel.sms': 'SMS or WhatsApp',
    'channel.qr': 'QR code', 'channel.website': 'Fake website', 'channel.upi': 'UPI request',
    'channel.other': 'Something else',
    'toast.lookup.failed': 'Lookup failed. Please try again.',
    'toast.invalid': 'Check the identifier and try again.',
    'toast.rate': 'Too many reports from this device. Please wait a few minutes.',
    'toast.report.ok': 'Report posted anonymously. Thank you.',
    'toast.report.dup': 'This report was already received.',
    'toast.license.ok': 'Licence installed. Access is live.',
    'toast.license.bad': 'That licence could not be verified.',
    'toast.license.expired': 'Licence accepted, but it has already expired.',
    'toast.seed.ok': 'Demo data loaded.',
    'toast.reset.ok': 'All reports deleted.',
    'toast.challenge.ok': 'Dispute received. The listing is under review.',
    'toast.demo.off': 'Demo tools are disabled on this server.',
    'toast.copy.fail': 'Could not copy. Select the text manually.',
    'toast.area.saved': 'Area saved on this device.',
    'toast.required': 'Please complete the required fields.',
    'toast.allquiet': 'No unusual patterns right now.',
    'error.title': 'That did not work',
    'empty.feed': 'No reports in the last 7 days yet.',
    'empty.alerts': 'All quiet. Alerts only fire for real spikes or new scam types.',
    'empty.map': 'No areas with reports in this view.',
    'license.no': 'No licence installed',
    'license.valid': 'Licence valid', 'license.expired': 'Licence expired',
    'license.clock': 'Clock rollback detected', 'license.invalid': 'Invalid licence',
    'license.missing': 'Licence missing',
    'overlay.expired.title': 'Licence expired',
    'overlay.expired.text': 'This server is locked. Every API except /health and /license returns 403. Your reports are safe and nothing has been deleted.',
    'overlay.missing.title': 'No licence installed',
    'overlay.missing.text': 'Upload a signed licence to unlock the server. Existing data is untouched.',
    'overlay.invalid.title': 'Licence signature invalid',
    'overlay.invalid.text': 'The file was not signed by the trusted key. Check that you uploaded the right licence.',
    'overlay.clock.title': 'Server clock moved backwards',
    'overlay.clock.text': 'The server detected a clock rollback. Upload a valid licence to clear the high-water mark and restore access.',
    'overlay.upload': 'Upload renewed licence', 'overlay.issue': 'Issue 5-minute demo licence',
    'overlay.retry': 'Retry', 'overlay.safe': 'Data is preserved. A valid licence restores access without a restart.',
    'challenge.title': 'This is my business',
    'challenge.sub': 'Tell us what is wrong. A human reviews every dispute before anything changes.',
    'challenge.name': 'Your name', 'challenge.email': 'Contact email',
    'challenge.proof': 'What should we know?', 'challenge.proof.placeholder': 'Business registration, official number, or why this listing is wrong.',
    'challenge.cancel': 'Cancel', 'challenge.submit': 'Submit dispute',
    'confirm.reset.title': 'Delete all reports?',
    'confirm.reset.text': 'This removes every report, case and challenge from the demo database. The licence and keys are kept. This cannot be undone.',
    'confirm.seed.title': 'Replace data with demo reports?',
    'confirm.seed.text': 'This clears the current database and loads the 115-report demo set. The licence is kept.',
    'confirm.delete': 'Yes, replace data', 'confirm.cancel': 'Cancel',
    'map.detail.reports': 'Reports', 'map.detail.people': 'People', 'map.detail.top': 'Top type',
    'map.detail.alerts': 'View alerts', 'map.detail.report': 'Report here',
    'alerts.summary.one': '1 unusual pattern detected', 'alerts.summary.many': '{n} unusual patterns detected',
    'alerts.summary.quiet': 'All quiet right now',
    'alerts.summary.body': 'Alerts fire only for real spikes and brand-new scam types.',
    'alerts.spike.title': 'Reports doubled in {area}',
    'alerts.spike.body': '{n} reports in the last 24 hours — {base} per day is the 7-day baseline.',
    'alerts.new.title': 'New scam type: {type}',
    'alerts.new.body': 'First seen in {area} in the last 24 hours. It was not reported there in the previous 30 days.',
    'alerts.count': '24h reports', 'alerts.baseline': 'Baseline / day', 'alerts.window': 'Window',
    'alerts.type': 'Type', 'alerts.area': 'Area', 'alerts.view': 'View area',
    'map.all': 'All India',
    'map.city': 'City',
    'map.report.count': '{n} reports',
    'feed.across': 'across {n} areas',
    'feed.reports': '{n} reports',
    'license.countdown': 'remaining',
    'license.demo': 'Demo mode',
  },
  hi: {
    'nav.check': 'जाँच', 'nav.report': 'शिकायत', 'nav.map': 'नक्शा', 'nav.alerts': 'अलर्ट',
    'nav.license': 'लाइसेंस', 'nav.trust': 'भरोसा', 'nav.report.short': 'शिकायत', 'nav.map.short': 'नक्शा',
    'nav.alerts.short': 'अलर्ट', 'nav.license.short': 'लाइसेंस',
    'side.live': 'ट्रस्ट इंजन सक्रिय', 'side.known': 'उच्च विश्वसनीयता वाली रिपोर्ट', 'side.areas': 'सक्रिय क्षेत्र',
    'side.how': 'शिकायतों को कैसे स्कोर किया जाता है', 'side.api': 'API जुड़ा है', 'side.licence': 'लाइसेंस वैध',
    'side.helpline': 'साइबर अपराध पोर्टल',
    'top.check': 'जाँच', 'top.check.title': 'पहचान जाँचें', 'top.report': 'शिकायत करें',
    'top.report.title': 'शिकायत दर्ज करें', 'top.map': 'क्षेत्रीय जानकारी', 'top.map.title': 'ठगी का नक्शा',
    'top.alerts': 'शोर नहीं, संकेत', 'top.alerts.title': 'असामान्य गतिविधि',
    'top.license': 'सर्वर', 'top.license.title': 'लाइसेंस और सर्वर',
    'top.trust': 'कठिन आधा', 'top.trust.title': 'भरोसे के नियम',
    'hero.eyebrow': 'समुदाय-संचालित · पूरी तरह गुमनाम',
    'hero.title': 'भरोसा करने से<br><span class="gradient-text">पहले जाँचें।</span>',
    'hero.sub': 'देखें कि कोई फ़ोन नंबर, UPI ID, लिंक या SMS भेजने वाला आपके पास पहले रिपोर्ट हुआ है या नहीं — पैसे भेजने, वापस कॉल करने या क्लिक करने से पहले।',
    'hero.metric.reports': 'इस हफ़्ते की शिकायतें', 'hero.metric.areas': 'शिकायत वाले क्षेत्र',
    'hero.metric.alerts': 'असामान्य पैटर्न',
    'hero.trust': 'रवि, प्रिया और हर उस परिवार के लिए जो नुकसान से पहले चेतावनी का हक़दार है।',
    'check.label': 'पहचान जाँचें', 'check.private': 'निजी',
    'check.placeholder': 'नंबर, UPI ID, लिंक या भेजने वाला पेस्ट करें',
    'check.button': 'अभी जाँचें', 'check.recent': 'हाल की',
    'check.privacy': 'हम कभी नहीं बताते कि किसने शिकायत की। सिर्फ़ क्षेत्र, कभी सटीक लोकेशन नहीं।',
    'type.auto': 'स्वतः', 'type.phone': 'फ़ोन', 'type.upi': 'UPI', 'type.url': 'लिंक', 'type.sender': 'SMS',
    'home.kicker': 'यह क्यों है', 'home.how.title': 'कॉल के बाद वाले पल के लिए',
    'home.how.note': 'कोई लॉगिन नहीं। कोई नाम नहीं। कोई सटीक पता नहीं।',
    'home.f1.title': '60 सेकंड में शिकायत',
    'home.f1.body': 'चुनें कि उन्होंने कैसे संपर्क किया, पहचान पेस्ट करें, अपना क्षेत्र चुनें। बस इतना ही।',
    'home.f1.tag': 'डिफ़ॉल्ट रूप से गुमनाम',
    'home.f2.title': 'पिछले 7 दिन देखें',
    'home.f2.body': 'शिकायतें नक्शे पर क्षेत्र के हिसाब से दिखती हैं — किसी के घर के सामने नहीं।',
    'home.f2.tag': 'सिर्फ़ क्षेत्र स्तर',
    'home.f3.title': 'फ़र्ज़ी शिकायतें नहीं गिनतीं',
    'home.f3.body': 'एक व्यक्ति, एक Wi-Fi या एक कॉपी-पेस्ट संदेश किसी मासूम व्यवसाय को ठग नहीं बना सकता।',
    'home.f3.tag': 'असमान भरोसा नियम',
    'home.feed.kicker': 'इस हफ़्ते लाइव', 'home.feed.title': 'लोग क्या रिपोर्ट कर रहे हैं',
    'home.alerts.kicker': 'सिर्फ़ असामान्य', 'home.alerts.title': 'आपके पास के अलर्ट', 'home.alerts.all': 'सभी देखें',
    'home.helpline.title': 'पैसे गँवा दिए?',
    'home.helpline.body': 'अभी 1930 पर कॉल करें। जितनी जल्दी रिपोर्ट करेंगे, ट्रांसफ़र रोकने का मौका उतना बेहतर।',
    'report.eyebrow': 'गुमनाम · सिर्फ़ क्षेत्र', 'report.title': 'शिकायत दर्ज करें',
    'report.sub': 'पाँच आसान टैप। कोई लॉगिन, नाम या सटीक पता नहीं। आपकी चेतावनी अगले व्यक्ति को बचा सकती है।',
    'report.time': '60 सेकंड से कम',
    'report.channel.title': 'उन्होंने आपसे कैसे संपर्क किया?',
    'report.channel.sub': 'चैनल चुनें। आइकन अकेले भी काम करते हैं।',
    'report.type.title': 'किस तरह की ठगी?',
    'report.type.sub': 'सबसे करीबी विकल्प चुनें। विवरण बाद में जोड़ सकते हैं।',
    'report.id.title': 'उन्होंने क्या इस्तेमाल किया?',
    'report.id.sub': 'नंबर, UPI ID, लिंक या SMS भेजने वाला। कोई भी फ़ॉर्मैट चलेगा।',
    'report.id.placeholder': '+91 98765 43210, name@okaxis, https://…',
    'report.area.title': 'आप कहाँ हैं?',
    'report.area.sub': 'हम सिर्फ़ क्षेत्र सेव करते हैं — आपकी गली या सटीक लोकेशन कभी नहीं।',
    'report.area.label': 'क्षेत्र',
    'report.area.privacy': 'सिर्फ़ क्षेत्र सेव होता है। नक्शा क्षेत्र के मैप पॉइंट का इस्तेमाल करता है, किसी रिपोर्टर की लोकेशन का नहीं।',
    'report.when.label': 'कब',
    'when.now': 'अभी', 'when.hour': 'पिछले घंटे', 'when.today': 'आज',
    'when.yesterday': 'कल', 'when.custom': 'समय चुनें',
    'report.note.title': 'बताइए क्या हुआ', 'report.note.optional': 'वैकल्पिक',
    'report.note.sub': 'आपके अपने शब्द कॉपी-पेस्ट संदेश से ज़्यादा मदद करते हैं।',
    'report.note.placeholder': 'उन्होंने क्या कहा या भेजा? जो अगले व्यक्ति को पहचानने में मदद करे।',
    'report.note.hint': 'व्यक्तिगत विवरण शिकायत को मज़बूत बनाते हैं',
    'report.screenshot': 'मेरे पास स्क्रीनशॉट है', 'report.amount': 'खोया amount (₹)',
    'report.consent': 'आपकी शिकायत गुमनाम है। हम सिर्फ़ आपका क्षेत्र सेव करते हैं, नाम, फ़ोन नंबर या सटीक लोकेशन नहीं।',
    'report.submit': 'गुमनाम शिकायत पोस्ट करें',
    'report.aside.title': 'आपकी पहचान बाहर रहती है',
    'report.aside.1': 'कोई नाम, फ़ोन नंबर या लॉगिन नहीं',
    'report.aside.2': 'सिर्फ़ क्षेत्र — सटीक लोकेशन कभी नहीं',
    'report.aside.3': 'नोट्स कभी जाँच परिणाम में नहीं दिखते',
    'report.aside.4': '3 लोगों की शिकायत तक नंबर छिपा रहता है',
    'report.aside.next': 'आगे क्या होता है?',
    'report.aside.next1': 'आपकी शिकायत उस पहचान के केस में जुड़ती है।',
    'report.aside.next2': 'भरोसा नियम स्वतंत्रता और गुणवत्ता को स्कोर करते हैं।',
    'report.aside.next3': 'स्वतंत्र रिपोर्ट आंतरिक साक्ष्य को मज़बूत करती हैं, लेकिन केवल रिपोर्ट से पहचान सत्यापित नहीं होती।',
    'report.aside.meter': 'एक शिकायत कभी किसी को सार्वजनिक रूप से नहीं बदनाम करती',
    'success.title': 'धन्यवाद। आपकी रिपोर्ट प्राप्त हुई।',
    'success.sub': 'आपकी शिकायत गुमनाम है। यह अगले व्यक्ति को बचाने में मदद करेगी।',
    'success.case': 'केस', 'success.merged': 'मौजूदा केस में जुड़ी',
    'success.check': 'यह पहचान जाँचें', 'success.again': 'और शिकायत करें',
    'map.eyebrow': 'क्षेत्र-स्तरीय जानकारी', 'map.title': 'ठगी का नक्शा',
    'map.sub': 'पिछले 7 दिन की हर शिकायत, क्षेत्र के हिसाब से। किसी रिपोर्टर की लोकेशन कभी नहीं।',
    'map.window': 'पिछले 7 दिन', 'map.refresh': 'रीफ़्रेश',
    'map.crit': 'गंभीर', 'map.high': 'उच्च', 'map.med': 'मध्यम',
    'map.empty.title': 'इस दृश्य में कोई शिकायत नहीं',
    'map.empty.body': 'दूसरा शहर देखें, या अपने क्षेत्र में पहली शिकायत करें।',
    'map.empty.cta': 'शिकायत करें',
    'map.privacy': 'सिर्फ़ क्षेत्र के मैप पॉइंट। कोई रिपोर्टर निर्देशांक सेव या दिखाया नहीं जाता।',
    'map.select.title': 'क्षेत्र चुनें',
    'map.select.body': 'शिकायतों की संख्या और मुख्य ठगी देखने के लिए मार्कर दबाएँ।',
    'map.list.title': 'शिकायत वाले क्षेत्र',
    'alerts.eyebrow': 'सिर्फ़ जब कुछ असामान्य हो', 'alerts.title': 'अलर्ट',
    'alerts.sub': 'अचानक बढ़ोतरी या बिल्कुल नई ठगी। हर शिकायत पर सूचना नहीं।',
    'alerts.refresh': 'रीफ़्रेश',
    'alerts.how.kicker': 'संकेत, शोर नहीं', 'alerts.how.title': 'अलर्ट कैसे काम करते हैं',
    'alerts.how.spike.title': 'असली बढ़ोतरी',
    'alerts.how.spike.body': '24 घंटे में कम से कम 5 शिकायतें, और पिछले 7 दिन की रोज़ाना औसत से कम से कम दोगुनी।',
    'alerts.how.new.title': 'नया प्रकार',
    'alerts.how.new.body': 'पिछले 24 घंटे में दिखा ठगी का प्रकार जो उस क्षेत्र में 30 दिन से नहीं था।',
    'alerts.how.fake.title': 'फ़र्ज़ी शांत रहते हैं',
    'alerts.how.fake.body': 'भरोसा नियमों से नकारी गई शिकायतें बड़े बर्स्ट में भी अलर्ट नहीं करतीं।',
    'licence.eyebrow': 'प्रीपेड-शैली सर्वर लाइसेंस', 'licence.title': 'लाइसेंस और सर्वर',
    'licence.sub': 'Ed25519 से हस्ताक्षरित, हर अनुरोध पर जाँच, बिना रीस्टार्ट नवीनीकरण।',
    'licence.json': 'GET /license', 'licence.docs': 'API डॉक्स',
    'licence.licensed': 'लाइसेंसधारी', 'licence.remaining': 'शेष',
    'licence.expires': 'समाप्ति', 'licence.server': 'सर्वर समय', 'licence.id': 'लाइसेंस ID',
    'licence.renew.kicker': 'रीस्टार्ट की ज़रूरत नहीं', 'licence.renew.title': 'नया लाइसेंस अपलोड करें',
    'licence.renew.body': 'हस्ताक्षरित JSON फ़ाइल यहाँ छोड़ें। सर्वर हस्ताक्षर जाँचता है और सारी शिकायतें रखता है।',
    'licence.renew.drop': 'लाइसेंस फ़ाइल चुनें', 'licence.renew.drop2': 'या यहाँ खींचकर छोड़ें',
    'licence.renew.verify': 'सर्वर में बिल्ट-in पब्लिक की से हस्ताक्षर जाँचा जाता है।',
    'licence.demo.kicker': 'डेमो टूल', 'licence.demo.title': 'चार-चरण डेमो का अभ्यास करें',
    'licence.demo.badge': 'डेमो मोड',
    'licence.demo.body': 'छोटा लाइसेंस जारी करें, ऐप लॉक होते देखें, फिर नवीनीकरण करें। शिकायतें कभी नहीं मिटतीं।',
    'licence.demo.five': '5 मिनट का लाइसेंस', 'licence.demo.year': '1 साल का लाइसेंस',
    'licence.demo.seed': 'डेमो डेटा लोड करें', 'licence.demo.reset': 'सभी शिकायतें मिटाएँ',
    'licence.demo.note': 'ग्राहक को देने से पहले DEMO_MODE=0 और ALLOW_DEMO_LICENSE_ISSUE=0 से डेमो एंडपॉइंट बंद करें।',
    'licence.steps.kicker': 'जजिंग डेमो', 'licence.steps.title': 'चार चरण, लाइव',
    'licence.steps.1.title': 'ऐप चलता दिखाएँ',
    'licence.steps.1.body': 'GET /license खोलें और दिखाएँ कि लाइसेंस किसके नाम है और कब समाप्त होगा।',
    'licence.steps.2.title': '5 मिनट का लाइसेंस अपलोड करें',
    'licence.steps.2.body': 'उलटी गिनती शुरू होती है। कुछ भी रीस्टार्ट नहीं होता।',
    'licence.steps.3.title': 'जाँच विफल होते देखें',
    'licence.steps.3.body': '/health और /license के अलावा हर API 403 LICENSE_EXPIRED देता है। ऐप लॉक स्क्रीन दिखाता है।',
    'licence.steps.4.title': 'नवीनीकरण करें और जारी रखें',
    'licence.steps.4.body': 'लंबा लाइसेंस अपलोड करें। ऐप एक मिनट में फिर चलता है, पुराना डेटा सुरक्षित।',
    'trust.eyebrow': 'कठिन आधा', 'trust.title': 'हम फ़र्ज़ी शिकायतें कैसे रोकते हैं',
    'trust.sub': 'एक व्यक्ति, एक Wi-Fi या एक कॉपी-पेस्ट संदेश किसी मासूम व्यवसाय को कभी ठग नहीं बना सकता। असली लहर पर भरोसा होना चाहिए।',
    'trust.badge': 'असमान भरोसा',
    'trust.flow.1': 'सामान्य करें', 'trust.flow.1b': 'एक पहचान, हर फ़ॉर्मैट',
    'trust.flow.2': 'स्कोर', 'trust.flow.2b': 'इतिहास, शब्द, नेटवर्क, समय',
    'trust.flow.3': 'समेटें', 'trust.flow.3b': 'एक व्यक्ति एक ही रहता है',
    'trust.flow.4': 'फ़ैसला', 'trust.flow.4b': 'पुष्टि के लिए 3 भरोसेमंद लोग',
    'trust.r1.title': 'एक व्यक्ति, एक शिकायत',
    'trust.r1.body': 'एक ही रिपोर्टर ID की छह शिकायतें एक व्यक्ति मानी जाती हैं। संख्या दिखती है, फ़ैसला अलग पहचानों पर होता है।',
    'trust.r1.tag': 'पहचान समेटना',
    'trust.r2.title': 'एक Wi-Fi, एक व्यक्ति',
    'trust.r2.body': '24 घंटे में एक ही IP प्रीफ़िक्स पर तीन या ज़्यादा रिपोर्टर ID एक पहचान बन जाती हैं। 22 फ़र्ज़ी खाते 1 बनते हैं।',
    'trust.r2.tag': 'नेटवर्क क्लस्टर',
    'trust.r3.title': 'प्रतिष्ठा बढ़ती है',
    'trust.r3.body': 'नए खाते 0.60 से शुरू। जिनकी पुरानी शिकायतों की दूसरों ने पुष्टि की, वे 0.90–1.00 तक। सत्यापित व्यवसायों पर बार-बार शिकायत करने वाले 0.20 तक।',
    'trust.r3.tag': 'रिपोर्टर इतिहास',
    'trust.r4.title': 'अपने शब्द कॉपी-पेस्ट से बेहतर',
    'trust.r4.body': 'विस्तृत, व्यक्तिगत नोट्स 0.95 तक। खाली नोट 0.50। हूबहू या लगभग-हूबहू नोट 0.12। बेकार नोट 0.08।',
    'trust.r4.tag': 'नोट गुणवत्ता',
    'trust.r5.title': 'बर्स्ट संदिग्ध हैं, सबूत नहीं',
    'trust.r5.body': 'स्क्रिप्टेड नोट्स वाले नए खातों का अचानक बर्स्ट कम भार पाता है। विस्तृत, अलग-अलग नोट्स वाली असली लहर गिनती है।',
    'trust.r5.tag': 'समन्वय संकेत',
    'trust.r6.title': 'बेकार कुछ अंदर नहीं',
    'trust.r6.body': '“12345”, “test”, दोहराए अंक और गलत लिंक स्कोरिंग से पहले 400 से नकारे जाते हैं। अज्ञात प्रकार “other” बनते हैं।',
    'trust.r6.tag': 'सत्यापन',
    'trust.threshold.kicker': 'फ़ैसला', 'trust.threshold.title': 'चार संभावित नतीजे',
    'trust.v.known': 'स्वतंत्र साक्ष्य आंतरिक विश्वसनीयता स्कोर में योगदान देता है',
    'trust.v.knownb': 'पूरा नंबर दिखता है। सुरक्षा सलाह और सबूत टाइमलाइन।',
    'trust.v.sus': 'शिकायतें हैं, पर स्वतंत्र भरोसा काफ़ी नहीं',
    'trust.v.susb': '3 अलग लोगों की शिकायत तक नंबर छिपा रहता है।',
    'trust.v.none': 'किसी ने इस पहचान की शिकायत नहीं की',
    'trust.v.noneb': 'फिर भी कोई गारंटी नहीं। आधिकारिक चैनल से जाँचें।',
    'trust.v.ver': 'स्वतंत्र रूप से सत्यापित संपर्क या व्यवसाय',
    'trust.v.verb': 'सत्यापन विश्वसनीय रजिस्ट्री से होता है, रिपोर्ट की संख्या से नहीं।',
    'trust.privacy.kicker': 'गैर-समझौता', 'trust.privacy.title': 'गोपनीयता वचन',
    'trust.p1': 'रिपोर्टर गुमनाम रहते हैं। नाम, फ़ोन नंबर या सटीक लोकेशन सेव नहीं होती।',
    'trust.p2': 'कम से कम 3 विश्वसनीय और स्वतंत्र रिपोर्टर साक्ष्य का समर्थन करें, तब तक नंबर छिपे रहते हैं।',
    'trust.p3': 'ऐप कहता है “रिपोर्ट हुआ”, कभी नहीं “यह व्यक्ति ठग है”।',
    'trust.p4': 'सोशल मीडिया या पीपल-सर्च साइट से कोई व्यक्तिगत डेटा नहीं उठाया जाता।',
    'trust.p5': 'एक्सेस लॉग बंद हैं ताकि जाँच URL कभी फ़ोन नंबर डिस्क पर न लिखें।',
    'trust.try.kicker': 'खुद देखें', 'trust.try.title': 'डेमो परिदृश्य आज़माएँ',
    'trust.try.body': 'डेमो डेटा लोड करें, फिर ये पहचानें जाँचें। बॉम्बिंग टारगेट पर 18 शिकायतें हैं पर सिर्फ़ एक व्यक्ति।',
    'footer.love': 'सुरक्षित समुदायों के लिए बनाया गया। डिज़ाइन से ही गुमनाम।', 'footer.trust': 'भरोसे के नियम',
    'verdict.known': 'ज्ञात ठगी', 'verdict.suspicious': 'संदिग्ध', 'verdict.none': 'अभी कोई शिकायत नहीं',
    'verdict.verified': 'सत्यापित',
    'verdict.known.sub': 'आपके पास {n} लोगों ने शिकायत की',
    'verdict.suspicious.sub': '{n} लोगों ने शिकायत की, पर पुष्टि के लिए स्वतंत्र भरोसा काफ़ी नहीं।',
    'verdict.suspicious.challenged': 'किसी व्यवसाय ने इस लिस्टिंग पर आपत्ति की है। समीक्षा चल रही है।',
    'verdict.none.sub': 'इस समुदाय में किसी ने अभी इस पहचान की शिकायत नहीं की। सावधान रहें।',
    'verdict.verified.sub': 'सत्यापित व्यवसाय या हेल्पलाइन। आधिकारिक चैनल से जाँचते रहें।',
    'result.reports': 'शिकायतें', 'result.people': 'अलग लोग', 'result.trusted': 'भरोसेमंद',
    'result.lastseen': 'अंतिम बार', 'result.hidden': '3 अलग लोगों की शिकायत तक छिपा',
    'result.report': 'इसकी शिकायत करें', 'result.challenge': 'यह मेरा व्यवसाय है', 'result.copy': 'चेतावनी कॉपी करें',
    'result.evidence': 'हाल के सबूत', 'result.privacy': 'रिपोर्टर के नाम, नोट्स या सटीक लोकेशन कभी नहीं दिखते।',
    'result.noevidence': 'अभी कोई सार्वजनिक सबूत नहीं।',
    'result.checked': 'आपने जाँचा', 'result.copied': 'चेतावनी क्लिपबोर्ड पर कॉपी हुई',
    'result.challenge.banner': 'व्यवसाय की आपत्ति के बाद यह लिस्टिंग समीक्षा में है।',
    'scam.other': 'अन्य', 'channel.phone': 'फ़ोन कॉल', 'channel.sms': 'SMS या WhatsApp',
    'channel.qr': 'QR कोड', 'channel.website': 'फ़र्ज़ी वेबसाइट', 'channel.upi': 'UPI अनुरोध',
    'channel.other': 'कुछ और',
    'toast.lookup.failed': 'जाँच विफल। फिर कोशिश करें।',
    'toast.invalid': 'पहचान जाँचें और फिर कोशिश करें।',
    'toast.rate': 'इस डिवाइस से बहुत ज़्यादा शिकायतें। कुछ मिनट रुकें।',
    'toast.report.ok': 'शिकायत गुमनाम रूप से पोस्ट हुई। धन्यवाद।',
    'toast.report.dup': 'यह शिकायत पहले मिल चुकी है।',
    'toast.license.ok': 'लाइसेंस इंस्टॉल हुआ। एक्सेस लाइव है।',
    'toast.license.bad': 'वह लाइसेंस सत्यापित नहीं हो सका।',
    'toast.license.expired': 'लाइसेंस स्वीकार हुआ, पर पहले ही समाप्त है।',
    'toast.seed.ok': 'डेमो डेटा लोड हुआ।',
    'toast.reset.ok': 'सभी शिकायतें मिट गईं।',
    'toast.challenge.ok': 'आपत्ति मिली। लिस्टिंग समीक्षा में है।',
    'toast.demo.off': 'इस सर्वर पर डेमो टूल बंद हैं।',
    'toast.copy.fail': 'कॉपी नहीं हो सका। टेक्स्ट चुनकर कॉपी करें।',
    'toast.area.saved': 'क्षेत्र इस डिवाइस पर सेव हुआ।',
    'toast.required': 'कृपया ज़रूरी फ़ील्ड भरें।',
    'toast.allquiet': 'अभी कोई असामान्य पैटर्न नहीं।',
    'error.title': 'यह काम नहीं आया',
    'empty.feed': 'पिछले 7 दिनों में अभी कोई शिकायत नहीं।',
    'empty.alerts': 'सब शांत। अलर्ट सिर्फ़ असली बढ़ोतरी या नई ठगी पर आते हैं।',
    'empty.map': 'इस दृश्य में शिकायत वाला कोई क्षेत्र नहीं।',
    'license.no': 'कोई लाइसेंस नहीं', 'license.valid': 'लाइसेंस वैध',
    'license.expired': 'लाइसेंस समाप्त', 'license.clock': 'क्लॉक रोलबैक मिला',
    'license.invalid': 'अमान्य लाइसेंस', 'license.missing': 'लाइसेंस गायब',
    'overlay.expired.title': 'लाइसेंस समाप्त',
    'overlay.expired.text': 'यह सर्वर लॉक है। /health और /license के अलावा हर API 403 देता है। आपकी शिकायतें सुरक्षित हैं, कुछ नहीं मिटा।',
    'overlay.missing.title': 'कोई लाइसेंस इंस्टॉल नहीं',
    'overlay.missing.text': 'सर्वर खोलने के लिए हस्ताक्षरित लाइसेंस अपलोड करें। मौजूदा डेटा सुरक्षित है।',
    'overlay.invalid.title': 'लाइसेंस हस्ताक्षर अमान्य',
    'overlay.invalid.text': 'फ़ाइल भरोसेमंद की से हस्ताक्षरित नहीं है। सही लाइसेंस जाँचें।',
    'overlay.clock.title': 'सर्वर घड़ी पीछे गई',
    'overlay.clock.text': 'सर्वर ने क्लॉक रोलबैक पकड़ा। हाई-वॉटर मार्क साफ़ करने और एक्सेस लौटाने के लिए वैध लाइसेंस अपलोड करें।',
    'overlay.upload': 'नया लाइसेंस अपलोड करें', 'overlay.issue': '5 मिनट का डेमो लाइसेंस',
    'overlay.retry': 'फिर कोशिश करें', 'overlay.safe': 'डेटा सुरक्षित है। वैध लाइसेंस बिना रीस्टार्ट एक्सेस लौटाता है।',
    'challenge.title': 'यह मेरा व्यवसाय है',
    'challenge.sub': 'बताएँ क्या गलत है। कुछ बदलने से पहले हर आपत्ति इंसान जाँचता है।',
    'challenge.name': 'आपका नाम', 'challenge.email': 'संपर्क ईमेल',
    'challenge.proof': 'हमें क्या जानना चाहिए?',
    'challenge.proof.placeholder': 'व्यवसाय पंजीकरण, आधिकारिक नंबर, या यह लिस्टिंग क्यों गलत है।',
    'challenge.cancel': 'रद्द करें', 'challenge.submit': 'आपत्ति भेजें',
    'confirm.reset.title': 'सभी शिकायतें मिटाएँ?',
    'confirm.reset.text': 'यह डेमो डेटाबेस से हर शिकायत, केस और आपत्ति हटाता है। लाइसेंस और की सुरक्षित रहते हैं। इसे वापस नहीं लाया जा सकता।',
    'confirm.seed.title': 'डेमो शिकायतों से डेटा बदलें?',
    'confirm.seed.text': 'यह मौजूदा डेटाबेस साफ़ कर 115-शिकायत वाला डेमो सेट लोड करता है। लाइसेंस सुरक्षित रहता है।',
    'confirm.delete': 'हाँ, डेटा बदलें', 'confirm.cancel': 'रद्द करें',
    'map.detail.reports': 'शिकायतें', 'map.detail.people': 'लोग', 'map.detail.top': 'मुख्य प्रकार',
    'map.detail.alerts': 'अलर्ट देखें', 'map.detail.report': 'यहाँ शिकायत करें',
    'alerts.summary.one': '1 असामान्य पैटर्न मिला', 'alerts.summary.many': '{n} असामान्य पैटर्न मिले',
    'alerts.summary.quiet': 'अभी सब शांत',
    'alerts.summary.body': 'अलर्ट सिर्फ़ असली बढ़ोतरी और बिल्कुल नई ठगी पर आते हैं।',
    'alerts.spike.title': '{area} में शिकायतें दोगुनी',
    'alerts.spike.body': 'पिछले 24 घंटे में {n} शिकायतें — 7 दिन का औसत {base} प्रति दिन।',
    'alerts.new.title': 'नई ठगी: {type}',
    'alerts.new.body': '{area} में पिछले 24 घंटे में पहली बार। पिछले 30 दिन में वहाँ यह प्रकार नहीं था।',
    'alerts.count': '24 घंटे की शिकायतें', 'alerts.baseline': 'औसत / दिन', 'alerts.window': 'अवधि',
    'alerts.type': 'प्रकार', 'alerts.area': 'क्षेत्र', 'alerts.view': 'क्षेत्र देखें',
    'map.all': 'पूरा भारत', 'map.city': 'शहर', 'map.report.count': '{n} शिकायतें',
    'feed.across': '{n} क्षेत्रों में', 'feed.reports': '{n} शिकायतें',
    'license.countdown': 'शेष', 'license.demo': 'डेमो मोड',
  },
};

/* ------------------------------------------------------------------
   Small helpers
   ------------------------------------------------------------------ */

function t(key, vars) {
  const table = I18N[state.lang] || I18N.en;
  let value = table[key];
  if (value === undefined) value = I18N.en[key];
  if (value === undefined) return key;
  if (vars) {
    for (const [name, replacement] of Object.entries(vars)) {
      value = value.split(`{${name}}`).join(String(replacement));
    }
  }
  return value;
}

function applyI18n() {
  document.documentElement.lang = state.lang === 'hi' ? 'hi' : 'en';
  $$('[data-i18n]').forEach((element) => {
    const value = t(element.dataset.i18n);
    if (value && value !== element.dataset.i18n) element.textContent = value;
  });
  $$('[data-i18n-html]').forEach((element) => {
    const value = t(element.dataset.i18nHtml);
    if (value && value !== element.dataset.i18nHtml) element.innerHTML = value;
  });
  $$('[data-i18n-placeholder]').forEach((element) => {
    const value = t(element.dataset.i18nPlaceholder);
    if (value && value !== element.dataset.i18nPlaceholder) element.placeholder = value;
  });
  const label = $('#lang-label');
  if (label) label.textContent = state.lang === 'hi' ? 'EN' : 'हिं';
  document.title = state.lang === 'hi' ? 'ScamMap — भरोसे से पहले जाँचें' : 'ScamMap — Check before you trust';
}

function escapeHtml(value) {
  return String(value === null || value === undefined ? '' : value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[character]));
}

function icon(name, className = 'icon') {
  return `<svg class="${className}" aria-hidden="true"><use href="#${name}"></use></svg>`;
}

function formatDate(value, short = false) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  const locale = state.lang === 'hi' ? 'hi-IN' : undefined;
  const options = short
    ? { day: 'numeric', month: 'short' }
    : { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' };
  try {
    return new Intl.DateTimeFormat(locale, options).format(date);
  } catch (_error) {
    return date.toLocaleString();
  }
}

function formatCountdown(seconds) {
  let total = Math.max(0, Math.floor(Number(seconds) || 0));
  const days = Math.floor(total / 86400);
  total %= 86400;
  const hours = Math.floor(total / 3600);
  total %= 3600;
  const minutes = Math.floor(total / 60);
  const secs = total % 60;
  if (days > 0) return `${days}d ${String(hours).padStart(2, '0')}h`;
  if (hours > 0) return `${hours}h ${String(minutes).padStart(2, '0')}m`;
  return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function plural(count, singular, pluralWord) {
  return count === 1 ? singular : (pluralWord || `${singular}s`);
}

function setBusy(button, busy, busyLabel) {
  if (!button) return;
  if (busy) {
    if (!button.dataset.originalHtml) button.dataset.originalHtml = button.innerHTML;
    button.disabled = true;
    button.innerHTML = `<span class="loading-spinner"></span><span>${escapeHtml(busyLabel || 'Working…')}</span>`;
  } else {
    button.disabled = false;
    if (button.dataset.originalHtml) {
      button.innerHTML = button.dataset.originalHtml;
      delete button.dataset.originalHtml;
    }
  }
}

/* ------------------------------------------------------------------
   API + UI primitives
   ------------------------------------------------------------------ */

const LICENSE_ERRORS = new Set([
  'LICENSE_EXPIRED', 'LICENSE_MISSING', 'LICENSE_INVALID', 'CLOCK_ROLLBACK',
  'EXPIRED', 'MISSING', 'INVALID',
]);

async function api(path, options = {}) {
  const request = { ...options, headers: { ...(options.headers || {}) } };
  if (request.body && typeof request.body !== 'string') {
    request.body = JSON.stringify(request.body);
    request.headers['Content-Type'] = 'application/json';
  }
  let response;
  try {
    response = await fetch(path, request);
  } catch (_error) {
    const networkError = new Error('Network unavailable');
    networkError.status = 0;
    throw networkError;
  }

  let data = null;
  try {
    data = await response.json();
  } catch (_error) {
    data = null;
  }

  if (!response.ok) {
    const code = data && data.error ? String(data.error) : '';
    if (response.status === 403 && LICENSE_ERRORS.has(code)) {
      showLicenseOverlay(code);
    }
    let message = (data && data.message) || code || (data && data.detail ? data.detail : `Request failed (${response.status})`);
    if (typeof message !== 'string') message = JSON.stringify(message);
    const error = new Error(message);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

function toast(message, type = 'info', iconName = 'i-info') {
  const root = $('#toast-root');
  if (!root) return;
  const element = document.createElement('div');
  element.className = `toast ${type}`;
  element.innerHTML = `${icon(iconName)}<span>${escapeHtml(message)}</span>`;
  root.appendChild(element);
  window.setTimeout(() => {
    element.style.opacity = '0';
    element.style.transform = 'translateY(6px)';
    window.setTimeout(() => element.remove(), 220);
  }, 4200);
}

function openModal(html) {
  const root = $('#modal-root');
  if (!root) return;
  root.innerHTML = `<div class="modal-card glass">${html}</div>`;
  root.hidden = false;
  document.body.style.overflow = 'hidden';
  root.onclick = (event) => {
    if (event.target === root || event.target.closest('[data-close]')) closeModal();
  };
}

function closeModal() {
  const root = $('#modal-root');
  if (!root) return;
  root.hidden = true;
  root.innerHTML = '';
  document.body.style.overflow = '';
}

function confirmAction(title, text, confirmLabel, onConfirm) {
  const id = `confirm-${Date.now()}`;
  openModal(`
    <div class="modal-head">
      <div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(text)}</p></div>
      <button class="modal-close" data-close aria-label="Close">${icon('i-x')}</button>
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" data-close>${escapeHtml(t('confirm.cancel'))}</button>
      <button class="btn btn-primary" id="${id}-yes">${escapeHtml(confirmLabel)}</button>
    </div>
  `);
  const button = $(`#${id}-yes`);
  if (button) {
    button.onclick = async () => {
      closeModal();
      try {
        await onConfirm();
      } catch (error) {
        toast(error.message || t('toast.lookup.failed'), 'error', 'i-alert');
      }
    };
  }
}

function licenseCode(code) {
  const raw = String(code || '').toUpperCase();
  if (raw.includes('CLOCK')) return 'CLOCK_ROLLBACK';
  if (raw.includes('MISSING')) return 'MISSING';
  if (raw.includes('INVALID')) return 'INVALID';
  if (raw.includes('EXPIRED')) return 'EXPIRED';
  return raw || 'EXPIRED';
}

function showLicenseOverlay(code) {
  const root = $('#license-overlay');
  if (!root) return;
  const normalized = licenseCode(code);
  const mapping = {
    EXPIRED: { title: t('overlay.expired.title'), text: t('overlay.expired.text') },
    MISSING: { title: t('overlay.missing.title'), text: t('overlay.missing.text') },
    INVALID: { title: t('overlay.invalid.title'), text: t('overlay.invalid.text') },
    CLOCK_ROLLBACK: { title: t('overlay.clock.title'), text: t('overlay.clock.text') },
  };
  const copy = mapping[normalized] || mapping.EXPIRED;
  const title = $('#overlay-title');
  const text = $('#overlay-text');
  const badge = $('#overlay-badge');
  if (title) title.textContent = copy.title;
  if (text) text.textContent = copy.text;
  if (badge) badge.textContent = normalized === 'EXPIRED' ? 'LICENSE_EXPIRED' : `LICENSE_${normalized}`;
  const issue = $('#overlay-issue');
  if (issue) issue.hidden = !(state.meta && state.meta.allow_demo_license_issue);
  const error = $('#overlay-error');
  if (error) error.hidden = true;
  root.hidden = false;
}

function hideLicenseOverlay() {
  const root = $('#license-overlay');
  if (root) root.hidden = true;
}

/* ------------------------------------------------------------------
   Labels + lookup
   ------------------------------------------------------------------ */

function scamEntry(id) {
  if (!state.meta || !Array.isArray(state.meta.scam_types)) return null;
  return state.meta.scam_types.find((entry) => entry.id === id) || null;
}

function scamLabel(id) {
  const entry = scamEntry(id);
  if (!entry) return id === 'other' ? t('scam.other') : (id || t('scam.other'));
  return state.lang === 'hi' ? (entry.hindi || entry.label) : entry.label;
}

function scamIcon(id) {
  const mapping = {
    'digital-arrest': 'i-shield', 'fake-kyc-link': 'i-link', 'upi-refund-qr': 'i-qr',
    'investment-group': 'i-trend', 'courier-customs': 'i-package', 'job-offer': 'i-briefcase',
    'lottery-prize': 'i-gift', 'loan-app-harassment': 'i-smartphone',
    'electricity-disconnection': 'i-zap', 'fake-customer-care': 'i-headset',
    'otp-call': 'i-key', 'sextortion': 'i-video', 'other': 'i-dots',
  };
  return mapping[id] || 'i-dots';
}

function channelIcon(channel) {
  const mapping = {
    'Phone call': 'i-phone', 'SMS or WhatsApp': 'i-message', 'QR code': 'i-qr',
    'Fake website': 'i-globe', 'UPI request': 'i-card', 'Something else': 'i-dots',
  };
  return mapping[channel] || 'i-dots';
}

function channelLabel(channel) {
  const mapping = {
    'Phone call': 'channel.phone', 'SMS or WhatsApp': 'channel.sms', 'QR code': 'channel.qr',
    'Fake website': 'channel.website', 'UPI request': 'channel.upi', 'Something else': 'channel.other',
  };
  return mapping[channel] ? t(mapping[channel]) : (channel || t('channel.other'));
}

function detectType(value) {
  const text = String(value || '').trim();
  if (!text) return 'phone';
  if (/^https?:\/\//i.test(text)) return 'url';
  if (text.includes('@') && !text.includes('://')) return 'upi';
  if (/^[+\d][\d\s().-]*$/.test(text)) return 'phone';
  if (/[a-z0-9-]+\.[a-z]{2,}(\/|$|\?)/i.test(text)) return 'url';
  if (/^[A-Za-z0-9][A-Za-z0-9 _-]{4,11}$/.test(text)) return 'sender_id';
  return 'phone';
}

function verdictMeta(verdict, data) {
  const count = Number(data.report_count || 0);
  if (data.evidence_filtered) {
    return {
      key: 'none', label: 'NO RECORDS FOUND', icon: 'i-eyeoff',
      sub: 'Community submissions were received, but their screenshot evidence could not be verified as matching the reported number.',
    };
  }
  if (verdict === 'VERIFIED' || verdict === 'VERIFIED_BUSINESS') {
    const verified = data.verified_business ? `${data.verified_business}. ` : '';
    return {
      key: 'verified', label: 'VERIFIED', icon: 'i-shieldcheck',
      sub: `${verified}Independently verified contact.`,
    };
  }
  if (verdict === 'NOT_VERIFIED' || verdict === 'SUSPICIOUS' || verdict === 'KNOWN_SCAM') {
    return {
      key: 'unverified', label: 'NOT VERIFIED', icon: 'i-help',
      sub: `${count} community report${count === 1 ? '' : 's'} received. Reports alone do not establish that this identifier is a scam.`,
    };
  }
  return {
    key: 'none', label: t('verdict.none'), icon: 'i-checkcircle',
    sub: t('verdict.none.sub'),
  };
}


function renderUrlIntelligence(intel) {
  const status = String(intel.status || 'unknown');
  const risk = String(intel.risk || 'UNKNOWN');
  const evidence = intel.evidence || {};
  const title = status === 'success'
    ? `VirusTotal · ${risk.replaceAll('_', ' ')}`
    : status === 'pending'
      ? 'VirusTotal · Analysis pending'
      : status === 'not_configured'
        ? 'VirusTotal · Not configured'
        : 'VirusTotal · Temporarily unavailable';
  const metrics = status === 'success' ? `
    <div class="result-stats">
      <div class="stat"><span>Malicious</span><strong>${Number(evidence.malicious || 0)}</strong></div>
      <div class="stat"><span>Suspicious</span><strong>${Number(evidence.suspicious || 0)}</strong></div>
      <div class="stat"><span>Phishing indicators</span><strong>${Number(evidence.phishing || 0)}</strong></div>
      <div class="stat"><span>Harmless</span><strong>${Number(evidence.harmless || 0)}</strong></div>
    </div>` : '';
  const riskClass = risk === 'HIGH' ? 'verdict-suspicious' : 'verdict-none';
  return `
    <section class="evidence-block vt-intelligence ${riskClass}">
      <h3>${escapeHtml(title)}</h3>
      ${metrics}
      <p>${escapeHtml(intel.message || 'No additional URL intelligence is available.')}</p>
      ${status === 'success' ? `<small>Source: VirusTotal · ${Number(intel.total_engines || 0)} engine results. External intelligence is supporting evidence, not a guarantee.</small>` : ''}
    </section>`;
}

function renderLookupResult(data, searchedValue) {
  const slot = $('#lookup-result');
  if (!slot) return;
  const verdict = data.verdict || 'NO_REPORTS';
  const meta = verdictMeta(verdict, data);
  const canonical = data.normalized_value || searchedValue || '';
  const display = data.display_value || canonical;
  const advice = data.advice || { title: 'Stay careful', steps: [] };
  const steps = Array.isArray(advice.steps) ? advice.steps : [];
  const evidence = Array.isArray(data.evidence) ? data.evidence : [];
  const stats = [
    [t('result.reports'), Number(data.report_count || 0)],
    [t('result.people'), Number(data.distinct_reporters || 0)],
    [t('result.trusted'), Number(data.trusted_reporters || 0)],
    [t('result.lastseen'), data.last_seen ? formatDate(data.last_seen) : '—'],
  ];
  const statHtml = stats.map(([label, value]) => `
    <div class="stat"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>
  `).join('');
  const evidenceHtml = evidence.length
    ? evidence.slice(0, 5).map((item) => `
      <div class="evidence-item">
        <span class="evidence-icon">${icon(channelIcon(item.channel))}</span>
        <div class="evidence-meta">
          <strong>${escapeHtml(scamLabel(item.scam_type))}</strong>
          <span>${escapeHtml(channelLabel(item.channel))} · ${escapeHtml(item.pincode || '')}</span>
        </div>
        <span class="evidence-date">${escapeHtml(formatDate(item.occurred_at, true))}</span>
      </div>
    `).join('')
    : `<div class="evidence-item"><span class="evidence-icon">${icon('i-eyeoff')}</span><div class="evidence-meta"><strong>${escapeHtml(t('result.noevidence'))}</strong><span>${escapeHtml(t('result.privacy'))}</span></div></div>`;

  const hiddenBadge = data.hidden
    ? `<span class="hidden-badge">${icon('i-eyeoff')}<span>${escapeHtml(t('result.hidden'))}</span></span>`
    : '';
  const challengeBanner = data.challenged
    ? `<div class="challenge-banner">${icon('i-scale')}<span>${escapeHtml(t('result.challenge.banner'))}</span></div>`
    : '';
  const warningText = `${t('result.report')}: ${display} — ${meta.label}. ${advice.title || ''}`.trim();

  slot.innerHTML = `
    <article class="glass verdict-card verdict-${meta.key}" data-verdict="${escapeHtml(verdict)}">
      <div class="verdict-head">
        <div class="verdict-icon">${icon(meta.icon)}</div>
        <div class="verdict-title-wrap">
          <div class="verdict-kicker">${escapeHtml(t('top.check'))}</div>
          <h2>${escapeHtml(meta.label)}</h2>
          <p class="verdict-sub">${escapeHtml(meta.sub)}</p>
        </div>
        <span class="verdict-pill">${escapeHtml(verdict)}</span>
      </div>
      <div class="result-body">
        <div class="result-value-row">
          <div>
            <span class="label">${escapeHtml(data.identifier_type || 'identifier')}</span>
            <code class="result-value">${escapeHtml(display)}</code>
          </div>
          ${hiddenBadge}
        </div>
        <div class="result-stats">${statHtml}</div>
        ${challengeBanner}
        <div class="advice-box">
          <div class="advice-head">${icon(meta.icon)}<h3>${escapeHtml(advice.title || 'Stay careful')}</h3></div>
          <ol>${steps.map((step) => `<li>${escapeHtml(step)}</li>`).join('')}</ol>
        </div>
        <div class="evidence-block">
          <h3>${escapeHtml(t('result.evidence'))}</h3>
          <div class="evidence-list">${evidenceHtml}</div>
        </div>
        ${data.url_intelligence ? renderUrlIntelligence(data.url_intelligence) : ''}
        <div class="result-actions">
          <button class="btn btn-secondary btn-sm" data-action="prefill" data-type="${escapeHtml(data.identifier_type || '')}" data-value="${escapeHtml(canonical)}" data-scam="${escapeHtml(data.scam_type || '')}">${icon('i-plus')}<span>${escapeHtml(t('result.report'))}</span></button>
          <button class="btn btn-ghost btn-sm" data-action="challenge" data-type="${escapeHtml(data.identifier_type || '')}" data-value="${escapeHtml(canonical)}">${icon('i-scale')}<span>${escapeHtml(t('result.challenge'))}</span></button>
          <button class="btn btn-ghost btn-sm" data-action="copy" data-copy="${escapeHtml(warningText)}">${icon('i-copy')}<span>${escapeHtml(t('result.copy'))}</span></button>
        </div>
        <div class="result-privacy">${icon('i-eyeoff')}<span>${escapeHtml(t('result.privacy'))}</span></div>
      </div>
    </article>
  `;
}

function renderLookupError(message) {
  const slot = $('#lookup-result');
  if (!slot) return;
  slot.innerHTML = `
    <div class="glass verdict-card verdict-suspicious">
      <div class="verdict-head">
        <div class="verdict-icon">${icon('i-xcircle')}</div>
        <div class="verdict-title-wrap">
          <div class="verdict-kicker">${escapeHtml(t('error.title'))}</div>
          <h2>${escapeHtml(message || t('toast.lookup.failed'))}</h2>
          <p class="verdict-sub">${escapeHtml(t('toast.invalid'))}</p>
        </div>
      </div>
      <div class="result-body">
        <div class="result-actions">
          <button class="btn btn-secondary btn-sm" data-action="retry">${icon('i-refresh')}<span>${escapeHtml(t('overlay.retry'))}</span></button>
          <button class="btn btn-ghost btn-sm" data-action="prefill" data-type="auto" data-value="">${icon('i-plus')}<span>${escapeHtml(t('result.report'))}</span></button>
        </div>
      </div>
    </div>
  `;
}

async function runSmsLookup(rawMessage) {
  const message = String(rawMessage || '').trim();
  if (!message) { toast(t('toast.required'), 'info', 'i-info'); return; }
  const button = $('#sms-lookup-submit');
  const slot = $('#lookup-result');
  setBusy(button, true, 'Analyse SMS');
  try {
    const data = await api(`/lookup?message=${encodeURIComponent(message)}`);
    const identifiers = (data.extracted_identifiers || []).map((item) => `${item.type}: ${item.value}`);
    if (slot) slot.innerHTML = `
      <div class="glass verdict-card verdict-none">
        <div class="verdict-head"><div class="verdict-icon">${icon('i-shieldcheck')}</div><div class="verdict-title-wrap"><div class="verdict-kicker">SMS analysis</div><h2>${data.similar_messages ? `${data.similar_messages} similar report(s) found` : 'NO RECORDS FOUND'}</h2><p class="verdict-sub">${escapeHtml(data.disclaimer || '')}</p></div></div>
        <div class="result-body"><h3>Extracted identifiers</h3>${identifiers.length ? `<ul>${identifiers.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ul>` : '<p>No supported URL, phone number, UPI ID or sender ID was detected.</p>'}<p><strong>Screening result:</strong> ${escapeHtml(data.risk_hint || 'UNKNOWN')}</p>${(data.matches || []).length ? `<p>Matched campaign references: ${(data.matches || []).map((item) => escapeHtml(item.case_id)).join(', ')}</p>` : ''}</div>
      </div>`;
  } catch (error) {
    if (slot) slot.innerHTML = `<div class="glass card"><p>${escapeHtml(error.message || 'SMS analysis failed.')}</p></div>`;
  } finally { setBusy(button, false); }
}

async function runLookup(rawValue, rawType) {
  const value = String(rawValue || '').trim();
  if (!value) {
    toast(t('toast.required'), 'info', 'i-info');
    return;
  }
  const type = rawType || state.lookupType || 'auto';
  state.lastLookup = { value, type };
  const slot = $('#lookup-result');
  if (slot) {
    slot.innerHTML = `
      <div class="glass verdict-card verdict-none">
        <div class="verdict-head">
          <div class="verdict-icon">${icon('i-search')}</div>
          <div class="verdict-title-wrap">
            <div class="verdict-kicker">${escapeHtml(t('top.check'))}</div>
            <h2>${escapeHtml(t('check.button'))}…</h2>
            <p class="verdict-sub">${escapeHtml(t('check.private'))}</p>
          </div>
        </div>
        <div class="result-body"><div class="skeleton-row"></div></div>
      </div>
    `;
  }
  const button = $('#lookup-submit');
  setBusy(button, true, t('check.button'));
  try {
    const query = new URLSearchParams({ value });
    if (type !== 'auto') query.set('type', type);
    const data = await api(`/lookup?${query.toString()}`);
    state.lastLookup = { value, type: data.identifier_type || type };
    renderLookupResult(data, value);
    addRecent(value, data.identifier_type || type, data.verdict);
  } catch (error) {
    if (error.status === 429) {
      toast(error.message || t('toast.rate'), 'error', 'i-alert');
      if (error.data && error.data.error === 'DAILY_SESSION_LIMIT') {
        renderReportQuota(error.data.used || 5, error.data.limit || 5, 0);
      }
    } else if (error.status === 400) {
      renderLookupError(error.message);
      toast(error.message || t('toast.invalid'), 'error', 'i-alert');
    } else if (error.status !== 403) {
      renderLookupError(t('toast.lookup.failed'));
      toast(t('toast.lookup.failed'), 'error', 'i-alert');
    }
  } finally {
    setBusy(button, false);
  }
}

function addRecent(value, type, verdict) {
  state.recent = state.recent.filter((item) => !(item.value === value && item.type === type));
  state.recent.unshift({ value, type, verdict });
  state.recent = state.recent.slice(0, 5);
  renderRecent();
}

function renderRecent() {
  const wrap = $('#recent-checks');
  const list = $('#recent-list');
  if (!wrap || !list) return;
  if (!state.recent.length) {
    wrap.hidden = true;
    return;
  }
  wrap.hidden = false;
  list.innerHTML = state.recent.map((item) => {
    const dot = (item.verdict === 'VERIFIED' || item.verdict === 'VERIFIED_BUSINESS') ? 'verified'
      : (item.verdict === 'NOT_VERIFIED' || item.verdict === 'SUSPICIOUS' || item.verdict === 'KNOWN_SCAM') ? 'high' : 'none';
    const shown = item.value.length > 22 ? `${item.value.slice(0, 19)}…` : item.value;
    return `<button class="recent-chip" data-recent-type="${escapeHtml(item.type)}" data-recent-value="${escapeHtml(item.value)}"><i class="dot ${dot}"></i> ${escapeHtml(shown)}</button>`;
  }).join('');
}

async function copyText(text) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
    } else {
      const area = document.createElement('textarea');
      area.value = text;
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      document.execCommand('copy');
      area.remove();
    }
    toast(t('result.copied'), 'success', 'i-copy');
  } catch (_error) {
    toast(t('toast.copy.fail'), 'error', 'i-alert');
  }
}

function prefillReport(type, value, scam) {
  state.reportType = type && type !== 'auto' ? type : detectType(value);
  state.report.channel = state.report.channel || 'Phone call';
  if (scam) state.report.scam = scam;
  const input = $('#report-identifier');
  if (input) input.value = value || '';
  go('report');
  renderReportForm();
  window.setTimeout(() => {
    const note = $('#report-note');
    if (note) note.focus({ preventScroll: true });
  }, 250);
}

function openChallengeModal(type, value) {
  openModal(`
    <div class="modal-head">
      <div><h3>${escapeHtml(t('challenge.title'))}</h3><p>${escapeHtml(t('challenge.sub'))}</p></div>
      <button class="modal-close" data-close aria-label="Close">${icon('i-x')}</button>
    </div>
    <form class="modal-form" id="challenge-form">
      <label class="field"><span>${escapeHtml(t('challenge.name'))}</span><input id="challenge-name" maxlength="200" required></label>
      <label class="field"><span>${escapeHtml(t('challenge.email'))}</span><input id="challenge-email" type="email" maxlength="320" required></label>
      <label class="field"><span>${escapeHtml(t('challenge.proof'))}</span><textarea id="challenge-proof" rows="3" maxlength="2000" placeholder="${escapeHtml(t('challenge.proof.placeholder'))}"></textarea></label>
      <div class="result-value-row"><div><span class="label">${escapeHtml(type || 'identifier')}</span><code class="result-value">${escapeHtml(value || '')}</code></div></div>
      <div class="inline-error" id="challenge-error" hidden></div>
      <div class="modal-actions">
        <button type="button" class="btn btn-secondary" data-close>${escapeHtml(t('challenge.cancel'))}</button>
        <button type="submit" class="btn btn-primary" id="challenge-submit">${icon('i-scale')}<span>${escapeHtml(t('challenge.submit'))}</span></button>
      </div>
    </form>
  `);
  const form = $('#challenge-form');
  if (!form) return;
  form.onsubmit = async (event) => {
    event.preventDefault();
    const name = $('#challenge-name').value.trim();
    const email = $('#challenge-email').value.trim();
    const proof = $('#challenge-proof').value.trim();
    const errorBox = $('#challenge-error');
    if (!name || !email) {
      errorBox.hidden = false;
      errorBox.textContent = t('toast.required');
      return;
    }
    const button = $('#challenge-submit');
    setBusy(button, true, t('challenge.submit'));
    try {
      await api('/challenges', {
        method: 'POST',
        body: {
          identifier_type: type || detectType(value),
          identifier_value: value,
          claimant_name: name,
          contact_email: email,
          proof_note: proof,
        },
      });
      closeModal();
      toast(t('toast.challenge.ok'), 'success', 'i-scale');
      if (state.lastLookup) runLookup(state.lastLookup.value, state.lastLookup.type);
    } catch (error) {
      errorBox.hidden = false;
      errorBox.textContent = error.message || t('toast.lookup.failed');
    } finally {
      setBusy(button, false);
    }
  };
}

/* ------------------------------------------------------------------
   Areas + report form
   ------------------------------------------------------------------ */

function areaByPin(pin) {
  if (!state.meta || !Array.isArray(state.meta.areas)) return null;
  return state.meta.areas.find((area) => area.pincode === String(pin)) || null;
}

function buildAreaOptions(selected, includeAll) {
  if (!state.meta || !Array.isArray(state.meta.areas)) return '';
  let html = includeAll
    ? `<option value="">${escapeHtml(state.lang === 'hi' ? 'सभी क्षेत्र' : 'All areas')}</option>`
    : '';
  const cities = state.meta.cities && state.meta.cities.length
    ? state.meta.cities
    : [...new Set(state.meta.areas.map((area) => area.city))];
  cities.forEach((city) => {
    const areas = state.meta.areas.filter((area) => area.city === city);
    if (!areas.length) return;
    html += `<optgroup label="${escapeHtml(city)}">`;
    areas.forEach((area) => {
      const isSelected = String(selected || '') === area.pincode ? ' selected' : '';
      html += `<option value="${escapeHtml(area.pincode)}"${isSelected}>${escapeHtml(area.locality)} · ${escapeHtml(area.pincode)}</option>`;
    });
    html += '</optgroup>';
  });
  return html;
}

function populateSelects() {
  if (!state.meta) return;
  const areas = state.meta.areas || [];
  if (!areas.some((area) => area.pincode === state.area)) {
    state.area = areas[0] ? areas[0].pincode : '';
    if (state.area) localStorage.setItem('sm_area', state.area);
  }
  if (!state.report.area || !areas.some((area) => area.pincode === state.report.area)) {
    state.report.area = state.area;
  }
  const global = $('#global-area');
  if (global) {
    global.innerHTML = buildAreaOptions(state.area, false);
    global.value = state.area;
  }
  const reportArea = $('#report-area');
  if (reportArea) {
    reportArea.innerHTML = buildAreaOptions(state.report.area || state.area, false);
    reportArea.value = state.report.area || state.area;
  }
  const alertArea = $('#alert-area');
  if (alertArea) {
    alertArea.innerHTML = buildAreaOptions(state.alertPin, true);
    alertArea.value = state.alertPin || '';
  }
}

function renderReportForm() {
  if (!state.meta) return;
  const channelSelect = $('#channel-select');
  if (channelSelect && !channelSelect.dataset.ready) {
    channelSelect.innerHTML = (state.meta.channels || []).map((channel) =>
      `<option value="${escapeHtml(channel)}">${escapeHtml(channelLabel(channel))}</option>`
    ).join('');
    channelSelect.dataset.ready = '1';
  }
  if (channelSelect) channelSelect.value = state.report.channel || (state.meta.channels || [])[0] || '';

  const scamSelect = $('#scam-select');
  if (scamSelect && !scamSelect.dataset.ready) {
    scamSelect.innerHTML = `<option value="">${state.lang === 'hi' ? 'श्रेणी चुनें' : 'Choose a scam category'}</option>` + (state.meta.scam_types || []).map((scam) =>
      `<option value="${escapeHtml(scam.id)}">${escapeHtml(state.lang === 'hi' ? (scam.hindi || scam.label) : scam.label)}</option>`
    ).join('');
    scamSelect.dataset.ready = '1';
  } else if (scamSelect) {
    (state.meta.scam_types || []).forEach((scam) => {
      const option = scamSelect.querySelector(`option[value="${CSS.escape(scam.id)}"]`);
      if (option) option.textContent = state.lang === 'hi' ? (scam.hindi || scam.label) : scam.label;
    });
  }
  if (scamSelect) scamSelect.value = state.report.scam || '';

  const typeSelect = $('#report-type-select');
  if (typeSelect) typeSelect.value = state.reportType || 'auto';

  const reportArea = $('#report-area');
  if (reportArea && !reportArea.options.length) {
    reportArea.innerHTML = buildAreaOptions(state.report.area || state.area, false);
  }
  if (reportArea) reportArea.value = state.report.area || state.area;
  updateNoteCount();
}

function updateNoteCount() {
  const note = $('#report-note');
  const counter = $('#note-count');
  if (note && counter) counter.textContent = `${note.value.length} / 2000`;
}

function reportTime(value) {
  const now = new Date();
  if (value === 'hour') return new Date(now.getTime() - 40 * 60 * 1000);
  if (value === 'today') return new Date(now.getTime() - 4 * 60 * 60 * 1000);
  if (value === 'yesterday') return new Date(now.getTime() - 28 * 60 * 60 * 1000);
  if (value === 'custom') {
    const input = $('#report-custom-time');
    if (!input || !input.value) throw new Error(t('toast.required'));
    const date = new Date(input.value);
    if (Number.isNaN(date.getTime())) throw new Error(t('toast.required'));
    return date;
  }
  return now;
}

async function refreshReportSession() {
  try {
    const data = await api('/report-session');
    renderReportQuota(data.used, data.limit, data.remaining);
  } catch (_error) {
    const count = $('#report-quota-count');
    if (count) count.textContent = 'Unavailable';
  }
}

function renderReportQuota(used, limit = 5, remaining = Math.max(0, limit - used)) {
  const percent = Math.max(0, Math.min(100, (Number(used) / Math.max(1, Number(limit))) * 100));
  const count = $('#report-quota-count');
  const fill = $('#report-quota-fill');
  const help = $('#report-quota-help');
  if (count) count.textContent = `${used} / ${limit}`;
  if (fill) fill.style.width = `${percent}%`;
  if (help) help.textContent = remaining > 0
    ? `${remaining} report${remaining === 1 ? '' : 's'} remaining in this anonymous session today.`
    : 'Daily limit reached. You can report again after the daily reset (IST).';
  const submit = $('#report-submit');
  if (submit) submit.disabled = Number(remaining) <= 0;
  const successCount = $('#success-quota-count');
  const successFill = $('#success-quota-fill');
  const successHelp = $('#success-quota-help');
  if (successCount) successCount.textContent = `${used} / ${limit}`;
  if (successFill) successFill.style.width = `${percent}%`;
  if (successHelp) successHelp.textContent = `${remaining} report${remaining === 1 ? '' : 's'} remaining today.`;
}

async function uploadSmsEvidence(reportId, file) {
  const response = await fetch(`/sms/evidence/${encodeURIComponent(reportId)}`, {
    method: 'POST',
    headers: { 'Content-Type': file.type, 'X-File-Name': file.name },
    body: file,
    credentials: 'same-origin',
  });
  let data = null;
  try { data = await response.json(); } catch (_error) { data = null; }
  if (!response.ok) {
    const error = new Error((data && (data.message || data.error)) || `Evidence upload failed (${response.status})`);
    error.status = response.status;
    throw error;
  }
  return data;
}

async function submitReport(event) {
  event.preventDefault();
  const errorBox = $('#report-error');
  if (errorBox) errorBox.hidden = true;
  const identifier = $('#report-identifier').value.trim();
  const messageText = ($('#report-sms-message')?.value || '').trim();
  const screenshotFile = $('#sms-evidence-file')?.files?.[0] || null;
  const screenshotChecked = Boolean($('#report-screenshot')?.checked);
  const area = areaByPin($('#report-area').value);
  if ((!identifier && !messageText) || !area || !state.report.channel || !state.report.scam) {
    if (errorBox) {
      errorBox.hidden = false;
      errorBox.textContent = t('toast.required');
    }
    toast(t('toast.required'), 'info', 'i-info');
    return;
  }
  if (screenshotChecked && !screenshotFile) {
    if (errorBox) { errorBox.hidden = false; errorBox.textContent = 'Please choose the SMS screenshot file, or untick the screenshot option.'; }
    return;
  }
  if (screenshotFile && !messageText) {
    if (errorBox) { errorBox.hidden = false; errorBox.textContent = 'Paste the SMS text as well so the screenshot can be compared with it.'; }
    return;
  }
  if (screenshotFile && (!['image/png', 'image/jpeg'].includes(screenshotFile.type) || screenshotFile.size > 5 * 1024 * 1024)) {
    if (errorBox) { errorBox.hidden = false; errorBox.textContent = 'Choose a PNG or JPG screenshot smaller than 5 MB.'; }
    return;
  }
  let occurred;
  try {
    occurred = reportTime($('#report-when').value);
  } catch (error) {
    if (errorBox) {
      errorBox.hidden = false;
      errorBox.textContent = error.message;
    }
    return;
  }
  const note = $('#report-note').value.trim();
  const type = identifier ? (state.reportType === 'auto' ? detectType(identifier) : state.reportType) : null;
  const amount = Number($('#report-amount').value || 0);
  const button = $('#report-submit');
  setBusy(button, true, t('report.submit'));
  try {
    const result = await api('/reports', {
      method: 'POST',
      body: {
        ...(identifier ? { identifier_type: type, identifier_value: identifier } : {}),
        ...(messageText ? { message_text: messageText } : {}),
        occurred_at: occurred.toISOString(),
        channel: state.report.channel,
        scam_type: state.report.scam,
        pincode: area.pincode,
        locality: area.locality,
        city: area.city,
        note,
        has_screenshot: Boolean(screenshotFile),
        amount_lost_inr: Number.isFinite(amount) ? Math.max(0, Math.floor(amount)) : 0,
      },
    });
    let evidenceResult = null;
    let evidenceUploadMessage = '';
    if (screenshotFile) {
      try {
        evidenceResult = await uploadSmsEvidence(result.report_id, screenshotFile);
        evidenceUploadMessage = ` Evidence check: ${evidenceResult.message}`;
      } catch (uploadError) {
        evidenceUploadMessage = ` Screenshot upload could not be completed: ${uploadError.message}. The report itself was received.`;
      }
    }
    state.lastReport = { type: type || 'sms', value: identifier || 'SMS message', scam: state.report.scam };
    $('#report-form').hidden = true;
    const success = $('#report-success');
    success.hidden = false;
    $('#success-report-id').textContent = result.report_id || '—';
    $('#success-case').textContent = result.case_id || '—';
    $('#success-merged').textContent = result.merged ? (state.lang === 'hi' ? 'हाँ' : 'Yes') : (state.lang === 'hi' ? 'नहीं' : 'No');
    $('#success-summary').textContent = (result.report_summary || 'Your report has been received and is awaiting verification.') + evidenceUploadMessage;
    $('#success-verification').textContent = 'REPORTED · MARKED FOR VERIFICATION';
    renderReportQuota(result.reports_used_today || 0, result.daily_report_limit || 5, result.reports_remaining_today || 0);
    success.scrollIntoView({ behavior: 'smooth', block: 'center' });
    toast(t('toast.report.ok'), 'success', 'i-checkcircle');
    refreshMapAlerts();
  } catch (error) {
    if (error.status === 403) return;
    if (error.status === 409) {
      toast(t('toast.report.dup'), 'error', 'i-alert');
      return;
    }
    if (error.status === 429) {
      toast(t('toast.rate'), 'error', 'i-alert');
    }
    if (errorBox) {
      errorBox.hidden = false;
      errorBox.textContent = error.message || t('toast.lookup.failed');
    }
    if (error.status !== 429) toast(error.message || t('toast.lookup.failed'), 'error', 'i-alert');
  } finally {
    setBusy(button, false);
    await refreshReportSession();
  }
}

function resetReportForm() {
  const form = $('#report-form');
  if (form) form.reset();
  state.report = { channel: 'Phone call', scam: '', when: 'now', area: state.area };
  state.reportType = 'auto';
  if (form) form.hidden = false;
  const success = $('#report-success');
  if (success) success.hidden = true;
  const error = $('#report-error');
  if (error) error.hidden = true;
  const idError = $('#report-id-error');
  if (idError) idError.hidden = true;
  const custom = $('#report-custom-time');
  if (custom) custom.hidden = true;
  const when = $('#report-when');
  if (when) when.value = 'now';
  renderReportForm();
  const input = $('#report-identifier');
  if (input) input.value = '';
  updateNoteCount();
}

/* ------------------------------------------------------------------
   Map
   ------------------------------------------------------------------ */

function mapCities() {
  const supported = (state.meta?.areas || []).map((area) => area.city);
  const reported = (state.map.clusters || []).map((cluster) => cluster.city);
  return [...new Set([...supported, ...reported].filter(Boolean))].sort();
}

function filteredClusters() {
  const all = state.map.clusters || [];
  if (state.mapCity === 'All India') return all;
  return all.filter((cluster) => cluster.city === state.mapCity);
}

function initializeLeafletMap() {
  const element = $('#scam-map');
  if (!element || state.leafletMap || !window.L) return;
  state.leafletMap = L.map(element, { zoomControl: true, scrollWheelZoom: true, preferCanvas: true })
    .setView([22.8, 79.0], 4.6);
  const cartoKey = String(window.SCAMMAP_PUBLIC_CONFIG?.carto_api_key || '').trim();
  const cartoTileUrl = `https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png${cartoKey ? `?key=${encodeURIComponent(cartoKey)}` : ''}`;
  L.tileLayer(cartoTileUrl, {
    subdomains: 'abcd', maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
  }).addTo(state.leafletMap);
  state.leafletMarkers = L.layerGroup().addTo(state.leafletMap);
  state.leafletHeat = window.L.heatLayer ? L.heatLayer([], {
    radius: 34, blur: 25, maxZoom: 11, minOpacity: 0.24,
    gradient: { 0.20: '#36c7d8', 0.48: '#f2c45e', 0.72: '#f18a48', 1.0: '#ef526f' }
  }).addTo(state.leafletMap) : null;
  state.leafletMap.on('click', () => {});
}

function updateLeafletMap(clusters) {
  initializeLeafletMap();
  const map = state.leafletMap;
  if (!map || !state.leafletMarkers) return;
  state.leafletMarkers.clearLayers();
  const heatPoints = [];
  clusters.forEach((cluster) => {
    const lat = Number(cluster.lat);
    const lng = Number(cluster.lng);
    const count = Math.max(0, Number(cluster.count) || 0);
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || !count) return;
    const severity = String(cluster.severity || 'MED').toUpperCase();
    const color = severity === 'CRIT' ? '#fb5878' : severity === 'HIGH' ? '#f5a34d' : '#39c7d8';
    heatPoints.push([lat, lng, Math.min(1, 0.22 + count / 18)]);
    const marker = L.circleMarker([lat, lng], {
      radius: Math.min(23, 8 + Math.sqrt(count) * 2.4),
      color, weight: 2, opacity: .96, fillColor: color, fillOpacity: .64,
      bubblingMouseEvents: false
    });
    const popup = `<div class="scam-popup"><strong>${escapeHtml(cluster.locality)}</strong><br>${escapeHtml(cluster.city)} · ${escapeHtml(cluster.pincode)}<br><span>${Number(count)} credible report${count === 1 ? '' : 's'}</span><br>Top pattern: ${escapeHtml(scamLabel(cluster.top_scam_type))}<br>Severity: <b>${escapeHtml(severity)}</b></div>`;
    marker.bindPopup(popup, { closeButton: true, autoPan: true });
    marker.bindTooltip(`${escapeHtml(cluster.locality)} · ${count} reports`, { direction: 'top', offset: [0, -8] });
    marker.on('click', () => {
      state.mapPin = cluster.pincode;
      const currentView = filteredClusters();
      renderMapList(currentView);
      renderMapDetail(currentView);
      marker.openPopup();
    });
    state.leafletMarkers.addLayer(marker);
  });
  if (state.leafletHeat) {
    state.leafletHeat.setLatLngs(heatPoints);
    if (state.leafletHeatVisible && !map.hasLayer(state.leafletHeat)) state.leafletHeat.addTo(map);
    if (!state.leafletHeatVisible && map.hasLayer(state.leafletHeat)) map.removeLayer(state.leafletHeat);
  }

  // Fit once when switching between national and city views; marker selection
  // does not reset the user's current zoom or pan position.
  if (state.leafletLastCity !== state.mapCity) {
    state.leafletLastCity = state.mapCity;
    if (state.mapCity === 'All India') {
      map.setView([22.8, 79.0], 4.6, { animate: true });
    } else {
      const areaPoints = (state.meta?.areas || []).filter((area) => area.city === state.mapCity);
      const points = areaPoints.length ? areaPoints : clusters;
      if (points.length) {
        const bounds = L.latLngBounds(points.map((area) => [Number(area.lat), Number(area.lng)]));
        if (bounds.isValid()) map.fitBounds(bounds.pad(0.22), { maxZoom: 12, animate: true });
      }
    }
  }
  window.setTimeout(() => map.invalidateSize(), 80);
}

function renderMap() {
  if (!state.meta) return;
  const all = state.map.clusters || [];
  const cities = mapCities();
  if (state.mapCity !== 'All India' && !cities.includes(state.mapCity)) {
    state.mapCity = cities.includes('Bengaluru') ? 'Bengaluru' : 'All India';
  }
  const tabs = $('#city-tabs');
  if (tabs) {
    tabs.innerHTML = [
      `<button class="city-tab${state.mapCity === 'All India' ? ' active' : ''}" data-city="All India">${escapeHtml(t('map.all'))}</button>`,
      ...cities.map((city) => `<button class="city-tab${state.mapCity === city ? ' active' : ''}" data-city="${escapeHtml(city)}">${escapeHtml(city)}</button>`),
    ].join('');
  }

  const filtered = filteredClusters();
  if (!filtered.some((cluster) => cluster.pincode === state.mapPin)) {
    state.mapPin = filtered[0] ? filtered[0].pincode : null;
  }
  const empty = $('#map-empty');
  if (empty) empty.hidden = filtered.length > 0;
  updateLeafletMap(filtered);
  const total = $('#map-total');
  if (total) total.textContent = String(filtered.length);
  renderMapList(filtered);
  renderMapDetail(filtered);
  renderMapAlerts();
  const metric = $('#metric-areas');
  if (metric) metric.textContent = String(all.length);
}

function renderMapSvg(clusters, city) {
  const width = 800;
  const height = 520;
  const left = 70;
  const top = 64;
  const plotW = 660;
  const plotH = 392;
  let minLat = 6;
  let maxLat = 37;
  let minLng = 68;
  let maxLng = 98;

  if (city !== 'All India' && state.meta) {
    const cityAreas = state.meta.areas.filter((area) => area.city === city);
    if (cityAreas.length) {
      const lats = cityAreas.map((area) => Number(area.lat));
      const lngs = cityAreas.map((area) => Number(area.lng));
      minLat = Math.min(...lats);
      maxLat = Math.max(...lats);
      minLng = Math.min(...lngs);
      maxLng = Math.max(...lngs);
      const spanLat = Math.max(0.035, maxLat - minLat);
      const spanLng = Math.max(0.035, maxLng - minLng);
      minLat -= spanLat * 0.18;
      maxLat += spanLat * 0.18;
      minLng -= spanLng * 0.18;
      maxLng += spanLng * 0.18;
    }
  }

  const project = (lat, lng) => ({
    x: left + ((Number(lng) - minLng) / (maxLng - minLng || 1)) * plotW,
    y: top + ((maxLat - Number(lat)) / (maxLat - minLat || 1)) * plotH,
  });

  let background = '';
  for (let index = 0; index <= 8; index += 1) {
    const x = left + (plotW / 8) * index;
    background += `<line class="map-grid-line" x1="${x}" y1="${top}" x2="${x}" y2="${top + plotH}"/>`;
  }
  for (let index = 0; index <= 5; index += 1) {
    const y = top + (plotH / 5) * index;
    background += `<line class="map-grid-line" x1="${left}" y1="${y}" x2="${left + plotW}" y2="${y}"/>`;
  }
  background += `
    <circle class="map-ring" cx="${left + plotW / 2}" cy="${top + plotH / 2}" r="78"/>
    <circle class="map-ring" cx="${left + plotW / 2}" cy="${top + plotH / 2}" r="152"/>
    <circle class="map-ring" cx="${left + plotW / 2}" cy="${top + plotH / 2}" r="226"/>
  `;

  if (city !== 'All India') {
    background += `
      <path class="map-road" d="M ${left} ${top + plotH * 0.68} C ${left + plotW * 0.24} ${top + plotH * 0.56}, ${left + plotW * 0.52} ${top + plotH * 0.78}, ${left + plotW} ${top + plotH * 0.58}"/>
      <path class="map-road" d="M ${left + plotW * 0.22} ${top} C ${left + plotW * 0.3} ${top + plotH * 0.3}, ${left + plotW * 0.34} ${top + plotH * 0.7}, ${left + plotW * 0.42} ${top + plotH}"/>
      <path class="map-road" d="M ${left + plotW * 0.72} ${top} C ${left + plotW * 0.66} ${top + plotH * 0.3}, ${left + plotW * 0.74} ${top + plotH * 0.66}, ${left + plotW * 0.84} ${top + plotH}"/>
    `;
  } else {
    background += `
      <text x="${left + plotW * 0.45}" y="${top + 34}" text-anchor="middle" class="map-city-label">NORTH</text>
      <text x="${left + plotW * 0.16}" y="${top + plotH * 0.55}" text-anchor="middle" class="map-city-label">WEST</text>
      <text x="${left + plotW * 0.48}" y="${top + plotH - 20}" text-anchor="middle" class="map-city-label">SOUTH</text>
      <text x="${left + plotW * 0.86}" y="${top + plotH * 0.5}" text-anchor="middle" class="map-city-label">EAST</text>
    `;
  }

  const sorted = [...clusters].sort((a, b) => a.count - b.count);
  const showAllLabels = sorted.length <= 5;
  const markers = sorted.map((cluster, index) => {
    const point = project(cluster.lat, cluster.lng);
    const radius = 8 + Math.min(16, Math.sqrt(Number(cluster.count) || 1) * 3.6);
    const selected = cluster.pincode === state.mapPin;
    const showLabel = selected || showAllLabels || Number(cluster.count) >= 6;
    const countSize = radius >= 18 ? 10 : 8.5;
    return `
      <g class="marker sev-${escapeHtml(cluster.severity)}${selected ? ' selected' : ''}" data-pin="${escapeHtml(cluster.pincode)}" transform="translate(${point.x.toFixed(1)} ${point.y.toFixed(1)})" tabindex="0" role="button" aria-label="${escapeHtml(cluster.locality)}: ${escapeHtml(cluster.count)} ${escapeHtml(t('result.reports'))}">
        <title>${escapeHtml(cluster.locality)} — ${escapeHtml(cluster.count)} ${escapeHtml(t('result.reports'))}</title>
        <circle class="marker-ring" r="${(radius + 10).toFixed(1)}" style="animation-delay:${(index * 0.18).toFixed(2)}s"/>
        <circle class="marker-halo" r="${(radius + 4).toFixed(1)}"/>
        <circle class="marker-core" r="${radius.toFixed(1)}"/>
        <text class="marker-count" y="0.5" style="font-size:${countSize}px">${escapeHtml(cluster.count)}</text>
        ${showLabel ? `<text class="map-area-label" y="${(radius + 15).toFixed(1)}" text-anchor="middle">${escapeHtml(cluster.locality)}</text>` : ''}
      </g>
    `;
  }).join('');

  const label = city === 'All India' ? 'INDIA' : city;
  return `
    <defs>
      <radialGradient id="map-vignette" cx="50%" cy="50%" r="65%">
        <stop offset="0%" stop-color="#c9b5ff" stop-opacity="0.12"/>
        <stop offset="100%" stop-color="#ffffff" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <rect x="0" y="0" width="${width}" height="${height}" fill="url(#map-vignette)"/>
    ${background}
    <text x="${left + plotW}" y="${top + plotH + 34}" text-anchor="end" class="map-city-label">${escapeHtml(label.toUpperCase())}</text>
    ${markers}
  `;
}


function mapAlertPresentation(alert) {
  if (alert.type === 'HIGHEST_ACTIVITY') {
    return { kind: 'highest', icon: 'i-bell', title: `Highest activity: ${alert.locality}`, body: `${alert.count} credible reports in the last 7 days`, tag: 'HIGH' };
  }
  if (alert.type === 'SPIKE') {
    return { kind: 'spike', icon: 'i-trend', title: `Spike detected: ${alert.locality}`, body: `${alert.count} reports vs ${alert.baseline_count || 0} in the previous 7 days`, tag: 'SPIKE' };
  }
  return { kind: 'new', icon: 'i-sparkles', title: `New scam pattern: ${alert.locality}`, body: `${scamLabel(alert.scam_type)} · ${alert.count || 0} recent reports`, tag: 'NEW' };
}

function renderMapAlerts() {
  const alerts = (state.alerts || []).filter((alert) => state.mapCity === 'All India' || alert.city === state.mapCity);
  const floating = $('#map-floating-alerts');
  const list = $('#map-live-alert-list');
  const count = $('#map-alert-count');
  if (count) count.textContent = String(alerts.length);
  if (!alerts.length) {
    if (floating) floating.innerHTML = '';
    if (list) list.innerHTML = '<div class="map-alert-quiet">No unusual activity detected in the last 7 days.</div>';
    return;
  }
  const top = alerts.slice(0, 3);
  if (floating) {
    floating.innerHTML = top.map((alert) => {
      const view = mapAlertPresentation(alert);
      return `<button class="map-float-alert ${view.kind}" data-map-alert-pin="${escapeHtml(alert.pincode)}" title="View ${escapeHtml(alert.locality)} on map"><span class="map-float-icon">${icon(view.icon)}</span><span class="map-float-copy"><strong>${escapeHtml(view.title)}</strong><small>${escapeHtml(view.body)}</small></span><span class="map-float-tag">${view.tag}</span><span class="map-float-close" aria-hidden="true">×</span></button>`;
    }).join('');
  }
  if (list) {
    list.innerHTML = alerts.slice(0, 5).map((alert) => {
      const view = mapAlertPresentation(alert);
      return `<button class="map-live-alert ${view.kind}" data-map-alert-pin="${escapeHtml(alert.pincode)}"><span class="map-live-alert-icon">${icon(view.icon)}</span><span class="map-live-alert-copy"><strong>${escapeHtml(view.title)}</strong><small>${escapeHtml(view.body)}</small></span><span class="map-live-alert-tag">${view.tag}</span></button>`;
    }).join('');
  }
}

function renderMapList(clusters) {
  const list = $('#map-list');
  if (!list) return;
  if (!clusters.length) {
    list.innerHTML = `<div class="detail-empty" style="min-height:90px"><p>${escapeHtml(t('empty.map'))}</p></div>`;
    return;
  }
  list.innerHTML = clusters.map((cluster) => `
    <button class="map-list-item${cluster.pincode === state.mapPin ? ' active' : ''}" data-pin="${escapeHtml(cluster.pincode)}">
      <i class="dot ${cluster.severity === 'CRIT' ? 'crit' : cluster.severity === 'HIGH' ? 'high' : 'med'}"></i>
      <div class="map-list-main">
        <strong>${escapeHtml(cluster.locality)}</strong>
        <span>${escapeHtml(cluster.city)} · ${escapeHtml(scamLabel(cluster.top_scam_type))}</span>
      </div>
      <div class="map-list-count"><strong>${escapeHtml(cluster.count)}</strong><span>${escapeHtml(t('result.reports'))}</span></div>
    </button>
  `).join('');
}

function renderMapDetail(clusters) {
  const detail = $('#map-detail');
  if (!detail) return;
  const cluster = clusters.find((item) => item.pincode === state.mapPin);
  if (!cluster) {
    detail.innerHTML = `
      <div class="detail-empty">
        ${icon('i-pin')}
        <h3>${escapeHtml(t('map.select.title'))}</h3>
        <p>${escapeHtml(t('map.select.body'))}</p>
      </div>
    `;
    return;
  }
  detail.innerHTML = `
    <div class="detail-head">
      <div><h3>${escapeHtml(cluster.locality)}</h3><p>${escapeHtml(cluster.city)} · ${escapeHtml(cluster.pincode)}</p></div>
      <span class="detail-severity sev-${escapeHtml(cluster.severity)}">${escapeHtml(cluster.severity)}</span>
    </div>
    <div class="detail-stats">
      <div class="detail-stat"><span>${escapeHtml(t('map.detail.reports'))}</span><strong>${escapeHtml(cluster.count)}</strong></div>
      <div class="detail-stat"><span>${escapeHtml(t('map.detail.people'))}</span><strong>${escapeHtml(cluster.distinct_reporters || 0)}</strong></div>
    </div>
    <div class="detail-type">${icon(scamIcon(cluster.top_scam_type))}<span>${escapeHtml(t('map.detail.top'))}: ${escapeHtml(scamLabel(cluster.top_scam_type))}</span></div>
    <div class="detail-actions">
      <button class="btn btn-secondary btn-sm" data-action="map-alerts" data-pin="${escapeHtml(cluster.pincode)}">${icon('i-bell')}<span>${escapeHtml(t('map.detail.alerts'))}</span></button>
      <button class="btn btn-ghost btn-sm" data-action="map-report" data-pin="${escapeHtml(cluster.pincode)}">${icon('i-plus')}<span>${escapeHtml(t('map.detail.report'))}</span></button>
    </div>
  `;
}

function selectMapPin(pin) {
  state.mapPin = pin;
  renderMap();
}

async function refreshMap() {
  try {
    const data = await api('/map?days=7');
    state.map = data || { clusters: [] };
    renderMap();
    renderHome();
  } catch (error) {
    if (error.status !== 403) toast(error.message || t('toast.lookup.failed'), 'error', 'i-alert');
  }
}

/* ------------------------------------------------------------------
   Alerts + home
   ------------------------------------------------------------------ */

function filteredAlerts() {
  if (!state.alertPin) return state.alerts;
  return state.alerts.filter((alert) => alert.pincode === state.alertPin);
}

function updateNavBadges() {
  const count = state.alerts.length;
  ['#nav-alert-count', '#tab-alert-count'].forEach((selector) => {
    const badge = $(selector);
    if (!badge) return;
    badge.textContent = String(count);
    badge.dataset.zero = count === 0 ? 'true' : 'false';
  });
}

function renderHome() {
  const clusters = state.map.clusters || [];
  const reportTotal = clusters.reduce((sum, cluster) => sum + Number(cluster.count || 0), 0);
  const critical = clusters.filter((cluster) => cluster.severity === 'CRIT').length;
  const metrics = {
    '#metric-reports': reportTotal,
    '#metric-areas': clusters.length,
    '#metric-alerts': state.alerts.length,
    '#side-known': critical,
    '#side-areas': clusters.length,
  };
  Object.entries(metrics).forEach(([selector, value]) => {
    const element = $(selector);
    if (element) element.textContent = String(value);
  });
  renderHomeFeed();
  renderHomeAlerts();
  updateNavBadges();
}

function renderHomeFeed() {
  const root = $('#home-feed');
  if (!root) return;
  const clusters = state.map.clusters || [];
  if (!clusters.length) {
    root.innerHTML = `<div class="detail-empty" style="min-height:120px"><p>${escapeHtml(t('empty.feed'))}</p></div>`;
    return;
  }
  const grouped = new Map();
  clusters.forEach((cluster) => {
    const key = cluster.top_scam_type || 'other';
    const current = grouped.get(key) || { count: 0, areas: 0 };
    current.count += Number(cluster.count || 0);
    current.areas += 1;
    grouped.set(key, current);
  });
  const rows = [...grouped.entries()].sort((a, b) => b[1].count - a[1].count).slice(0, 5);
  root.innerHTML = rows.map(([type, data]) => `
    <div class="feed-item">
      <span class="feed-icon">${icon(scamIcon(type))}</span>
      <div class="feed-main">
        <strong>${escapeHtml(scamLabel(type))}</strong>
        <span>${escapeHtml(t('feed.across', { n: data.areas }))}</span>
      </div>
      <span class="feed-count">${escapeHtml(data.count)}</span>
    </div>
  `).join('');
}

function miniAlert(alert) {
  const isSpike = alert.type === 'SPIKE';
  const title = isSpike
    ? t('alerts.spike.title', { area: alert.locality })
    : t('alerts.new.title', { type: scamLabel(alert.scam_type) });
  return `
    <div class="mini-alert ${isSpike ? 'spike' : 'new'}">
      <span class="mini-alert-icon">${icon(isSpike ? 'i-trend' : 'i-sparkles')}</span>
      <div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(alert.city || '')} · ${escapeHtml(alert.pincode || '')}</span></div>
    </div>
  `;
}

function renderHomeAlerts() {
  const root = $('#home-alerts');
  if (!root) return;
  if (!state.alerts.length) {
    root.innerHTML = `
      <div class="mini-alert">
        <span class="mini-alert-icon" style="background:rgba(52,211,153,.1);color:var(--green)">${icon('i-checkcircle')}</span>
        <div><strong>${escapeHtml(t('alerts.summary.quiet'))}</strong><span>${escapeHtml(t('empty.alerts'))}</span></div>
      </div>
    `;
    return;
  }
  root.innerHTML = state.alerts.slice(0, 2).map(miniAlert).join('');
}

function alertCard(alert) {
  const isSpike = alert.type === 'SPIKE';
  const title = isSpike
    ? t('alerts.spike.title', { area: alert.locality })
    : t('alerts.new.title', { type: scamLabel(alert.scam_type) });
  const body = isSpike
    ? t('alerts.spike.body', { n: alert.count, base: alert.baseline_per_day })
    : t('alerts.new.body', { area: alert.locality });
  const metrics = isSpike
    ? [
      [t('alerts.count'), alert.count],
      [t('alerts.baseline'), alert.baseline_per_day],
      [t('alerts.window'), '24h'],
    ]
    : [
      [t('alerts.type'), scamLabel(alert.scam_type)],
      [t('alerts.area'), alert.pincode],
      [t('alerts.window'), '24h'],
    ];
  return `
    <article class="glass alert-card ${isSpike ? 'alert-spike' : 'alert-new'}">
      <span class="alert-icon">${icon(isSpike ? 'i-trend' : 'i-sparkles')}</span>
      <div class="alert-body">
        <div class="alert-top">
          <span class="alert-type">${escapeHtml(alert.type)}</span>
          <span class="alert-area">${escapeHtml(alert.locality)} · ${escapeHtml(alert.city)}</span>
        </div>
        <h3>${escapeHtml(title)}</h3>
        <p>${escapeHtml(body)}</p>
        <div class="alert-metrics">
          ${metrics.map(([label, value]) => `<div class="alert-metric"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')}
        </div>
      </div>
      <button class="btn btn-ghost btn-sm alert-action" data-action="alert-map" data-pin="${escapeHtml(alert.pincode)}" data-city="${escapeHtml(alert.city)}">${icon('i-map')}<span>${escapeHtml(t('alerts.view'))}</span></button>
    </article>
  `;
}

function renderAlerts() {
  const alerts = filteredAlerts();
  const summary = $('#alerts-summary');
  if (summary) {
    if (alerts.length) {
      const title = alerts.length === 1
        ? t('alerts.summary.one')
        : t('alerts.summary.many', { n: alerts.length });
      summary.innerHTML = `
        <span class="summary-icon">${icon('i-bell')}</span>
        <div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(t('alerts.summary.body'))}</p></div>
        <span class="summary-count">${escapeHtml(alerts.length)}</span>
      `;
    } else {
      summary.innerHTML = `
        <span class="summary-icon" style="background:rgba(52,211,153,.1);color:var(--green)">${icon('i-checkcircle')}</span>
        <div><h3>${escapeHtml(t('alerts.summary.quiet'))}</h3><p>${escapeHtml(t('alerts.summary.body'))}</p></div>
        <span class="summary-count" style="color:var(--green)">0</span>
      `;
    }
  }
  const list = $('#alerts-list');
  if (list) {
    if (!alerts.length) {
      list.innerHTML = `
        <div class="glass alerts-empty">
          <span class="empty-icon">${icon('i-checkcircle')}</span>
          <h3>${escapeHtml(t('alerts.summary.quiet'))}</h3>
          <p>${escapeHtml(t('empty.alerts'))}</p>
        </div>
      `;
    } else {
      list.innerHTML = alerts.map(alertCard).join('');
    }
  }
  const select = $('#alert-area');
  if (select) select.value = state.alertPin || '';
  renderHomeAlerts();
  updateNavBadges();
}

async function refreshAlerts() {
  try {
    const data = await api('/alerts');
    state.alerts = data && Array.isArray(data.alerts) ? data.alerts : [];
    renderAlerts();
    renderHome();
    renderMapAlerts();
  } catch (error) {
    if (error.status !== 403) toast(error.message || t('toast.lookup.failed'), 'error', 'i-alert');
  }
}

async function refreshMapAlerts() {
  await Promise.allSettled([refreshMap(), refreshAlerts()]);
}

/* ------------------------------------------------------------------
   Licence + server demo
   ------------------------------------------------------------------ */

function licenseRemaining() {
  if (!state.license || !state.license.valid) return 0;
  let seconds = Number(state.license.seconds_remaining);
  if (!Number.isFinite(seconds)) {
    const expires = new Date(state.license.expires_at).getTime();
    seconds = Number.isFinite(expires) ? (expires - Date.now()) / 1000 : 0;
  }
  const elapsed = state.licenseFetchedAt ? (Date.now() - state.licenseFetchedAt) / 1000 : 0;
  return Math.max(0, seconds - elapsed);
}

function licenseProgress() {
  if (!state.license || !state.license.valid) return 0;
  const issued = new Date(state.license.issued_at).getTime();
  const expires = new Date(state.license.expires_at).getTime();
  if (!Number.isFinite(issued) || !Number.isFinite(expires) || expires <= issued) return 100;
  const total = (expires - issued) / 1000;
  return Math.max(0, Math.min(100, (licenseRemaining() / total) * 100));
}

function licenseStatusKey(license) {
  if (!license) return 'missing';
  const status = String(license.status || '').toUpperCase();
  if (status === 'VALID' || license.valid) return 'valid';
  if (status.includes('CLOCK')) return 'clock';
  if (status.includes('INVALID')) return 'invalid';
  if (status.includes('MISSING')) return 'missing';
  return 'expired';
}

function renderLicense() {
  const license = state.license;
  const key = licenseStatusKey(license);
  const badge = $('#license-badge');
  if (badge) {
    const labels = {
      valid: 'VALID', expired: 'EXPIRED', clock: 'CLOCK_ROLLBACK',
      invalid: 'INVALID', missing: 'NO LICENCE',
    };
    badge.className = `status-badge ${key === 'valid' ? 'valid' : key === 'missing' ? 'missing' : key === 'clock' ? 'warn' : 'expired'}`;
    badge.textContent = labels[key] || 'CHECKING';
  }
  const licensee = $('#license-licensee');
  if (licensee) licensee.textContent = license && license.licensee ? license.licensee : t('license.no');
  const remaining = licenseRemaining();
  const countdown = $('#license-countdown');
  if (countdown) countdown.textContent = key === 'valid' ? formatCountdown(remaining) : '—';
  const progress = $('#license-progress-bar');
  if (progress) progress.style.width = `${licenseProgress()}%`;
  const expires = $('#license-expires');
  if (expires) expires.textContent = license && license.expires_at ? formatDate(license.expires_at) : '—';
  const server = $('#license-server');
  if (server) server.textContent = license && license.server_time ? formatDate(license.server_time) : '—';
  const id = $('#license-id');
  if (id) id.textContent = license && license.license_id ? license.license_id : '—';

  const dot = $('#licence-dot');
  const statusText = $('#licence-status');
  if (dot) {
    dot.className = `status-dot ${key === 'valid' ? 'ok' : key === 'missing' ? 'warn' : 'bad'}`;
  }
  if (statusText) {
    const labels = {
      valid: t('license.valid'), expired: t('license.expired'), clock: t('license.clock'),
      invalid: t('license.invalid'), missing: t('license.missing'),
    };
    statusText.textContent = labels[key] || t('license.missing');
  }
  const demo = $('#demo-tools');
  if (demo) demo.hidden = !(state.meta && state.meta.demo_mode);
  const issue = $('#issue-5min');
  if (issue) issue.disabled = !(state.meta && state.meta.allow_demo_license_issue);
  const issueYear = $('#issue-year');
  if (issueYear) issueYear.disabled = !(state.meta && state.meta.allow_demo_license_issue);
}

function updateLicenseCountdown() {
  if (!state.license || !state.license.valid) return;
  const remaining = licenseRemaining();
  const countdown = $('#license-countdown');
  if (countdown) countdown.textContent = formatCountdown(remaining);
  const progress = $('#license-progress-bar');
  if (progress) progress.style.width = `${licenseProgress()}%`;
  if (remaining <= 0 && !state.countdownExpired) {
    state.countdownExpired = true;
    refreshLicense();
  }
}

async function refreshLicense() {
  try {
    const data = await api('/license');
    const wasValid = state.license && state.license.valid;
    state.license = data;
    state.licenseFetchedAt = Date.now();
    state.licenseLoaded = true;
    state.countdownExpired = false;
    renderLicense();
    if (data && data.valid) {
      hideLicenseOverlay();
      if (state.licenseLoaded && wasValid === false) refreshData();
    } else {
      showLicenseOverlay((data && (data.error || data.status)) || 'EXPIRED');
    }
    return data;
  } catch (_error) {
    const dot = $('#licence-dot');
    if (dot) dot.className = 'status-dot bad';
    return null;
  }
}

async function refreshData() {
  const results = await Promise.allSettled([
    api('/meta'),
    api('/license'),
    api('/map?days=7'),
    api('/alerts'),
  ]);
  const [metaResult, licenseResult, mapResult, alertsResult] = results;
  if (metaResult.status === 'fulfilled') state.meta = metaResult.value;
  if (licenseResult.status === 'fulfilled') {
    state.license = licenseResult.value;
    state.licenseFetchedAt = Date.now();
    state.licenseLoaded = true;
    state.countdownExpired = false;
  }
  if (mapResult.status === 'fulfilled') state.map = mapResult.value || { clusters: [] };
  if (alertsResult.status === 'fulfilled') {
    state.alerts = alertsResult.value && Array.isArray(alertsResult.value.alerts)
      ? alertsResult.value.alerts
      : [];
  }
  const apiDot = $('#api-dot');
  if (apiDot) apiDot.className = `status-dot ${metaResult.status === 'fulfilled' ? 'ok' : 'bad'}`;
  const apiStatus = $('#api-status');
  if (apiStatus) {
    apiStatus.textContent = metaResult.status === 'fulfilled'
      ? t('side.api')
      : (state.lang === 'hi' ? 'API से कनेक्ट नहीं' : 'API unavailable');
  }
  populateSelects();
  renderAll();
  if (state.licenseLoaded) {
    if (state.license && state.license.valid) hideLicenseOverlay();
    else showLicenseOverlay((state.license && (state.license.error || state.license.status)) || 'EXPIRED');
  }
  if (metaResult.status === 'rejected' && metaResult.reason && metaResult.reason.status !== 403) {
    toast(metaResult.reason.message || t('toast.lookup.failed'), 'error', 'i-alert');
  }
}

function renderAll() {
  applyI18n();
  populateSelects();
  renderReportForm();
  renderHome();
  renderMap();
  renderAlerts();
  renderLicense();
  renderRecent();
}

async function handleLicenseFile(file) {
  if (!file) return;
  const errorBoxes = [$('#license-error'), $('#overlay-error')].filter(Boolean);
  errorBoxes.forEach((box) => { box.hidden = true; });
  let payload;
  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    payload = parsed && typeof parsed === 'object' && parsed.license ? parsed.license : parsed;
    if (!payload || typeof payload !== 'object') throw new Error(t('toast.license.bad'));
  } catch (_error) {
    errorBoxes.forEach((box) => { box.hidden = false; box.textContent = t('toast.license.bad'); });
    return;
  }
  try {
    const data = await api('/license', { method: 'POST', body: payload });
    state.license = data;
    state.licenseFetchedAt = Date.now();
    state.licenseLoaded = true;
    state.countdownExpired = false;
    renderLicense();
    if (data && data.valid) {
      hideLicenseOverlay();
      toast(t('toast.license.ok'), 'success', 'i-shieldcheck');
      await refreshData();
    } else {
      showLicenseOverlay((data && (data.error || data.status)) || 'EXPIRED');
      toast(t('toast.license.expired'), 'error', 'i-alert');
    }
  } catch (error) {
    errorBoxes.forEach((box) => { box.hidden = false; box.textContent = error.message || t('toast.license.bad'); });
    toast(error.message || t('toast.license.bad'), 'error', 'i-alert');
  } finally {
    $$('#license-file, #overlay-license-file').forEach((input) => { input.value = ''; });
  }
}

async function issueDemoLicense(minutes = 5) {
  try {
    const adminToken = window.prompt('Admin token (not saved):');
    if (!adminToken) return;
    const data = await api(`/demo/license/issue?minutes=${encodeURIComponent(minutes)}`, { method: 'POST', headers: { 'X-Admin-Token': adminToken } });
    state.license = data;
    state.licenseFetchedAt = Date.now();
    state.licenseLoaded = true;
    state.countdownExpired = false;
    renderLicense();
    hideLicenseOverlay();
    toast(t('toast.license.ok'), 'success', 'i-timer');
    await refreshData();
  } catch (error) {
    if (error.status === 404) toast(t('toast.demo.off'), 'info', 'i-info');
    else toast(error.message || t('toast.license.bad'), 'error', 'i-alert');
  }
}

function seedDemo() {
  if (!state.meta || !state.meta.demo_mode) {
    toast(t('toast.demo.off'), 'info', 'i-info');
    return;
  }
  confirmAction(t('confirm.seed.title'), t('confirm.seed.text'), t('confirm.delete'), async () => {
    const adminToken = window.prompt('Admin token (not saved):');
    if (!adminToken) return;
    const result = await api('/demo/seed', { method: 'POST', headers: { 'X-Admin-Token': adminToken } });
    toast(`${t('toast.seed.ok')} ${result.reports || 0} ${state.lang === 'hi' ? 'शिकायतें' : 'reports'}.`, 'success', 'i-database');
    await refreshData();
    go('map');
  });
}

function resetData() {
  if (!state.meta || !state.meta.demo_mode) {
    toast(t('toast.demo.off'), 'info', 'i-info');
    return;
  }
  confirmAction(t('confirm.reset.title'), t('confirm.reset.text'), t('confirm.delete'), async () => {
    const adminToken = window.prompt('Admin token (not saved):');
    if (!adminToken) return;
    const result = await api('/admin/reset', { method: 'POST', headers: { 'X-Admin-Token': adminToken } });
    toast(`${t('toast.reset.ok')} ${result.deleted_reports || 0} ${state.lang === 'hi' ? 'हटीं' : 'deleted'}.`, 'success', 'i-trash');
    await refreshData();
    go('map');
  });
}

function startLicenseTimers() {
  window.setInterval(updateLicenseCountdown, 1000);
  window.setInterval(async () => {
    if (document.hidden || state.licensePolling) return;
    state.licensePolling = true;
    try {
      await refreshLicense();
    } finally {
      state.licensePolling = false;
    }
  }, 10000);
  // Keep the map heat layer and its floating alerts fresh while the user is
  // viewing the map. Polling avoids requiring a separate websocket service.
  window.setInterval(() => {
    if (!document.hidden && state.page === 'map') refreshMapAlerts();
  }, 15000);
}

/* ------------------------------------------------------------------
   Navigation + events
   ------------------------------------------------------------------ */

const PAGE_META = {
  check: ['top.check', 'top.check.title'],
  report: ['top.report', 'top.report.title'],
  map: ['top.map', 'top.map.title'],
  alerts: ['top.alerts', 'top.alerts.title'],
  license: ['top.license', 'top.license.title'],
  trust: ['top.trust', 'top.trust.title'],
};

function go(page) {
  const target = PAGE_META[page] ? page : 'check';
  state.page = target;
  $$('.page').forEach((section) => section.classList.toggle('active', section.dataset.page === target));
  $$('.nav-item, .tab').forEach((button) => button.classList.toggle('active', button.dataset.nav === target));
  const meta = PAGE_META[target];
  const eyebrow = $('#topbar-eyebrow');
  const title = $('#topbar-title');
  if (eyebrow) eyebrow.textContent = t(meta[0]);
  if (title) title.textContent = t(meta[1]);
  if (location.hash !== `#${target}`) history.replaceState(null, '', `#${target}`);
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (target === 'map') {
    renderMap();
    if (state.leafletMap) window.setTimeout(() => state.leafletMap.invalidateSize(), 120);
  }
  if (target === 'alerts') renderAlerts();
  if (target === 'license') renderLicense();
  if (target === 'report') renderReportForm();
}

function toggleLanguage() {
  state.lang = state.lang === 'hi' ? 'en' : 'hi';
  localStorage.setItem('sm_lang', state.lang);
  applyI18n();
  renderAll();
  if (state.lastLookup) runLookup(state.lastLookup.value, state.lastLookup.type);
}

async function pasteFromClipboard(target) {
  if (!target) return;
  try {
    const text = await navigator.clipboard.readText();
    if (text) {
      target.value = text.trim();
      target.focus();
    }
  } catch (_error) {
    toast(state.lang === 'hi' ? 'क्लिपबोर्ड पढ़ा नहीं जा सका। Ctrl+V दबाएँ।' : 'Clipboard unavailable. Press Ctrl+V to paste.', 'info', 'i-info');
  }
}

async function detectAndSetArea(statusTarget = '#report-location-status') {
  const status = $(statusTarget);
  const reportButton = $('#report-locate');
  const mapButton = $('#map-locate');
  const buttons = [reportButton, mapButton].filter(Boolean);
  const setStatus = (message, kind = '') => {
    if (status) {
      status.textContent = message;
      status.classList.toggle('is-error', kind === 'error');
      status.classList.toggle('is-success', kind === 'success');
    }
  };

  if (!('geolocation' in navigator)) {
    setStatus('This browser does not provide location access. Choose your area manually.', 'error');
    return;
  }
  if (!window.isSecureContext && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
    setStatus('Location access requires HTTPS or localhost. Choose your area manually.', 'error');
    return;
  }

  buttons.forEach((button) => { button.disabled = true; button.dataset.previousText = button.textContent.trim(); });
  setStatus('Requesting location permission…');
  try {
    const position = await new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: false,
        timeout: 10000,
        maximumAge: 120000,
      });
    });
    const result = await api('/areas/nearest', {
      method: 'POST',
      body: {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      },
    });
    const area = result.area;
    state.area = area.pincode;
    state.report.area = area.pincode;
    localStorage.setItem('sm_area', area.pincode);
    const globalArea = $('#global-area');
    const reportArea = $('#report-area');
    if (globalArea) globalArea.value = area.pincode;
    if (reportArea) reportArea.value = area.pincode;
    if (state.meta) {
      state.mapCity = area.city;
      state.mapPin = area.pincode;
      renderMap();
    }
    setStatus(`Area set to ${area.locality}, ${area.city} · approx. ${result.distance_km} km from nearest map point. Exact coordinates are not saved.`, 'success');
    toast(`Area updated: ${area.locality}, ${area.city}`, 'success', 'i-checkcircle');
  } catch (error) {
    const messages = {
      1: 'Location permission was denied. Choose your area manually.',
      2: 'Your location could not be determined. Choose your area manually.',
      3: 'Location request timed out. Try again or choose your area manually.',
    };
    if (typeof error.code === 'number') {
      setStatus(messages[error.code] || 'Location unavailable. Choose your area manually.', 'error');
    } else {
      setStatus(error.message || 'Could not resolve your area. Choose it manually.', 'error');
    }
  } finally {
    buttons.forEach((button) => { button.disabled = false; });
  }
}

function bindEvents() {
  document.addEventListener('click', (event) => {
    const nav = event.target.closest('[data-nav]');
    if (nav) {
      event.preventDefault();
      go(nav.dataset.nav);
    }
  });

  const lang = $('#lang-toggle');
  if (lang) lang.addEventListener('click', toggleLanguage);

  const globalArea = $('#global-area');
  if (globalArea) {
    globalArea.addEventListener('change', () => {
      state.area = globalArea.value;
      state.report.area = globalArea.value;
      localStorage.setItem('sm_area', state.area);
      renderReportForm();
    });
  }

  const reportLocate = $('#report-locate');
  if (reportLocate) reportLocate.addEventListener('click', () => detectAndSetArea('#report-location-status'));
  const mapLocate = $('#map-locate');
  if (mapLocate) mapLocate.addEventListener('click', () => {
    go('report');
    detectAndSetArea('#report-location-status');
  });

  const lookupTypes = $('#lookup-types');
  if (lookupTypes) {
    lookupTypes.addEventListener('click', (event) => {
      const button = event.target.closest('.seg');
      if (!button) return;
      state.lookupType = button.dataset.type || 'auto';
      $$('#lookup-types .seg').forEach((seg) => seg.classList.toggle('active', seg === button));
    });
  }

  const lookupForm = $('#lookup-form');
  if (lookupForm) {
    lookupForm.addEventListener('submit', (event) => {
      event.preventDefault();
      runLookup($('#lookup-input').value, state.lookupType);
    });
  }

  const smsLookupForm = $('#sms-lookup-form');
  if (smsLookupForm) smsLookupForm.addEventListener('submit', (event) => {
    event.preventDefault();
    runSmsLookup($('#sms-lookup-input').value);
  });

  const paste = $('#paste-btn');
  if (paste) paste.addEventListener('click', () => pasteFromClipboard($('#lookup-input')));
  const reportPaste = $('#report-paste');
  if (reportPaste) reportPaste.addEventListener('click', () => pasteFromClipboard($('#report-identifier')));

  const recent = $('#recent-list');
  if (recent) {
    recent.addEventListener('click', (event) => {
      const chip = event.target.closest('[data-recent-value]');
      if (!chip) return;
      const input = $('#lookup-input');
      if (input) input.value = chip.dataset.recentValue;
      runLookup(chip.dataset.recentValue, chip.dataset.recentType || 'auto');
    });
  }

  const result = $('#lookup-result');
  if (result) {
    result.addEventListener('click', (event) => {
      const button = event.target.closest('[data-action]');
      if (!button) return;
      const action = button.dataset.action;
      if (action === 'prefill') {
        prefillReport(button.dataset.type || 'auto', button.dataset.value || '', button.dataset.scam || '');
      } else if (action === 'challenge') {
        openChallengeModal(button.dataset.type || 'auto', button.dataset.value || '');
      } else if (action === 'copy') {
        copyText(button.dataset.copy || '');
      } else if (action === 'retry') {
        if (state.lastLookup) runLookup(state.lastLookup.value, state.lastLookup.type);
      }
    });
  }

  const reportTypeSelect = $('#report-type-select');
  if (reportTypeSelect) {
    reportTypeSelect.addEventListener('change', () => {
      state.reportType = reportTypeSelect.value || 'auto';
    });
  }

  const channelSelect = $('#channel-select');
  if (channelSelect) {
    channelSelect.addEventListener('change', () => {
      state.report.channel = channelSelect.value;
    });
  }

  const scamSelect = $('#scam-select');
  if (scamSelect) {
    scamSelect.addEventListener('change', () => {
      state.report.scam = scamSelect.value;
    });
  }

  const when = $('#report-when');
  if (when) {
    when.addEventListener('change', () => {
      state.report.when = when.value;
      const custom = $('#report-custom-time');
      if (!custom) return;
      custom.hidden = when.value !== 'custom';
      if (when.value === 'custom' && !custom.value) {
        const now = new Date();
        const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
        custom.value = local.toISOString().slice(0, 16);
      }
    });
  }

  const note = $('#report-note');
  if (note) note.addEventListener('input', updateNoteCount);

  const reportForm = $('#report-form');
  if (reportForm) reportForm.addEventListener('submit', submitReport);
  const evidenceInput = $('#sms-evidence-file');
  if (evidenceInput) evidenceInput.addEventListener('change', () => {
    const screenshotToggle = $('#report-screenshot');
    if (screenshotToggle) screenshotToggle.checked = Boolean(evidenceInput.files && evidenceInput.files.length);
    const help = $('#sms-evidence-help');
    if (help && evidenceInput.files && evidenceInput.files[0]) help.textContent = `${evidenceInput.files[0].name} selected. It will be checked against the pasted SMS.`;
  });

  const successCheck = $('#success-check');
  if (successCheck) {
    successCheck.addEventListener('click', () => {
      if (!state.lastReport) return;
      go('check');
      const input = $('#lookup-input');
      if (input) input.value = state.lastReport.value;
      runLookup(state.lastReport.value, state.lastReport.type);
    });
  }
  const successAgain = $('#success-again');
  if (successAgain) successAgain.addEventListener('click', resetReportForm);

  const cityTabs = $('#city-tabs');
  if (cityTabs) {
    cityTabs.addEventListener('click', (event) => {
      const button = event.target.closest('[data-city]');
      if (!button) return;
      state.mapCity = button.dataset.city;
      state.mapPin = null;
      renderMap();
    });
  }

  const mapCanvas = $('#map-canvas');
  if (mapCanvas) {
    mapCanvas.addEventListener('click', (event) => {
      const alertButton = event.target.closest('[data-map-alert-pin]');
      if (alertButton && alertButton.dataset.mapAlertPin) {
        state.mapPin = alertButton.dataset.mapAlertPin;
        renderMap();
        return;
      }
      const marker = event.target.closest('.marker');
      if (marker && marker.dataset.pin) selectMapPin(marker.dataset.pin);
    });
    mapCanvas.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      const marker = event.target.closest('.marker');
      if (marker && marker.dataset.pin) {
        event.preventDefault();
        selectMapPin(marker.dataset.pin);
      }
    });
  }

  const mapList = $('#map-list');
  if (mapList) {
    mapList.addEventListener('click', (event) => {
      const item = event.target.closest('[data-pin]');
      if (item) selectMapPin(item.dataset.pin);
    });
  }

  const mapAlertList = $('#map-live-alert-list');
  if (mapAlertList) {
    mapAlertList.addEventListener('click', (event) => {
      const button = event.target.closest('[data-map-alert-pin]');
      if (!button) return;
      state.mapPin = button.dataset.mapAlertPin;
      renderMap();
    });
  }

  const mapDetail = $('#map-detail');
  if (mapDetail) {
    mapDetail.addEventListener('click', (event) => {
      const button = event.target.closest('[data-action]');
      if (!button) return;
      if (button.dataset.action === 'map-alerts') {
        state.alertPin = button.dataset.pin;
        go('alerts');
        renderAlerts();
      } else if (button.dataset.action === 'map-report') {
        state.report.area = button.dataset.pin;
        go('report');
        renderReportForm();
      }
    });
  }

  const mapRefresh = $('#map-refresh');
  if (mapRefresh) mapRefresh.addEventListener('click', refreshMap);
  const heatToggle = $('#map-heat-toggle');
  if (heatToggle) heatToggle.addEventListener('click', () => {
    state.leafletHeatVisible = !state.leafletHeatVisible;
    heatToggle.setAttribute('aria-pressed', String(state.leafletHeatVisible));
    heatToggle.textContent = `Heat layer: ${state.leafletHeatVisible ? 'on' : 'off'}`;
    if (state.leafletMap && state.leafletHeat) {
      if (state.leafletHeatVisible) state.leafletHeat.addTo(state.leafletMap);
      else state.leafletMap.removeLayer(state.leafletHeat);
    }
  });

  const alertArea = $('#alert-area');
  if (alertArea) {
    alertArea.addEventListener('change', () => {
      state.alertPin = alertArea.value;
      renderAlerts();
    });
  }
  const alertsRefresh = $('#alerts-refresh');
  if (alertsRefresh) alertsRefresh.addEventListener('click', refreshAlerts);
  const alertsList = $('#alerts-list');
  if (alertsList) {
    alertsList.addEventListener('click', (event) => {
      const button = event.target.closest('[data-action="alert-map"]');
      if (!button) return;
      state.mapCity = button.dataset.city || 'All India';
      state.mapPin = button.dataset.pin;
      go('map');
      renderMap();
    });
  }

  const licenseFile = $('#license-file');
  if (licenseFile) licenseFile.addEventListener('change', () => handleLicenseFile(licenseFile.files[0]));
  const overlayFile = $('#overlay-license-file');
  if (overlayFile) overlayFile.addEventListener('change', () => handleLicenseFile(overlayFile.files[0]));
  const dropzone = $('#license-dropzone');
  if (dropzone) {
    ['dragenter', 'dragover'].forEach((type) => dropzone.addEventListener(type, (event) => {
      event.preventDefault();
      dropzone.classList.add('dragover');
    }));
    ['dragleave', 'drop'].forEach((type) => dropzone.addEventListener(type, (event) => {
      event.preventDefault();
      dropzone.classList.remove('dragover');
    }));
    dropzone.addEventListener('drop', (event) => {
      const file = event.dataTransfer && event.dataTransfer.files ? event.dataTransfer.files[0] : null;
      if (file) handleLicenseFile(file);
    });
  }

  const issueFive = $('#issue-5min');
  if (issueFive) issueFive.addEventListener('click', () => issueDemoLicense(5));
  const issueYear = $('#issue-year');
  if (issueYear) issueYear.addEventListener('click', () => issueDemoLicense(525600));
  const seed = $('#seed-demo');
  if (seed) seed.addEventListener('click', seedDemo);
  const reset = $('#reset-data');
  if (reset) reset.addEventListener('click', resetData);

  const overlayIssue = $('#overlay-issue');
  if (overlayIssue) overlayIssue.addEventListener('click', () => issueDemoLicense(5));
  const overlayRetry = $('#overlay-retry');
  if (overlayRetry) {
    overlayRetry.addEventListener('click', async () => {
      const data = await refreshLicense();
      if (data && data.valid) {
        hideLicenseOverlay();
        await refreshData();
      } else {
        toast(t('toast.allquiet'), 'info', 'i-info');
      }
    });
  }

  $$('.try-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      const value = chip.dataset.try;
      const input = $('#lookup-input');
      if (input) input.value = value;
      state.lookupType = 'auto';
      go('check');
      runLookup(value, 'auto');
    });
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeModal();
    if (event.metaKey || event.ctrlKey || event.altKey) return;
    if (event.target.matches('input, textarea, select, [contenteditable="true"]')) return;
    const shortcuts = { '1': 'check', '2': 'report', '3': 'map', '4': 'alerts', '5': 'license', '6': 'trust' };
    if (shortcuts[event.key]) go(shortcuts[event.key]);
  });

  window.addEventListener('hashchange', () => {
    const page = location.hash.replace('#', '') || 'check';
    if (page !== state.page) go(page);
  });
}

async function init() {
  // Fetch only browser-safe map configuration. VirusTotal credentials remain server-side.
  try {
    const configResponse = await fetch('/public-config', { cache: 'no-store' });
    if (configResponse.ok) window.SCAMMAP_PUBLIC_CONFIG = await configResponse.json();
  } catch (error) { console.warn('Public map configuration unavailable; trying CARTO without a key.', error); }
  if (state.lang !== 'hi' && state.lang !== 'en') state.lang = 'en';
  bindEvents();
  applyI18n();
  const initial = location.hash.replace('#', '') || 'check';
  go(initial);
  await refreshReportSession();
  await refreshData();
  startLicenseTimers();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

