"""Static reference data from the PRD appendix.

Everything in this file is deliberately data, not behaviour.  The API accepts
exactly these areas and the lookup treats the verified registry as authoritative.
"""

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# Appendix B - the 25 area codes used by the judging tool.
# ---------------------------------------------------------------------------

AREAS: list[dict[str, Any]] = [
    {"pincode": "560102", "locality": "HSR Layout", "city": "Bengaluru", "lat": 12.9116, "lng": 77.6473},
    {"pincode": "560038", "locality": "Indiranagar", "city": "Bengaluru", "lat": 12.9784, "lng": 77.6408},
    {"pincode": "560034", "locality": "Koramangala", "city": "Bengaluru", "lat": 12.9352, "lng": 77.6245},
    {"pincode": "560066", "locality": "Whitefield", "city": "Bengaluru", "lat": 12.9698, "lng": 77.7500},
    {"pincode": "560076", "locality": "BTM Layout", "city": "Bengaluru", "lat": 12.9166, "lng": 77.6101},
    {"pincode": "560011", "locality": "Jayanagar", "city": "Bengaluru", "lat": 12.9299, "lng": 77.5826},
    {"pincode": "560037", "locality": "Marathahalli", "city": "Bengaluru", "lat": 12.9591, "lng": 77.6974},
    {"pincode": "560103", "locality": "Bellandur", "city": "Bengaluru", "lat": 12.9260, "lng": 77.6762},
    {"pincode": "560100", "locality": "Electronic City", "city": "Bengaluru", "lat": 12.8452, "lng": 77.6602},
    {"pincode": "560078", "locality": "JP Nagar", "city": "Bengaluru", "lat": 12.9077, "lng": 77.5851},
    {"pincode": "560003", "locality": "Malleshwaram", "city": "Bengaluru", "lat": 13.0035, "lng": 77.5709},
    {"pincode": "560010", "locality": "Rajajinagar", "city": "Bengaluru", "lat": 12.9915, "lng": 77.5520},
    {"pincode": "560024", "locality": "Hebbal", "city": "Bengaluru", "lat": 13.0358, "lng": 77.5970},
    {"pincode": "560064", "locality": "Yelahanka", "city": "Bengaluru", "lat": 13.1007, "lng": 77.5963},
    {"pincode": "560070", "locality": "Banashankari", "city": "Bengaluru", "lat": 12.9250, "lng": 77.5468},
    {"pincode": "400050", "locality": "Bandra West", "city": "Mumbai", "lat": 19.0596, "lng": 72.8295},
    {"pincode": "110016", "locality": "Hauz Khas", "city": "Delhi", "lat": 28.5494, "lng": 77.2001},
    {"pincode": "500081", "locality": "Madhapur", "city": "Hyderabad", "lat": 17.4486, "lng": 78.3908},
    {"pincode": "600020", "locality": "Adyar", "city": "Chennai", "lat": 13.0012, "lng": 80.2565},
    {"pincode": "411014", "locality": "Viman Nagar", "city": "Pune", "lat": 18.5679, "lng": 73.9143},
    {"pincode": "700091", "locality": "Salt Lake Sector V", "city": "Kolkata", "lat": 22.5790, "lng": 88.4290},
    {"pincode": "380015", "locality": "Satellite", "city": "Ahmedabad", "lat": 23.0260, "lng": 72.5085},
    {"pincode": "302017", "locality": "Malviya Nagar", "city": "Jaipur", "lat": 26.8570, "lng": 75.8080},
    {"pincode": "226010", "locality": "Gomti Nagar", "city": "Lucknow", "lat": 26.8540, "lng": 80.9990},
    {"pincode": "682030", "locality": "Kakkanad", "city": "Kochi", "lat": 10.0159, "lng": 76.3419},
]

AREA_BY_PINCODE: dict[str, dict[str, Any]] = {a["pincode"]: a for a in AREAS}
AREA_BY_LOCALITY: dict[str, dict[str, Any]] = {a["locality"].lower(): a for a in AREAS}

CITIES: list[str] = sorted({a["city"] for a in AREAS})


def find_area(pincode: str | None = None, locality: str | None = None) -> dict[str, Any] | None:
    """Resolve an area without ever accepting a precise address."""
    if pincode:
        pin = str(pincode).strip()
        if pin in AREA_BY_PINCODE:
            return AREA_BY_PINCODE[pin]
    if locality:
        loc = " ".join(str(locality).strip().lower().split())
        if loc in AREA_BY_LOCALITY:
            return AREA_BY_LOCALITY[loc]
        # Tolerate "HSR Layout, Bengaluru" and similar user input.
        for name, area in AREA_BY_LOCALITY.items():
            if loc.startswith(name) or name.startswith(loc):
                return area
    return None


def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    from math import asin, cos, radians, sin, sqrt

    r = 6371.0088
    p1, p2 = radians(lat1), radians(lat2)
    dp = radians(lat2 - lat1)
    dl = radians(lng2 - lng1)
    h = sin(dp / 2) ** 2 + cos(p1) * cos(p2) * sin(dl / 2) ** 2
    return 2 * r * asin(sqrt(h))


def resolve_nearest_area(lat: float, lng: float, max_distance_km: float = 25.0) -> tuple[dict[str, Any] | None, float | None]:
    """Map a user-approved coordinate to a curated locality, never a street address.

    This is deliberately offline: it uses only the static area coordinates in
    this module and Python's standard library. Coordinates are not persisted.
    """
    from math import isfinite

    if not isfinite(lat) or not isfinite(lng) or not (-90 <= lat <= 90) or not (-180 <= lng <= 180):
        raise ValueError("Coordinates are outside valid latitude/longitude ranges")
    nearest = min(AREAS, key=lambda area: haversine_km(lat, lng, area["lat"], area["lng"]))
    distance = haversine_km(lat, lng, nearest["lat"], nearest["lng"])
    if distance > max_distance_km:
        return None, distance
    return nearest, distance


# ---------------------------------------------------------------------------
# Appendix C - verified businesses and helplines.
# Values are stored in the same canonical form the normaliser produces.
# ---------------------------------------------------------------------------

VERIFIED: list[dict[str, str]] = [
    {"type": "phone", "value": "+911930", "belongs_to": "National Cybercrime Helpline"},
    {"type": "phone", "value": "+911909", "belongs_to": "TRAI Do Not Disturb"},
    {"type": "phone", "value": "+9118001600", "belongs_to": "HDFC Bank customer care"},
    {"type": "phone", "value": "+9118002600", "belongs_to": "HDFC Bank customer care"},
    {"type": "phone", "value": "+9118001080", "belongs_to": "ICICI Bank customer care"},
    {"type": "phone", "value": "+9118001234", "belongs_to": "State Bank of India customer care"},
    {"type": "phone", "value": "+9118002100", "belongs_to": "State Bank of India customer care"},
    {"type": "phone", "value": "+9118604195555", "belongs_to": "Axis Bank customer care"},
    {"type": "phone", "value": "+9118602662666", "belongs_to": "Kotak Mahindra Bank customer care"},
    {"type": "sender_id", "value": "HDFCBK", "belongs_to": "HDFC Bank SMS sender"},
    {"type": "sender_id", "value": "ICICIB", "belongs_to": "ICICI Bank SMS sender"},
    {"type": "sender_id", "value": "SBIINB", "belongs_to": "State Bank of India SMS sender"},
    {"type": "sender_id", "value": "AXISBK", "belongs_to": "Axis Bank SMS sender"},
    {"type": "sender_id", "value": "KOTAKB", "belongs_to": "Kotak Mahindra Bank SMS sender"},
    {"type": "url", "value": "https://cybercrime.gov.in", "belongs_to": "National Cyber Crime Reporting Portal"},
    {"type": "url", "value": "https://sancharsaathi.gov.in", "belongs_to": "Sanchar Saathi"},
    {"type": "phone", "value": "+918041002233", "belongs_to": "Fresh Bakes, Indiranagar (made up)"},
    {"type": "phone", "value": "+918025530190", "belongs_to": "Koramangala Pharmacy (made up)"},
    {"type": "upi", "value": "freshbakes@okaxis", "belongs_to": "Fresh Bakes, Indiranagar (made up)"},
]

VERIFIED_BY_KEY: dict[tuple[str, str], dict[str, str]] = {
    (v["type"], v["value"]): v for v in VERIFIED
}


def verified_entry(identifier_type: str, canonical: str) -> dict[str, str] | None:
    return VERIFIED_BY_KEY.get((identifier_type, canonical))


# ---------------------------------------------------------------------------
# Report channels and scam types.
# ---------------------------------------------------------------------------

CHANNELS: list[str] = [
    "Phone call",
    "SMS or WhatsApp",
    "QR code",
    "Fake website",
    "UPI request",
    "Something else",
]

CHANNEL_ALIASES: dict[str, str] = {
    "phone": "Phone call",
    "call": "Phone call",
    "phone call": "Phone call",
    "sms": "SMS or WhatsApp",
    "whatsapp": "SMS or WhatsApp",
    "sms or whatsapp": "SMS or WhatsApp",
    "qr": "QR code",
    "qr code": "QR code",
    "website": "Fake website",
    "fake website": "Fake website",
    "link": "Fake website",
    "upi": "UPI request",
    "upi request": "UPI request",
    "other": "Something else",
    "something else": "Something else",
}


def canonical_channel(value: str | None) -> str:
    if not value:
        return "Something else"
    return CHANNEL_ALIASES.get(str(value).strip().lower(), "Something else")


SCAM_TYPES: list[dict[str, str]] = [
    {"id": "digital-arrest", "label": "Digital arrest", "hindi": "डिजिटल अरेस्ट", "icon": "shield-alert"},
    {"id": "fake-kyc-link", "label": "Fake KYC link", "hindi": "फ़र्ज़ी KYC लिंक", "icon": "link"},
    {"id": "upi-refund-qr", "label": "UPI refund QR", "hindi": "UPI रिफ़ंड QR", "icon": "qr"},
    {"id": "investment-group", "label": "Investment group", "hindi": "निवेश ग्रुप", "icon": "trending-up"},
    {"id": "courier-customs", "label": "Courier / customs", "hindi": "कूरियर / कस्टम", "icon": "package"},
    {"id": "job-offer", "label": "Fake job offer", "hindi": "फ़र्ज़ी नौकरी", "icon": "briefcase"},
    {"id": "lottery-prize", "label": "Lottery / prize", "hindi": "लॉटरी / इनाम", "icon": "gift"},
    {"id": "loan-app-harassment", "label": "Loan app harassment", "hindi": "लोन ऐप परेशानी", "icon": "smartphone"},
    {"id": "electricity-disconnection", "label": "Power cut SMS", "hindi": "बिजली कटौती SMS", "icon": "zap"},
    {"id": "fake-customer-care", "label": "Fake customer care", "hindi": "फ़र्ज़ी कस्टमर केयर", "icon": "headset"},
    {"id": "otp-call", "label": "OTP / card call", "hindi": "OTP / कार्ड कॉल", "icon": "key"},
    {"id": "sextortion", "label": "Sextortion", "hindi": "सेक्सटॉर्शन", "icon": "video"},
]

SCAM_TYPE_IDS: set[str] = {s["id"] for s in SCAM_TYPES}
SCAM_TYPE_BY_ID: dict[str, dict[str, str]] = {s["id"]: s for s in SCAM_TYPES}


def canonical_scam_type(value: str | None) -> str:
    """Unknown values are accepted but treated as ``other`` (PRD Appendix C)."""
    if not value:
        return "other"
    raw = str(value).strip().lower().replace(" ", "-")
    return raw if raw in SCAM_TYPE_IDS else "other"


def scam_label(value: str) -> str:
    if value == "other":
        return "Other"
    entry = SCAM_TYPE_BY_ID.get(value)
    return entry["label"] if entry else "Other"


# Short, practical safety advice shown after a lookup.
ADVICE: dict[str, dict[str, Any]] = {
    "digital-arrest": {
        "title": "No real police arrest happens over a video call",
        "steps": [
            "Hang up. Police, CBI and courts never demand payment on a call.",
            "Do not share Aadhaar, bank details, OTPs or screen access.",
            "Call the cybercrime helpline 1930 and report the number.",
        ],
    },
    "fake-kyc-link": {
        "title": "Banks never ask for KYC through a link in SMS",
        "steps": [
            "Do not open the link or enter your net-banking password.",
            "Open your bank app directly and check for messages there.",
            "Report the SMS to 1909 and the link on cybercrime.gov.in.",
        ],
    },
    "upi-refund-qr": {
        "title": "Scanning a QR code only sends money, it never receives it",
        "steps": [
            "Never scan a QR code to receive a refund.",
            "Do not approve a UPI collect request you did not start.",
            "Report the UPI ID to your bank and on 1930.",
        ],
    },
    "investment-group": {
        "title": "Guaranteed profits in a WhatsApp group are a trap",
        "steps": [
            "Leave the group. Do not top up 'fees' or 'taxes'.",
            "Check SEBI registration before any investment.",
            "Report the group and UPI IDs on cybercrime.gov.in.",
        ],
    },
    "courier-customs": {
        "title": "Customs does not collect fines over WhatsApp or UPI",
        "steps": [
            "Do not pay any 'clearance' or 'parcel' fee.",
            "Track the parcel only on the official courier website.",
            "Call 1930 if you have already paid.",
        ],
    },
    "job-offer": {
        "title": "A real job never asks you to pay a deposit",
        "steps": [
            "Never pay registration, training or task deposits.",
            "Do not share bank accounts or OTPs with 'recruiters'.",
            "Report the number and group on 1930.",
        ],
    },
    "lottery-prize": {
        "title": "You cannot win a lottery you never entered",
        "steps": [
            "Do not pay any processing fee or tax to claim a prize.",
            "Do not share bank or card details.",
            "Report the sender and number to 1909 / 1930.",
        ],
    },
    "loan-app-harassment": {
        "title": "Instant loan apps that threaten contacts are illegal",
        "steps": [
            "Do not pay. Screenshot the threats and loan details.",
            "Revoke contacts and gallery permissions immediately.",
            "Report the app and number on cybercrime.gov.in and 1930.",
        ],
    },
    "electricity-disconnection": {
        "title": "Power companies do not send payment links at night",
        "steps": [
            "Do not call the number in the SMS or scan its QR.",
            "Pay only through your electricity board's official app.",
            "Forward the SMS to 1909 and report on 1930.",
        ],
    },
    "fake-customer-care": {
        "title": "Search-result customer care numbers are often fake",
        "steps": [
            "Use the number printed on your card or the official app.",
            "Never install a screen-sharing app for support.",
            "Report the number on 1930.",
        ],
    },
    "otp-call": {
        "title": "No bank employee will ever ask for your OTP",
        "steps": [
            "Hang up. Never read out an OTP, PIN or CVV.",
            "Do not approve a UPI request or install remote-access apps.",
            "If money moved, call your bank and 1930 immediately.",
        ],
    },
    "sextortion": {
        "title": "A video call that becomes blackmail is a crime",
        "steps": [
            "Do not pay. Paying increases the demands.",
            "Save evidence, block the account and report it.",
            "Call 1930 or file at cybercrime.gov.in. You are not alone.",
        ],
    },
    "other": {
        "title": "Stop, verify and report",
        "steps": [
            "Do not pay or share OTPs, passwords or screen access.",
            "Verify the person through an official number you find yourself.",
            "Report it on 1930 or cybercrime.gov.in.",
        ],
    },
}

HELPLINES: list[dict[str, str]] = [
    {"label": "Cybercrime helpline", "value": "1930", "tel": "1930"},
    {"label": "TRAI spam reporting", "value": "1909", "tel": "1909"},
    {"label": "Cybercrime portal", "value": "cybercrime.gov.in", "url": "https://cybercrime.gov.in"},
]
