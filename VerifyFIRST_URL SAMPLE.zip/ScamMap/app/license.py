"""Prepaid-style licence: signed JSON, checked on every request, renewed live.

The private key never ships with the server.  Only the public key is embedded
below.  The demo helper can sign licences from ``secrets/license_private_key.pem``
when ``ALLOW_DEMO_LICENSE_ISSUE`` is enabled; turn that off in production.
"""

from __future__ import annotations

import base64
import json
import os
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

# Public half of the keypair generated for this prototype.
# Replace it (and the offline private key) for a real deployment.
DEFAULT_PUBLIC_KEY_B64 = "CKSFl86I+OMdr8Pdk50kJ16UrCfbZUh00S8E5eKYHW4="

IST = timezone(timedelta(hours=5, minutes=30))
CLOCK_ROLLBACK_TOLERANCE_SECONDS = 120
CLOCK_WRITE_INTERVAL_SECONDS = 5


class LicenseError(Exception):
    def __init__(self, code: str, message: str = ""):
        super().__init__(message or code)
        self.code = code


def parse_iso(value: str) -> datetime:
    text = str(value or "").strip()
    if not text:
        raise ValueError("missing timestamp")
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=IST)
    return dt


def to_ist_iso(dt: datetime | float) -> str:
    if isinstance(dt, (int, float)):
        dt = datetime.fromtimestamp(dt, tz=timezone.utc)
    return dt.astimezone(IST).isoformat(timespec="seconds")


def _canonical(payload: dict[str, Any]) -> bytes:
    body = {k: v for k, v in payload.items() if k != "signature"}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _load_public_key(value: str) -> ed25519.Ed25519PublicKey:
    text = (value or "").strip()
    if not text:
        raise ValueError("public key is empty")
    path = Path(text)
    if path.exists() and path.is_file():
        text = path.read_text(encoding="utf-8").strip()
    if "BEGIN PUBLIC KEY" in text:
        return serialization.load_pem_public_key(text.encode("utf-8"))  # type: ignore[return-value]
    raw = base64.b64decode(text)
    if len(raw) != 32:
        raise ValueError("Ed25519 public key must be 32 raw bytes")
    return ed25519.Ed25519PublicKey.from_public_bytes(raw)


def _load_private_key(path: str | Path) -> ed25519.Ed25519PrivateKey:
    data = Path(path).read_bytes()
    key = serialization.load_pem_private_key(data, password=None)
    if not isinstance(key, ed25519.Ed25519PrivateKey):
        raise ValueError("private key is not Ed25519")
    return key


def sign_license(
    private_key: ed25519.Ed25519PrivateKey,
    licensee: str,
    expires_at: str,
    issued_at: str | None = None,
    license_id: str | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "licensee": licensee,
        "expires_at": expires_at,
        "issued_at": issued_at or to_ist_iso(time.time()),
        "license_id": license_id or "lic_" + uuid.uuid4().hex[:12],
    }
    signature = private_key.sign(_canonical(payload))
    payload["signature"] = base64.b64encode(signature).decode("ascii")
    return payload


def verify_license(
    license_obj: Any,
    public_key_b64: str = DEFAULT_PUBLIC_KEY_B64,
) -> tuple[bool, dict[str, Any] | None, str | None]:
    """Return (valid, payload, error_code). Expiry is a separate status."""
    if not isinstance(license_obj, dict):
        return False, None, "INVALID_LICENSE"
    for field in ("licensee", "expires_at", "signature"):
        if not isinstance(license_obj.get(field), str) or not license_obj[field].strip():
            return False, None, "INVALID_LICENSE"
    try:
        parse_iso(license_obj["expires_at"])
    except Exception:
        return False, None, "INVALID_LICENSE"
    try:
        signature = base64.b64decode(license_obj["signature"], validate=True)
    except Exception:
        return False, None, "INVALID_SIGNATURE"
    try:
        public_key = _load_public_key(public_key_b64)
        public_key.verify(signature, _canonical(license_obj))
    except InvalidSignature:
        return False, None, "INVALID_SIGNATURE"
    except Exception:
        return False, None, "INVALID_SIGNATURE"
    return True, dict(license_obj), None


class LicenseManager:
    def __init__(
        self,
        db: Any,
        license_path: str | Path,
        public_key_b64: str = DEFAULT_PUBLIC_KEY_B64,
        private_key_path: str | Path | None = None,
        now_fn: Any = time.time,
    ):
        self.db = db
        self.path = Path(license_path)
        self.public_key_b64 = public_key_b64
        self.private_key_path = Path(private_key_path) if private_key_path else None
        self.now_fn = now_fn
        self._lock = threading.RLock()
        self._license: dict[str, Any] | None = None
        self._verify_error: str | None = None
        self._last_seen_write = 0.0
        self.load()

    def ensure_default(self, default_file: str | Path) -> None:
        if not self.path.exists():
            source = Path(default_file)
            if source.exists():
                self.path.parent.mkdir(parents=True, exist_ok=True)
                self.path.write_bytes(source.read_bytes())
                self.load()

    def load(self) -> None:
        with self._lock:
            self._license = None
            self._verify_error = None
            if not self.path.exists():
                self._verify_error = "LICENSE_MISSING"
                return
            try:
                obj = json.loads(self.path.read_text(encoding="utf-8"))
            except Exception:
                self._verify_error = "INVALID_LICENSE"
                return
            valid, payload, error = verify_license(obj, self.public_key_b64)
            if not valid:
                self._verify_error = error or "INVALID_LICENSE"
                return
            self._license = payload

    def _check_clock(self, now: float) -> bool:
        """Return True if the clock went backwards. Persist the high-water mark."""
        stored_raw = self.db.get_meta("last_seen_ts")
        stored = float(stored_raw) if stored_raw else 0.0
        if stored and now < stored - CLOCK_ROLLBACK_TOLERANCE_SECONDS:
            return True
        if now - self._last_seen_write >= CLOCK_WRITE_INTERVAL_SECONDS:
            self.db.max_meta_float("last_seen_ts", now)
            self._last_seen_write = now
        return False

    def status(self) -> dict[str, Any]:
        with self._lock:
            now = float(self.now_fn())
            server_time = to_ist_iso(now)
            rollback = self._check_clock(now)

            base: dict[str, Any] = {
                "server_time": server_time,
                "valid": False,
                "signature_verified": self._license is not None,
                "licensee": self._license.get("licensee") if self._license else None,
                "expires_at": self._license.get("expires_at") if self._license else None,
                "issued_at": self._license.get("issued_at") if self._license else None,
                "license_id": self._license.get("license_id") if self._license else None,
                "seconds_remaining": 0,
            }

            if rollback:
                return {**base, "status": "CLOCK_ROLLBACK", "error": "CLOCK_ROLLBACK"}

            if self._license is None:
                code = self._verify_error or "LICENSE_MISSING"
                status = "INVALID" if code == "INVALID_SIGNATURE" else "MISSING"
                return {**base, "status": status, "error": code}

            try:
                expires_ts = parse_iso(self._license["expires_at"]).timestamp()
            except Exception:
                return {**base, "status": "INVALID", "error": "INVALID_LICENSE"}

            remaining = max(0, int(expires_ts - now))
            if now >= expires_ts:
                return {
                    **base,
                    "status": "EXPIRED",
                    "error": "LICENSE_EXPIRED",
                    "seconds_remaining": 0,
                }

            return {
                **base,
                "status": "VALID",
                "error": None,
                "valid": True,
                "seconds_remaining": remaining,
            }

    def upload(self, license_obj: Any) -> dict[str, Any]:
        valid, payload, error = verify_license(license_obj, self.public_key_b64)
        if not valid:
            raise LicenseError(error or "INVALID_LICENSE")
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.path)
            self._license = payload
            self._verify_error = None
            # A successful renewal also clears a clock high-water mark, so a
            # judge can recover the demo after deliberately moving the clock.
            now = float(self.now_fn())
            self.db.set_meta("last_seen_ts", str(now))
            self._last_seen_write = now
        return self.status()

    def issue_and_install(self, minutes: int, licensee: str = "Demo Bank") -> dict[str, Any]:
        if self.private_key_path is None or not self.private_key_path.exists():
            raise LicenseError("DEMO_KEY_MISSING", "demo signing key is not available")
        now = float(self.now_fn())
        expires = datetime.fromtimestamp(now, tz=timezone.utc) + timedelta(minutes=minutes)
        private_key = _load_private_key(self.private_key_path)
        payload = sign_license(
            private_key,
            licensee=licensee,
            expires_at=to_ist_iso(expires),
        )
        return self.upload(payload)
