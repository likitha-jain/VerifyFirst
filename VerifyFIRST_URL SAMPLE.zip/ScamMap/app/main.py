"""FastAPI application for the Community Scam Map.

The seven PRD endpoints live here, plus a small demo surface and the static
mobile web app.  Access logs are disabled because lookup URLs contain the
identifier being checked (privacy rule: no personal data in logs).
"""

from __future__ import annotations

import asyncio
import hashlib
import json
from difflib import SequenceMatcher
import logging
import os
import re
import secrets
import threading
import time
import uuid
from io import BytesIO
from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from PIL import Image, ImageOps

try:
    import pytesseract
except ImportError:  # OCR is optional at runtime; evidence is then inconclusive.
    pytesseract = None

from .areas import (
    ADVICE,
    AREAS,
    AREA_BY_PINCODE,
    CHANNELS,
    CITIES,
    HELPLINES,
    SCAM_TYPES,
    VERIFIED,
    canonical_channel,
    canonical_scam_type,
    find_area,
    haversine_km,
    resolve_nearest_area,
    verified_entry,
)
from .db import Database, DuplicateReport
from .identifiers import (
    IdentifierError,
    detect_type,
    normalize_identifier,
    sanitize_ip_prefix,
    validate_reporter_id,
)
from .license import (
    DEFAULT_PUBLIC_KEY_B64,
    LicenseError,
    LicenseManager,
    parse_iso,
    to_ist_iso,
)
from .seed import seed_demo
from .trust import TrustEngine, normalise_note
from .virustotal import check_url_reputation
from .message_model import predict_message, MessageModelNotReady
from .report_match_model import assess_report_match

# Privacy: uvicorn's access log writes the full query string, including the
# phone number in /lookup?value=...  Turn it off even when started with the
# uvicorn CLI.  Errors still reach the console.
logging.getLogger("uvicorn.access").disabled = True

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "app" / "static"

DAILY_SESSION_REPORT_LIMIT = 5
IST = timezone(timedelta(hours=5, minutes=30))
REPORT_SESSION_COOKIE = "scammap_session"


def _ist_day() -> str:
    return datetime.now(IST).date().isoformat()


def _session_token_hash(request: Request) -> str | None:
    token = request.cookies.get(REPORT_SESSION_COOKIE, "")
    # token_urlsafe(32) is 43 URL-safe characters. Reject malformed cookies.
    if not re.fullmatch(r"[A-Za-z0-9_-]{40,60}", token):
        return None
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _report_summary(scam_type: str, channel: str, note: str, has_screenshot: bool, amount: int) -> str:
    """Return a concise reporter-facing gist without echoing obvious personal data."""
    safe = (note or "").strip()
    safe = re.sub(r"https?://\S+|www\.\S+", "[link]", safe, flags=re.I)
    safe = re.sub(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", "[email or UPI ID]", safe, flags=re.I)
    safe = re.sub(
        r"\b(otp|pin|cvv|password|passcode|verification code)\s*(?:is|:|was|of)?\s*[:#-]?\s*\d{4,8}\b",
        r"\1 [redacted]",
        safe,
        flags=re.I,
    )
    safe = re.sub(r"(?<!\w)(?:\+?91[-\s]?)?[6-9]\d{9}(?!\w)", "[phone number]", safe)
    safe = re.sub(r"\b\d{8,18}\b", "[sensitive number]", safe)
    safe = re.sub(r"\s+", " ", safe)
    safe = safe[:260].strip()
    category = next(
        (item.get("label", "") for item in SCAM_TYPES if item.get("id") == scam_type),
        scam_type.replace("-", " ").replace("_", " ").strip().title(),
    )
    gist = f"{category} report received through {channel.lower()}."
    if safe:
        gist += f" Report details: {safe}"
    if has_screenshot:
        gist += " Screenshot evidence was indicated."
    if amount > 0:
        gist += f" Reported amount involved: ₹{amount:,}."
    return gist


@dataclass
class Settings:
    data_dir: Path
    license_file: Path
    public_key_b64: str = DEFAULT_PUBLIC_KEY_B64
    private_key_file: Path | None = None
    demo_mode: bool = False
    allow_demo_license_issue: bool = False
    admin_token: str = ""
    cors_origins: tuple[str, ...] = ("http://localhost:8000", "http://127.0.0.1:8000")
    rate_reporter_limit: int = 30
    rate_ip_limit: int = 120
    rate_window_seconds: int = 600
    virustotal_api_key: str = ""
    carto_api_key: str = ""
    judge_api_compat: bool = False

    @classmethod
    def from_env(cls) -> "Settings":
        load_dotenv(BASE_DIR / ".env", override=False)
        data_dir = Path(os.environ.get("SCAMMAP_DATA_DIR", str(BASE_DIR / "data")))
        license_file = Path(os.environ.get("SCAMMAP_LICENSE_FILE", str(data_dir / "license.json")))
        private_key_raw = os.environ.get("SCAMMAP_PRIVATE_KEY", "").strip()
        private_key = Path(private_key_raw) if private_key_raw else None
        demo_mode = os.environ.get("DEMO_MODE", "0").strip().lower() not in ("0", "false", "no", "off")
        allow_issue = os.environ.get("ALLOW_DEMO_LICENSE_ISSUE", "0").strip().lower() not in (
            "0", "false", "no", "off"
        )
        return cls(
            data_dir=data_dir,
            license_file=license_file,
            public_key_b64=os.environ.get("SCAMMAP_PUBLIC_KEY", DEFAULT_PUBLIC_KEY_B64),
            private_key_file=private_key,
            demo_mode=demo_mode,
            allow_demo_license_issue=allow_issue,
            admin_token=os.environ.get("SCAMMAP_ADMIN_TOKEN", "").strip(),
            cors_origins=tuple(x.strip() for x in os.environ.get("CORS_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(",") if x.strip()),
            rate_reporter_limit=int(os.environ.get("RATE_REPORTER_LIMIT", "30")),
            rate_ip_limit=int(os.environ.get("RATE_IP_LIMIT", "120")),
            rate_window_seconds=int(os.environ.get("RATE_WINDOW_SECONDS", "600")),
            virustotal_api_key=os.environ.get("VT_API_KEY", "").strip(),
            carto_api_key=os.environ.get("CARTO_API_KEY", "").strip(),
            judge_api_compat=os.environ.get("JUDGE_API_COMPAT", "0").strip().lower() in ("1", "true", "yes", "on"),
        )


class RateLimiter:
    """In-memory sliding window.  Reset clears it with the reports."""

    def __init__(self, reporter_limit: int, ip_limit: int, window_seconds: int):
        self.reporter_limit = reporter_limit
        self.ip_limit = ip_limit
        self.window_seconds = window_seconds
        self._events: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def allow_key(self, key: str, limit: int, window_seconds: int | None = None) -> bool:
        """Bounded per-key sliding window for endpoints beyond report creation."""
        now = time.time()
        window = window_seconds or self.window_seconds
        with self._lock:
            # Opportunistically prune stale keys so hostile clients cannot grow
            # this in-memory map forever. This is a single-process limiter.
            if len(self._events) > 2048:
                cutoff = now - max(self.window_seconds, window)
                stale = [k for k, events in self._events.items() if not events or events[-1] < cutoff]
                for stale_key in stale[:1024]:
                    self._events.pop(stale_key, None)
            events = self._events[key]
            while events and events[0] < now - window:
                events.popleft()
            if len(events) >= limit:
                return False
            events.append(now)
            return True

    def allow(self, reporter_id: str, ip_prefix: str) -> bool:
        now = time.time()
        keys = ((f"r:{reporter_id}", self.reporter_limit), (f"ip:{ip_prefix}", self.ip_limit))
        with self._lock:
            for key, limit in keys:
                events = self._events[key]
                while events and events[0] < now - self.window_seconds:
                    events.popleft()
                if len(events) >= limit:
                    return False
            for key, _ in keys:
                self._events[key].append(now)
        return True

    def clear(self) -> None:
        with self._lock:
            self._events.clear()


def _request_ip(request: Request) -> str:
    # Forwarded headers are client-spoofable unless a trusted reverse proxy
    # overwrites them. Ignore them by default; opt in only behind a proxy that
    # sanitizes X-Forwarded-For.
    trust_proxy = os.environ.get("TRUST_PROXY_HEADERS", "0").strip().lower() in ("1", "true", "yes")
    if trust_proxy:
        forwarded = request.headers.get("x-forwarded-for", "")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


async def _json_body(request: Request) -> dict[str, Any]:
    # Keep attacker-controlled JSON bodies bounded before parsing.
    max_bytes = 64 * 1024
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > max_bytes:
                raise ValueError("JSON body exceeds 64 KB")
        except ValueError as exc:
            if "exceeds" in str(exc):
                raise
            raise ValueError("invalid Content-Length") from exc
    chunks = []
    total = 0
    async for chunk in request.stream():
        total += len(chunk)
        if total > max_bytes:
            raise ValueError("JSON body exceeds 64 KB")
        chunks.append(chunk)
    try:
        body = json.loads(b"".join(chunks))
    except Exception:
        raise ValueError("invalid JSON body")
    if not isinstance(body, dict):
        raise ValueError("JSON body must be an object")
    return body


def _int_param(value: Any, default: int, low: int, high: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, number))


def _float_param(value: Any, default: float, low: float, high: float) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, number))


def _bool_value(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "on")


def _int_value(value: Any) -> int:
    try:
        return max(0, int(float(value)))
    except (TypeError, ValueError):
        return 0


def _parse_time(value: Any, field: str) -> tuple[datetime, float, str]:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} is invalid")
    try:
        dt = parse_iso(value)
    except Exception as exc:
        raise ValueError(f"{field} is invalid") from exc
    return dt, dt.timestamp(), to_ist_iso(dt)


_SMS_URL_RE = re.compile(r"(?i)\b(?:https?://|www\.)[^\s<>\"']+")
_SMS_PHONE_RE = re.compile(r"(?<!\w)(?:\+?91[-\s]?)?[6-9]\d{9}(?!\w)")
_SMS_UPI_RE = re.compile(r"(?i)\b[a-z0-9._-]{2,}@[a-z][a-z0-9.-]{1,}\b")
_SMS_SENDER_RE = re.compile(r"(?<![A-Z0-9])[A-Z]{2}-[A-Z0-9]{5,8}(?![A-Z0-9])")


def extract_sms_identifiers(message: str) -> list[dict[str, str]]:
    """Extract likely identifiers from an SMS; values are validated and canonicalised."""
    found: list[dict[str, str]] = []
    patterns = (("url", _SMS_URL_RE), ("phone", _SMS_PHONE_RE), ("upi", _SMS_UPI_RE), ("sender_id", _SMS_SENDER_RE))
    for kind, pattern in patterns:
        for match in pattern.findall(message or ""):
            candidate = match.rstrip(".,);]}")
            try:
                canonical = normalize_identifier(kind, candidate)
            except IdentifierError:
                continue
            item = {"type": kind, "value": canonical}
            if item not in found:
                found.append(item)
    return found[:20]


def redact_sms(message: str) -> str:
    text = _SMS_URL_RE.sub("[URL]", message)
    text = _SMS_PHONE_RE.sub("[PHONE]", text)
    text = _SMS_UPI_RE.sub("[UPI]", text)
    text = re.sub(r"(?i)\b(otp|pin|cvv|password|passcode|code)\s*(?:is|:|was|of)?\s*[:#-]?\s*\d{4,8}\b", r"\1 [REDACTED]", text)
    text = re.sub(r"\b\d{8,18}\b", "[NUMBER]", text)
    return text[:2000]


def normalize_sms_text(message: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (message or "").lower()).strip()[:2000]


def _sms_text_similarity(left: str, right: str) -> float:
    a = normalize_sms_text(redact_sms(left))
    b = normalize_sms_text(redact_sms(right))
    ratio = SequenceMatcher(None, a, b).ratio()
    a_tokens, b_tokens = set(a.split()), set(b.split())
    jaccard = len(a_tokens & b_tokens) / max(1, len(a_tokens | b_tokens))
    return max(ratio, jaccard)


def _image_perceptual_hash(image: Image.Image) -> str:
    """Return a compact 64-bit difference hash for near-duplicate screening."""
    gray = ImageOps.grayscale(image).resize((9, 8))
    pixels = list(gray.getdata())
    bits = 0
    for y in range(8):
        for x in range(8):
            left = pixels[y * 9 + x]
            right = pixels[y * 9 + x + 1]
            bits = (bits << 1) | int(left > right)
    return f"{bits:016x}"


def _safe_image_metadata(image: Image.Image) -> dict[str, str]:
    metadata: dict[str, str] = {}
    try:
        exif = image.getexif()
        for key, label in ((306, "DateTime"), (36867, "DateTimeOriginal"), (305, "Software"), (271, "Make"), (272, "Model")):
            value = exif.get(key)
            if value is not None:
                metadata[label] = str(value)[:160]
    except Exception:
        pass
    try:
        for key in ("Software", "software", "Description", "Comment"):
            value = image.info.get(key)
            if value is not None and str(value).strip():
                metadata.setdefault(key, str(value)[:160])
    except Exception:
        pass
    return metadata


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings.from_env()
    settings.data_dir.mkdir(parents=True, exist_ok=True)

    db = Database(settings.data_dir / "scammap.db")
    trust = TrustEngine(db)
    licenses = LicenseManager(
        db,
        settings.license_file,
        public_key_b64=settings.public_key_b64,
        private_key_path=settings.private_key_file,
    )
    # Never silently install a demo licence in a normal deployment.
    if settings.demo_mode:
        licenses.ensure_default(BASE_DIR / "licenses" / "demo_long.json")
    rate_limiter = RateLimiter(
        settings.rate_reporter_limit,
        settings.rate_ip_limit,
        settings.rate_window_seconds,
    )

    app = FastAPI(
        title="Community Scam Map API",
        version="1.0.0",
        description=(
            "Report, look up and map scam identifiers. Anonymous by design. "
            "Every endpoint except /health, /license and /meta is licence-gated."
        ),
    )
    app.state.settings = settings
    app.state.db = db
    app.state.trust = trust
    app.state.licenses = licenses
    app.state.rate_limiter = rate_limiter
    app.state.ocr_semaphore = asyncio.Semaphore(2)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_origins),
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "X-Admin-Token", "X-File-Name"],
        allow_credentials=True,
    )

    def require_admin(request: Request):
        supplied = request.headers.get("x-admin-token", "")
        expected = settings.admin_token or ""
        if not expected or not supplied or not secrets.compare_digest(supplied, expected):
            return JSONResponse(status_code=401, content={"error": "ADMIN_AUTH_REQUIRED"})
        return None

    exempt_exact = {
        "/", "/health", "/license", "/meta", "/public-config", "/favicon.ico",
        "/manifest.webmanifest", "/docs", "/redoc", "/openapi.json",
    }

    @app.middleware("http")
    async def licence_guard(request: Request, call_next):
        path = request.url.path
        if (
            path in exempt_exact
            or path.startswith("/static/")
            or path.startswith("/demo/license")
        ):
            response = await call_next(request)
            response.headers.setdefault("Cache-Control", "no-store")
            return response

        status = licenses.status()
        if not status.get("valid"):
            return JSONResponse(
                status_code=403,
                content={"error": status.get("error") or "LICENSE_EXPIRED"},
            )
        response = await call_next(request)
        response.headers.setdefault("Cache-Control", "no-store")
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("Permissions-Policy", "geolocation=(), camera=(), microphone=()")
        return response

    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    @app.get("/manifest.webmanifest", include_in_schema=False)
    def manifest() -> FileResponse:
        return FileResponse(STATIC_DIR / "manifest.webmanifest", media_type="application/manifest+json")

    @app.get("/favicon.ico", include_in_schema=False)
    def favicon() -> FileResponse:
        return FileResponse(STATIC_DIR / "img" / "favicon.svg", media_type="image/svg+xml")

    @app.get("/health")
    def health() -> dict[str, Any]:
        return {"ok": True}

    @app.post("/ml/analyze-message")
    async def ml_analyze_message(request: Request):
        """Text screening only; does not create a report or public scam verdict."""
        try: body = await _json_body(request)
        except ValueError as exc: return JSONResponse(status_code=400, content={"error": str(exc)})
        message = str(body.get("message_text") or "").strip()
        if not message: return JSONResponse(status_code=400, content={"error": "message_text is required"})
        if len(message)>2000: return JSONResponse(status_code=413, content={"error": "message_text exceeds 2000 characters"})
        try: return predict_message(message)
        except MessageModelNotReady as exc: return JSONResponse(status_code=503, content={"error": "MODEL_NOT_TRAINED", "message": str(exc)})

    @app.get("/license")
    def get_license() -> dict[str, Any]:
        return licenses.status()

    @app.post("/license")
    async def post_license(request: Request):
        try:
            body = await _json_body(request)
        except ValueError as exc:
            return JSONResponse(status_code=400, content={"error": str(exc)})
        candidate = body.get("license", body)
        try:
            return licenses.upload(candidate)
        except LicenseError as exc:
            return JSONResponse(status_code=400, content={"error": exc.code})

    @app.post("/demo/license/issue")
    def demo_issue_license(request: Request):
        if not settings.demo_mode or not settings.allow_demo_license_issue:
            return JSONResponse(status_code=404, content={"error": "NOT_FOUND"})
        denied = require_admin(request)
        if denied: return denied
        minutes = _int_param(request.query_params.get("minutes"), 5, 1, 525600)
        licensee = request.query_params.get("licensee", "Demo Bank")[:120]
        try:
            return licenses.issue_and_install(minutes, licensee=licensee)
        except LicenseError as exc:
            return JSONResponse(status_code=400, content={"error": exc.code})

    @app.get("/public-config")
    def public_config() -> dict[str, Any]:
        # CARTO basemap keys are browser-visible by design; restrict the key
        # to this application/domain in the CARTO dashboard. Never return VT_API_KEY.
        return {"carto_api_key": settings.carto_api_key}

    @app.get("/meta")
    def meta() -> dict[str, Any]:
        return {
            "areas": AREAS,
            "cities": CITIES,
            "channels": CHANNELS,
            "scam_types": SCAM_TYPES,
            "verified": VERIFIED,
            "helplines": HELPLINES,
            "demo_mode": settings.demo_mode,
            "allow_demo_license_issue": settings.allow_demo_license_issue,
        }

    @app.post("/areas/nearest")
    async def nearest_area(request: Request):
        """Resolve browser-consented coordinates to a supported locality only."""
        client_key = sanitize_ip_prefix(_request_ip(request))
        if not rate_limiter.allow_key(f"geo:{client_key}", 20, 3600):
            return JSONResponse(status_code=429, content={"error": "LOCATION_RATE_LIMITED", "message": "Location lookup limit reached. Choose your area manually."})
        try:
            body = await _json_body(request)
            lat_raw, lng_raw = body.get("latitude"), body.get("longitude")
            if isinstance(lat_raw, bool) or isinstance(lng_raw, bool):
                raise ValueError("Invalid coordinates")
            lat, lng = float(lat_raw), float(lng_raw)
            area, distance = resolve_nearest_area(lat, lng, max_distance_km=25.0)
        except (ValueError, TypeError) as exc:
            return JSONResponse(status_code=400, content={"error": "INVALID_COORDINATES", "message": str(exc) or "Provide valid coordinates."})
        if area is None:
            return JSONResponse(status_code=404, content={"error": "AREA_NOT_SUPPORTED", "message": "Your location is outside the supported map areas. Please select your area manually."})
        # Return locality-level data only. Raw coordinates are never stored or returned.
        return {"area": {"pincode": area["pincode"], "locality": area["locality"], "city": area["city"]}, "distance_km": round(float(distance or 0), 1), "precision": "area"}

    @app.get("/report-session")
    def report_session(request: Request):
        token = request.cookies.get(REPORT_SESSION_COOKIE, "")
        created = not bool(re.fullmatch(r"[A-Za-z0-9_-]{40,60}", token))
        if created:
            token = secrets.token_urlsafe(32)
        session_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        today = _ist_day()
        used = db.session_report_count(session_hash, today)
        response = JSONResponse({
            "used": used,
            "limit": DAILY_SESSION_REPORT_LIMIT,
            "remaining": max(0, DAILY_SESSION_REPORT_LIMIT - used),
            "day": today,
        })
        if created:
            response.set_cookie(
                REPORT_SESSION_COOKIE,
                token,
                max_age=60 * 60 * 24 * 30,
                httponly=True,
                secure=request.url.scheme == "https",
                samesite="strict",
                path="/",
            )
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.post("/demo/seed")
    def demo_seed(request: Request):
        if not settings.demo_mode:
            return JSONResponse(status_code=404, content={"error": "NOT_FOUND"})
        denied = require_admin(request)
        if denied: return denied
        result = seed_demo(db, trust)
        rate_limiter.clear()
        return {"ok": True, **result}

    @app.post("/reports", status_code=201)
    async def post_report(request: Request):
        try:
            body = await _json_body(request)
        except ValueError as exc:
            return JSONResponse(status_code=400, content={"error": str(exc)})

        if not body.get("occurred_at"):
            return JSONResponse(status_code=400, content={"error": "occurred_at is required"})
        message_text = str(body.get("message_text") or body.get("raw_sms") or "").strip()
        if len(message_text) > 2000:
            return JSONResponse(status_code=413, content={"error": "SMS message exceeds 2000 characters"})
        extracted = extract_sms_identifiers(message_text) if message_text else []
        raw_kind = body.get("identifier_type")
        raw_value = body.get("identifier_value")
        if not raw_value and extracted:
            raw_kind, raw_value = extracted[0]["type"], extracted[0]["value"]
        if not raw_value:
            return JSONResponse(status_code=400, content={"error": "Provide an identifier or a message containing a supported URL, phone, UPI ID or sender ID"})
        try:
            kind = str(raw_kind or detect_type(str(raw_value))).strip().lower()
            canonical = normalize_identifier(kind, raw_value)
        except IdentifierError as exc:
            return JSONResponse(status_code=400, content={"error": str(exc)})

        now = time.time()
        try:
            _, occurred_ts, occurred_at = _parse_time(body["occurred_at"], "occurred_at")
        except ValueError as exc:
            return JSONResponse(status_code=400, content={"error": str(exc)})
        if occurred_ts > now + 86400:
            return JSONResponse(status_code=400, content={"error": "occurred_at cannot be in the future"})
        if occurred_ts < now - 730 * 86400:
            return JSONResponse(status_code=400, content={"error": "occurred_at is too old"})

        if body.get("reported_at"):
            try:
                _, _, reported_at = _parse_time(body["reported_at"], "reported_at")
            except ValueError as exc:
                return JSONResponse(status_code=400, content={"error": str(exc)})
        else:
            reported_at = to_ist_iso(now)

        area = find_area(body.get("pincode"), body.get("locality"))
        if area is None:
            return JSONResponse(
                status_code=400,
                content={"error": "pincode or locality is not a supported area"},
            )

        session_hash = _session_token_hash(request)
        if settings.judge_api_compat:
            # The official judging harness simulates many reporters from one
            # machine. Honour its supplied identity fields only in the isolated
            # judging profile; keep the public anonymous-session path unchanged.
            try:
                reporter_id = validate_reporter_id(body.get("reporter_id"))
            except IdentifierError as exc:
                return JSONResponse(status_code=400, content={"error": str(exc)})
            ip_prefix = sanitize_ip_prefix(body.get("ip_prefix"))
            if not body.get("ip_prefix"):
                return JSONResponse(status_code=400, content={"error": "ip_prefix is required in judge mode"})
            if not rate_limiter.allow(reporter_id, ip_prefix):
                return JSONResponse(status_code=429, content={"error": "RATE_LIMITED"})
            usage_day = None
            used_today = 0
        else:
            if session_hash is None:
                return JSONResponse(
                    status_code=400,
                    content={"error": "SESSION_REQUIRED", "message": "Refresh the page to start an anonymous reporting session."},
                )
            reporter_id = "anon:" + session_hash[:32]
            ip_prefix = sanitize_ip_prefix(_request_ip(request))
            if not rate_limiter.allow(reporter_id, ip_prefix):
                return JSONResponse(status_code=429, content={"error": "RATE_LIMITED"})
            usage_day = _ist_day()
            reserved, used_today = db.reserve_session_report(
                session_hash, usage_day, DAILY_SESSION_REPORT_LIMIT
            )
            if not reserved:
                return JSONResponse(
                    status_code=429,
                    content={
                        "error": "DAILY_SESSION_LIMIT",
                        "message": "Daily anonymous-session limit reached. You can submit up to 5 reports per day.",
                        "used": used_today,
                        "limit": DAILY_SESSION_REPORT_LIMIT,
                        "remaining": 0,
                    },
                )

        channel = canonical_channel(body.get("channel"))
        scam_type_raw = str(body.get("scam_type") or "other").strip()[:80]
        scam_type = canonical_scam_type(scam_type_raw)
        note = str(body.get("note") or "")[:2000]
        note_norm = normalise_note(note)
        case_id, merged = db.get_or_create_case(kind, canonical)

        report_id = str(body.get("report_id") or f"rep_{uuid.uuid4().hex[:12]}").strip()[:128]
        if not report_id:
            report_id = f"rep_{uuid.uuid4().hex[:12]}"

        report = {
            "report_id": report_id,
            "case_id": case_id,
            "occurred_at": occurred_at,
            "occurred_ts": occurred_ts,
            "reported_at": reported_at,
            "reporter_id": reporter_id,
            "ip_prefix": ip_prefix,
            "channel": channel,
            "scam_type": scam_type,
            "scam_type_raw": scam_type_raw,
            "identifier_type": kind,
            "identifier_value": canonical,
            "pincode": area["pincode"],
            "locality": area["locality"],
            "city": area["city"],
            "note": note,
            "note_norm": note_norm,
            "note_hash": hashlib.sha256(note_norm.encode("utf-8")).hexdigest(),
            "has_screenshot": int(_bool_value(body.get("has_screenshot", False))),
            "amount_lost_inr": _int_value(body.get("amount_lost_inr", 0)),
            "created_ts": now,
        }
        try:
            db.insert_report(report)
        except DuplicateReport:
            if session_hash is not None and usage_day is not None:
                db.release_session_report(session_hash, usage_day)
            return JSONResponse(status_code=409, content={"error": "DUPLICATE_REPORT"})
        except Exception:
            if session_hash is not None and usage_day is not None:
                db.release_session_report(session_hash, usage_day)
            raise
        if message_text:
            safe_message = redact_sms(message_text)
            normalized_message = normalize_sms_text(safe_message)
            db.insert_sms_message({
                "report_id": report_id,
                "case_id": case_id,
                "message_text": safe_message,
                "normalized_text": normalized_message,
                "text_hash": hashlib.sha256(normalized_message.encode("utf-8")).hexdigest(),
                "extracted_identifiers": json.dumps(extracted, ensure_ascii=False),
                "created_ts": now,
            })
        trust.invalidate()
        amount_reported = report["amount_lost_inr"]
        summary = _report_summary(
            scam_type, channel, note, bool(report["has_screenshot"]), amount_reported
        )
        return JSONResponse(
            status_code=201,
            content={
                "report_id": report_id,
                "case_id": case_id,
                "merged": merged,
                "report_summary": summary,
                "report_status": "RECEIVED",
                "verification_status": "NOT_VERIFIED",
                "reports_used_today": used_today,
                "daily_report_limit": DAILY_SESSION_REPORT_LIMIT if not settings.judge_api_compat else None,
                "reports_remaining_today": max(0, DAILY_SESSION_REPORT_LIMIT - used_today) if not settings.judge_api_compat else None,
                "sms_analysis": {"submitted": bool(message_text), "extracted_identifiers": extracted},
            },
        )

    @app.post("/sms/evidence/{report_id}")
    async def upload_sms_evidence(report_id: str, request: Request):
        """Accept a private SMS screenshot and compare it with the submitted SMS."""
        session_hash = _session_token_hash(request)
        if not session_hash:
            return JSONResponse(status_code=401, content={"error": "SESSION_REQUIRED"})
        report = db.report_by_id(report_id)
        if not report or report.get("reporter_id") != "anon:" + session_hash[:32]:
            return JSONResponse(status_code=404, content={"error": "REPORT_NOT_FOUND"})
        sms_record = db.sms_message_by_report(report_id)
        if not sms_record:
            return JSONResponse(status_code=400, content={"error": "SMS_REPORT_REQUIRED"})
        ip_key = sanitize_ip_prefix(_request_ip(request))
        if not rate_limiter.allow_key(f"evidence:{ip_key}", 8, 600):
            return JSONResponse(status_code=429, content={"error": "RATE_LIMITED", "message": "Too many evidence uploads. Try again later."})
        max_upload = 5 * 1024 * 1024
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                if int(content_length) > max_upload:
                    return JSONResponse(status_code=413, content={"error": "Screenshot must be between 1 byte and 5 MB"})
            except ValueError:
                return JSONResponse(status_code=400, content={"error": "Invalid Content-Length"})
        chunks = []
        total = 0
        async for chunk in request.stream():
            total += len(chunk)
            if total > max_upload:
                return JSONResponse(status_code=413, content={"error": "Screenshot must be between 1 byte and 5 MB"})
            chunks.append(chunk)
        raw = b"".join(chunks)
        if not raw:
            return JSONResponse(status_code=413, content={"error": "Screenshot must be between 1 byte and 5 MB"})
        content_type = request.headers.get("content-type", "").split(";", 1)[0].lower()
        if content_type not in {"image/png", "image/jpeg"}:
            return JSONResponse(status_code=415, content={"error": "Upload a PNG or JPG screenshot"})
        if not (raw.startswith(b"\x89PNG\r\n\x1a\n") if content_type == "image/png" else raw.startswith(b"\xff\xd8\xff")):
            return JSONResponse(status_code=415, content={"error": "Image content does not match its file type"})
        try:
            original_image = Image.open(BytesIO(raw))
            width, height = original_image.size
            if width < 120 or height < 120 or width * height > 20_000_000:
                return JSONResponse(status_code=400, content={"error": "Screenshot dimensions are not supported"})
            original_image.verify()
            metadata = _safe_image_metadata(Image.open(BytesIO(raw)))
            image = ImageOps.exif_transpose(Image.open(BytesIO(raw))).convert("RGB")
        except Exception:
            return JSONResponse(status_code=400, content={"error": "The uploaded image could not be read"})

        image_hash = hashlib.sha256(raw).hexdigest()
        metadata["perceptual_hash"] = _image_perceptual_hash(image)
        duplicate = db.sms_evidence_hash_exists(image_hash)
        ocr_text = ""
        sender_text = ""
        status = "INCONCLUSIVE"
        reason = "OCR_UNAVAILABLE"
        software = " ".join(metadata.get(key, "") for key in ("Software", "software", "Description", "Comment")).lower()
        editor_markers = ("photoshop", "gimp", "canva", "picsart", "snapseed", "lightroom", "pixlr", "photopea", "meitu", "facetune", "paint.net", "mspaint", "microsoft paint", "windows photos")
        editor_metadata_found = any(marker in software for marker in editor_markers)
        if duplicate:
            reason = "DUPLICATE_SCREENSHOT"
        elif editor_metadata_found:
            reason = "IMAGE_EDITOR_METADATA"
        elif pytesseract is not None:
            try:
                async with app.state.ocr_semaphore:
                    ocr_text = await asyncio.to_thread(
                        pytesseract.image_to_string, image, config="--psm 6", timeout=8
                    )
                    sender_crop = image.crop((0, 0, width, max(1, int(height * 0.35))))
                    sender_text = await asyncio.to_thread(
                        pytesseract.image_to_string, sender_crop, config="--psm 6", timeout=5
                    )
                ocr_text = ocr_text[:5000]
                sender_text = sender_text[:1200]
                similarity = _sms_text_similarity(sms_record["message_text"], ocr_text)
                text_matches = similarity >= 0.68
                sender_matches = True
                sender_check_needed = report["identifier_type"] in {"phone", "sender_id"}
                if sender_check_needed:
                    claimed = (report["identifier_type"], report["identifier_value"])
                    top_ids = extract_sms_identifiers(sender_text)
                    same_type = [item for item in top_ids if item["type"] == claimed[0]]
                    sender_matches = claimed in [(item["type"], item["value"]) for item in same_type]
                    if not same_type:
                        full_ids = [item for item in extract_sms_identifiers(ocr_text) if item["type"] == claimed[0]]
                        if full_ids and all(item["value"] != claimed[1] for item in full_ids):
                            sender_matches = False
                        else:
                            sender_matches = None
                if not text_matches:
                    status, reason = "MISMATCHED", "SCREENSHOT_TEXT_MISMATCH"
                elif sender_matches is False:
                    status, reason = "MISMATCHED", "SENDER_NUMBER_MISMATCH"
                elif sender_matches is None:
                    status, reason = "INCONCLUSIVE", "SENDER_NOT_READABLE"
                else:
                    status, reason = "MATCHED", "TEXT_AND_SENDER_MATCH"
                metadata["ocr_similarity"] = f"{similarity:.3f}"
            except Exception as exc:
                # Tesseract timeouts and missing native binaries are inconclusive.
                status, reason = "INCONCLUSIVE", "OCR_TIMEOUT" if "timeout" in str(exc).lower() else "OCR_UNAVAILABLE"
        else:
            reason = "OCR_PACKAGE_UNAVAILABLE"

        evidence_dir = settings.data_dir / "sms_evidence"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        extension = ".png" if content_type == "image/png" else ".jpg"
        stored_name = f"{uuid.uuid4().hex}{extension}"
        (evidence_dir / stored_name).write_bytes(raw)
        # Auxiliary ML comparison is recorded as private metadata only. It never
        # changes the deterministic MATCHED/MISMATCHED/INCONCLUSIVE evidence status.
        try:
            ml_advisory = assess_report_match(
                sms_record.get("message_text", ""), ocr_text,
                report.get("identifier_value", ""), sender_text
            )
            metadata["aux_ml_assessment"] = str(ml_advisory.get("assessment", "NOT_RUN"))
            metadata["aux_ml_confidence"] = str(ml_advisory.get("confidence", ""))
            metadata["aux_ml_advisory_only"] = "true"
        except Exception:
            ml_advisory = {"available": False, "assessment": "NOT_RUN",
                           "message": "Auxiliary assessment unavailable."}
        try:
            evidence_record = {
                "evidence_id": "ev_" + uuid.uuid4().hex[:16],
                "report_id": report_id,
                "image_hash": image_hash,
                "file_name": stored_name,
                "image_format": "PNG" if extension == ".png" else "JPEG",
                "image_size": len(raw),
                "image_width": width,
                "image_height": height,
                "metadata_json": json.dumps(metadata, ensure_ascii=False),
                "ocr_text": ocr_text[:5000],
                "status": status,
                "reason": reason,
                "created_ts": time.time(),
            }
            db.insert_sms_evidence(evidence_record)
            status = evidence_record["status"]
        except Exception:
            try: (evidence_dir / stored_name).unlink(missing_ok=True)
            except Exception: pass
            return JSONResponse(status_code=409, content={"error": "Evidence has already been submitted for this report"})
        trust.invalidate()
        return {"accepted": True, "evidence_status": status,
                "verification_status": "MARKED_FOR_VERIFICATION",
                "ml_advisory": ml_advisory,
                "message": {"MATCHED": "Screenshot supports the SMS details.", "MISMATCHED": "Screenshot details do not match the submitted SMS or sender.", "INCONCLUSIVE": "Screenshot was received, but it could not be fully checked."}[status]}

    @app.get("/lookup")
    async def lookup(request: Request):
        ip_key = sanitize_ip_prefix(_request_ip(request))
        if not rate_limiter.allow_key(f"lookup:{ip_key}", 60, 60):
            return JSONResponse(status_code=429, content={"error": "RATE_LIMITED", "message": "Too many lookups. Try again shortly."})
        params = request.query_params
        message_query = params.get("message")
        if message_query and message_query.strip():
            if len(message_query) > 2000:
                return JSONResponse(status_code=413, content={"error": "message exceeds 2000 characters"})
            cleaned = normalize_sms_text(redact_sms(message_query))
            extracted = extract_sms_identifiers(message_query)
            candidates = db.sms_messages(limit=500)
            matches = []
            query_tokens = set(cleaned.split())
            for row in candidates:
                # Contradictory or unreadable screenshot evidence must not
                # contribute to public SMS similarity results. Missing evidence
                # remains unverified; it is not automatically a mismatch.
                # Public SMS results require accepted screenshot evidence.
                # Missing evidence is not proof of fraud and is not public proof.
                if row.get("evidence_status") != "MATCHED":
                    continue
                existing = row.get("normalized_text", "")
                ratio = SequenceMatcher(None, cleaned, existing).ratio()
                tokens = set(existing.split())
                jaccard = len(query_tokens & tokens) / max(1, len(query_tokens | tokens))
                score = max(ratio, jaccard)
                if score >= 0.72:
                    matches.append({"case_id": row["case_id"], "similarity": round(score, 3), "created_ts": row["created_ts"]})
            matches.sort(key=lambda item: item["similarity"], reverse=True)
            return {
                "query_type": "sms",
                "extracted_identifiers": [
                    item for item in extracted
                    if item.get("type") not in {"phone", "sender_id", "upi"}
                ],
                "similar_messages": len(matches),
                "matches": matches[:10],
                "risk_hint": "VERIFIED_RECORDS_FOUND" if matches else "NO_RECORDS_FOUND",
                "disclaimer": (
                    "Verified evidence records found. Similarity and screenshot consistency checks are screening signals, not proof of fraud."
                    if matches else
                    "No verified community records were found. Reports without accepted evidence, with reused/near-duplicate screenshots, or flagged for coordinated review are excluded."
                ),
            }
        value = params.get("value")
        if value is None or not str(value).strip():
            return JSONResponse(status_code=400, content={"error": "value or message is required"})
        kind = (params.get("type") or detect_type(value)).strip().lower()
        try:
            canonical = normalize_identifier(kind, value)
        except IdentifierError as exc:
            return JSONResponse(status_code=400, content={"error": str(exc)})

        evidence_summary = db.sms_evidence_summary_for_identifier(kind, canonical)
        assessment = trust.assess(kind, canonical)
        advice = ADVICE.get(assessment.scam_type, ADVICE["other"])
        payload = assessment.lookup_payload(advice)
        payload["evidence_filtered"] = bool(
            kind == "phone"
            and evidence_summary["sms_total"] > 0
            and evidence_summary["matched"] == 0
            and (evidence_summary["mismatched"] + evidence_summary["inconclusive"]) == evidence_summary["sms_total"]
            and evidence_summary["missing"] == 0
            and evidence_summary["non_sms"] == 0
        )
        payload["identifier_type"] = kind
        payload["normalized_value"] = canonical

        # External URL intelligence is an additional evidence source only.
        # It never changes the community trust verdict by itself.
        if kind == "url":
            payload["url_intelligence"] = await check_url_reputation(
                canonical, settings.virustotal_api_key
            )
        return payload

    @app.get("/map")
    def map_view(request: Request):
        params = request.query_params
        days = _int_param(params.get("days"), 7, 1, 90)
        radius_km = _float_param(params.get("radius_km"), 2.0, 0.0, 100.0)
        pincode = (params.get("pincode") or "").strip()
        center = AREA_BY_PINCODE.get(pincode) if pincode else None
        if pincode and center is None:
            return {"clusters": []}

        now = time.time()
        groups: dict[str, list[tuple[dict[str, Any], Any]]] = defaultdict(list)
        for row, score in trust.scored_reports(now - days * 86400):
            # Map counts ignore obvious spam but keep ordinary empty-note reports.
            if score.q < 0.10:
                continue
            groups[row["pincode"]].append((row, score))

        clusters: list[dict[str, Any]] = []
        for pin, items in groups.items():
            area = AREA_BY_PINCODE.get(pin)
            if area is None:
                continue
            if center is not None:
                distance = haversine_km(center["lat"], center["lng"], area["lat"], area["lng"])
                if distance > radius_km:
                    continue

            identities = {score.identity for _, score in items}
            type_weights: Counter[str] = Counter()
            for row, score in items:
                type_weights[row["scam_type"]] += max(score.q, 0.10)
            top_scam_type = type_weights.most_common(1)[0][0] if type_weights else "other"
            count = len(items)
            if count >= 8 or len(identities) >= 5:
                severity = "CRIT"
            elif count >= 4 or len(identities) >= 3:
                severity = "HIGH"
            else:
                severity = "MED"
            clusters.append(
                {
                    "pincode": pin,
                    "locality": area["locality"],
                    "city": area["city"],
                    "count": count,
                    "distinct_reporters": len(identities),
                    "top_scam_type": top_scam_type,
                    "severity": severity,
                    "lat": area["lat"],
                    "lng": area["lng"],
                }
            )
        clusters.sort(key=lambda cluster: (-cluster["count"], cluster["locality"]))
        return {"clusters": clusters}

    @app.get("/alerts")
    def alerts(request: Request):
        """Return map-ready alerts from credible, independent recent reports.

        The live map only uses the latest 7 days. Older reports remain available
        for the comparison baseline but never create active map alerts.
        """
        pincode = (request.query_params.get("pincode") or "").strip()
        now = time.time()
        current_start = now - 7 * 86400
        previous_start = now - 14 * 86400
        history_start = now - 30 * 86400
        groups: dict[str, dict[str, list[tuple[dict[str, Any], Any]]]] = defaultdict(
            lambda: {"current": [], "previous": [], "history": []}
        )
        for row, score in trust.credible_reports(history_start):
            pin = row.get("pincode")
            if not pin or (pincode and pin != pincode):
                continue
            bucket = groups[pin]
            ts = float(row["occurred_ts"])
            if ts >= current_start:
                bucket["current"].append((row, score))
            elif ts >= previous_start:
                bucket["previous"].append((row, score))
            else:
                bucket["history"].append((row, score))

        area_activity: list[dict[str, Any]] = []
        out: list[dict[str, Any]] = []
        for pin, buckets in groups.items():
            area = AREA_BY_PINCODE.get(pin)
            if area is None:
                continue
            current = buckets["current"]
            previous = buckets["previous"]
            history = buckets["history"]
            current_ids = {score.identity for _, score in current}
            previous_ids = {score.identity for _, score in previous}
            if current:
                area_activity.append({
                    "type": "HIGHEST_ACTIVITY",
                    "pincode": pin,
                    "count": len(current),
                    "independent_reporters": len(current_ids),
                    "locality": area["locality"],
                    "city": area["city"],
                    "window": "7d",
                })

            # A spike needs enough independent evidence and a 3x rise over
            # the preceding 7-day period. A quiet area does not alert.
            baseline_per_day = len(previous) / 7.0
            if len(current) >= 5 and len(current_ids) >= 3 and len(current) >= 3 * max(len(previous), 1):
                out.append({
                    "type": "SPIKE",
                    "pincode": pin,
                    "window": "7d",
                    "count": len(current),
                    "baseline_count": len(previous),
                    "baseline_per_day": round(baseline_per_day, 1),
                    "increase_percent": round(((len(current) - len(previous)) / max(len(previous), 1)) * 100),
                    "independent_reporters": len(current_ids),
                    "locality": area["locality"],
                    "city": area["city"],
                })

            previous_types = {row["scam_type"] for row, _ in previous + history}
            current_by_type: dict[str, list[tuple[dict[str, Any], Any]]] = defaultdict(list)
            for row, score in current:
                current_by_type[row["scam_type"]].append((row, score))
            for scam_type, typed_items in current_by_type.items():
                typed_ids = {score.identity for _, score in typed_items}
                if scam_type not in previous_types and len(typed_ids) >= 3:
                    out.append({
                        "type": "NEW_TYPE",
                        "pincode": pin,
                        "scam_type": scam_type,
                        "count": len(typed_items),
                        "independent_reporters": len(typed_ids),
                        "window": "7d",
                        "locality": area["locality"],
                        "city": area["city"],
                    })

        # The highest activity card is always the leading map alert, provided
        # the area has at least 3 independent credible reporters.
        area_activity.sort(key=lambda item: (-item["count"], item["locality"]))
        if area_activity:
            top = area_activity[0]
            if top["independent_reporters"] >= 3:
                out.insert(0, top)
        out.sort(key=lambda item: (
            0 if item["type"] == "HIGHEST_ACTIVITY" else 1 if item["type"] == "SPIKE" else 2,
            -item.get("count", 0),
            item.get("locality", ""),
        ))
        return {"alerts": out[:12], "generated_at": datetime.now(IST).isoformat(), "map_window_days": 7}

    @app.post("/challenges", status_code=201)
    async def post_challenge(request: Request):
        ip_key = sanitize_ip_prefix(_request_ip(request))
        if not rate_limiter.allow_key(f"challenge:{ip_key}", 5, 3600):
            return JSONResponse(status_code=429, content={"error": "RATE_LIMITED"})
        try:
            body = await _json_body(request)
        except ValueError as exc:
            return JSONResponse(status_code=400, content={"error": str(exc)})

        for field in ("identifier_type", "identifier_value", "claimant_name", "contact_email"):
            if not body.get(field):
                return JSONResponse(status_code=400, content={"error": f"{field} is required"})

        try:
            kind = str(body["identifier_type"]).strip().lower()
            canonical = normalize_identifier(kind, body["identifier_value"])
        except IdentifierError as exc:
            return JSONResponse(status_code=400, content={"error": str(exc)})

        claimant_name = str(body["claimant_name"]).strip()[:200]
        contact_email = str(body["contact_email"]).strip()[:320]
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", contact_email):
            return JSONResponse(status_code=400, content={"error": "contact_email is invalid"})
        proof_note = str(body.get("proof_note") or "")[:2000]

        challenge_id = "chal_" + uuid.uuid4().hex[:12]
        db.add_challenge(
            {
                "challenge_id": challenge_id,
                "identifier_type": kind,
                "identifier_value": canonical,
                "claimant_name": claimant_name,
                "contact_email": contact_email,
                "proof_note": proof_note,
                "status": "under_review",
                "created_ts": time.time(),
            }
        )
        # Refresh the display flag; challenge state no longer changes trust scoring.
        trust.invalidate()
        return JSONResponse(
            status_code=201,
            content={"challenge_id": challenge_id, "status": "under_review"},
        )

    @app.post("/admin/reset")
    def admin_reset(request: Request):
        # The no-credential reset is enabled only in the isolated judge profile,
        # because the official harness cannot send an admin key. Never enable
        # JUDGE_API_COMPAT on an unrestricted public deployment.
        if not settings.judge_api_compat:
            denied = require_admin(request)
            if denied: return denied
        deleted = db.reset()
        evidence_dir = settings.data_dir / "sms_evidence"
        if evidence_dir.exists():
            for evidence_file in evidence_dir.iterdir():
                if evidence_file.is_file():
                    try: evidence_file.unlink()
                    except OSError: pass
        trust.invalidate()
        rate_limiter.clear()
        return {"ok": True, "deleted_reports": deleted}

    @app.get("/admin/challenges")
    def admin_challenges(request: Request):
        denied = require_admin(request)
        if denied: return denied
        return {"challenges": db.challenges()}

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
    return app


app = create_app()

