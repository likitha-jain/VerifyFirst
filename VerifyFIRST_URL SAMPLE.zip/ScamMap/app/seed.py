"""Realistic demo data, including attempts to game the trust rules.

The seed deliberately contains:
  * genuine multi-reporter scam clusters,
  * a 18-account bombing run on an unverified bakery,
  * a 12-account bombing run on a verified bakery,
  * one-person and two-person reports,
  * a spike and a new scam type in HSR Layout.
"""

from __future__ import annotations

import hashlib
import time
from datetime import datetime, timezone
from typing import Any

from .areas import find_area
from .identifiers import normalize_identifier
from .license import to_ist_iso
from .trust import normalise_note

_FAKE_NOTE = "This bakery cheated me, do not trust this number, they took my money."


def seed_demo(db: Any, trust_engine: Any) -> dict[str, int]:
    db.reset()
    trust_engine.invalidate()
    now = time.time()
    counter = 0
    inserted = 0
    created_cases: set[tuple[str, str]] = set()

    def add(
        identifier_type: str,
        identifier_value: str,
        pincode: str,
        scam_type: str,
        channel: str,
        note: str,
        minutes_ago: float,
        reporter_id: str,
        ip_prefix: str,
        amount: int = 0,
        screenshot: bool = False,
    ) -> None:
        nonlocal counter, inserted
        counter += 1
        canonical = normalize_identifier(identifier_type, identifier_value)
        area = find_area(pincode=pincode)
        if area is None:
            raise ValueError(f"unknown seed area {pincode}")
        case_id, _ = db.get_or_create_case(identifier_type, canonical)
        created_cases.add((identifier_type, canonical))
        occurred_ts = now - minutes_ago * 60
        occurred_at = to_ist_iso(datetime.fromtimestamp(occurred_ts, tz=timezone.utc))
        reported_ts = min(now, occurred_ts + 300)
        note_norm = normalise_note(note)
        report = {
            "report_id": f"rep_seed_{counter:04d}",
            "case_id": case_id,
            "occurred_at": occurred_at,
            "occurred_ts": occurred_ts,
            "reported_at": to_ist_iso(datetime.fromtimestamp(reported_ts, tz=timezone.utc)),
            "reporter_id": reporter_id,
            "ip_prefix": ip_prefix,
            "channel": channel,
            "scam_type": scam_type,
            "scam_type_raw": scam_type,
            "identifier_type": identifier_type,
            "identifier_value": canonical,
            "pincode": area["pincode"],
            "locality": area["locality"],
            "city": area["city"],
            "note": note,
            "note_norm": note_norm,
            "note_hash": hashlib.sha256(note_norm.encode("utf-8")).hexdigest(),
            "has_screenshot": int(screenshot),
            "amount_lost_inr": int(amount),
            "created_ts": now,
        }
        db.insert_report(report)
        inserted += 1

    # ------------------------------------------------------------------
    # HSR Layout: a real digital-arrest campaign with a genuine 24h spike.
    # ------------------------------------------------------------------
    hsr_old = [
        (10080, "seed_hsr_01", "103.21.58", "Caller said a parcel with drugs was found in my name and demanded ₹2 lakh to avoid arrest."),
        (8640, "seed_hsr_02", "49.36.12", "A man in police uniform on video call told me my Aadhaar was linked to a drugs case. He asked for a payment."),
        (7200, "seed_hsr_03", "157.32.44", "They kept me on a video call for two hours and said CBI would arrest me unless I transferred money."),
        (5760, "seed_hsr_04", "182.65.9", "Fake customs officer said a courier in my name had illegal items. Demanded a clearance fee on UPI."),
        (4320, "seed_hsr_05", "106.51.77", "Video call from a police uniform, said my parcel was seized. Asked me to stay on the call and pay."),
        (2880, "seed_hsr_06", "223.185.31", "They claimed a drugs parcel was registered to my Aadhaar and threatened arrest. I hung up and reported."),
    ]
    for minutes, reporter, ip, note in hsr_old:
        add("phone", "+919876501234", "560102", "digital-arrest", "Phone call", note, minutes, reporter, ip)

    hsr_new = [
        (600, "seed_hsr_07", "103.21.59", "Got a WhatsApp video call from a man in uniform saying a parcel with drugs was in my name. He demanded ₹1.5 lakh."),
        (480, "seed_hsr_08", "49.36.13", "Fake CBI officer said my bank account was used for money laundering and asked me to transfer money for verification."),
        (360, "seed_hsr_09", "157.32.45", "They said a courier with illegal passports was caught and I must pay a fine or be arrested. It was a video call."),
        (240, "seed_hsr_10", "182.65.10", "A police uniform video call, then a demand for ₹2 lakh. They told me not to disconnect the call."),
        (120, "seed_hsr_11", "106.51.78", "Caller claimed my Aadhaar was linked to a drugs parcel and said a digital arrest warrant was issued."),
        (60, "seed_hsr_12", "223.185.32", "Same digital arrest script: parcel, police uniform, video call, demand for money. I blocked them."),
    ]
    for minutes, reporter, ip, note in hsr_new:
        add("phone", "+919876501234", "560102", "digital-arrest", "Phone call", note, minutes, reporter, ip)

    # A brand-new scam type in HSR: job-offer. This must raise NEW_TYPE.
    for minutes, reporter, ip, note in [
        (180, "seed_job_01", "103.22.11", "Work from home task job on WhatsApp asked for a ₹5,000 deposit before sending any orders."),
        (300, "seed_job_02", "49.37.22", "They promised ₹3,000 a day for liking videos, then asked me to pay a registration fee."),
        (420, "seed_job_03", "157.33.55", "A recruiter on Telegram asked for a security deposit for a part-time data entry job. No company details."),
    ]:
        add("phone", "+919876505678", "560102", "job-offer", "SMS or WhatsApp", note, minutes, reporter, ip)

    # ------------------------------------------------------------------
    # Bombing runs against bakeries.
    # ------------------------------------------------------------------
    for index in range(18):
        add(
            "phone", "+918055550101", "560102", "fake-customer-care", "Phone call",
            _FAKE_NOTE, 20 + index * 0.2, f"seed_bomb_{index:02d}", "198.51.100",
        )
    for index in range(12):
        add(
            "phone", "+918041002233", "560038", "fake-customer-care", "Phone call",
            _FAKE_NOTE, 15 + index * 0.2, f"seed_verified_bomb_{index:02d}", "203.0.113",
        )

    # ------------------------------------------------------------------
    # Ordinary clusters in the other 23 areas. All older than 24h so they
    # do not create noisy alerts; they still appear on the 7-day map.
    # ------------------------------------------------------------------
    clusters = [
        ("560038", "url", "http://www.sbi-kyc-verify.in/update?utm=sms", "fake-kyc-link", "Fake website",
         ["Fake SBI KYC link said my account would be blocked in 24 hours and asked for net banking details.",
          "The link copied the SBI page and asked for my card PIN and OTP. I closed it and reported.",
          "Got an SMS with this link saying my KYC was expired. The page looked exactly like my bank."], 2, 3),
        ("560034", "upi", "refund.help@okaxis", "upi-refund-qr", "UPI request",
         ["They said they would send a refund and asked me to scan a QR code. It debited ₹8,000 instead.",
          "A fake refund request came on UPI. Approving it sent money from my account, not to it.",
          "Scan to receive was a lie. The QR code started a payment request for ₹12,500.",
          "They sent a collect request after I complained about a failed order. It was a refund scam."], 2, 4),
        ("560066", "phone", "+919876511111", "fake-customer-care", "Phone call",
         ["Found this number on a search result for my bank's customer care. They asked for my card CVV.",
          "The caller claimed to be from my bank and asked me to install a screen sharing app."], 2, 2),
        ("560076", "phone", "+919876522222", "courier-customs", "Phone call",
         ["Customs officer said my parcel had banned medicine and asked for a ₹7,000 clearance fee.",
          "They sent a UPI request for customs duty on a parcel I never ordered.",
          "Fake courier call said my parcel was held and I must pay a fine within an hour."], 3, 3),
        ("560011", "sender_id", "VK-POWER", "electricity-disconnection", "SMS or WhatsApp",
         ["SMS said my power would be cut tonight unless I paid ₹1,200 on a link. It was not from BESCOM.",
          "A message from this sender threatened disconnection and gave a fake payment link."], 3, 2),
        ("560037", "phone", "+919876533333", "otp-call", "Phone call",
         ["Caller said my card was blocked and asked for the OTP sent to my phone. I did not share it.",
          "They claimed to be from the bank fraud team and asked me to read out a six digit OTP.",
          "Fake bank call asked for my CVV and OTP to reverse a transaction.",
          "They said a suspicious payment was made and needed my OTP to cancel it."], 4, 4),
        ("560103", "phone", "+919876544444", "loan-app-harassment", "Phone call",
         ["Loan app gave ₹5,000 and then called my contacts threatening them for ₹40,000.",
          "They sent morphed photos to my family and demanded repayment at 10x the loan.",
          "Instant loan app accessed my gallery and blackmailed me with edited images."], 4, 3),
        ("560100", "phone", "+919876555555", "job-offer", "SMS or WhatsApp",
         ["Telegram job asked for a ₹2,000 training deposit and then blocked me.",
          "They promised part-time work and asked for money to unlock tasks."], 5, 2),
        ("560078", "phone", "+919876566666", "lottery-prize", "SMS or WhatsApp",
         ["SMS said I won ₹25 lakh and asked for a ₹5,000 processing fee.",
          "Lottery message asked for bank details and a tax payment before releasing the prize."], 5, 2),
        ("560003", "url", "https://profit-invest-group.example/app", "investment-group", "Fake website",
         ["WhatsApp group showed fake profits and asked me to deposit more for a VIP plan.",
          "The investment app showed a balance but blocked withdrawals until I paid a tax.",
          "They guaranteed 20% daily returns and asked for a minimum ₹10,000 deposit.",
          "Fake trading group sent screenshots of profits and demanded a withdrawal fee."], 6, 4),
        ("560010", "phone", "+919876577777", "fake-customer-care", "Phone call",
         ["Fake customer care number for a delivery app asked me to install a remote access app.",
          "They said my order was stuck and asked for a refund OTP."], 6, 2),
        ("560024", "phone", "+919876588888", "digital-arrest", "Phone call",
         ["Video call from a man in uniform said my parcel had drugs and demanded money.",
          "They said a digital arrest warrant was issued and I must stay on the call."], 6, 2),
        ("560064", "phone", "+919876599999", "courier-customs", "Phone call",
         ["Customs parcel scam asked for a clearance fee on a UPI ID.",
          "They claimed a parcel with illegal items was registered to my address."], 6, 2),
        ("560070", "upi", "refund.pay@ybl", "upi-refund-qr", "UPI request",
         ["Refund QR code debited money instead of returning it.",
          "They sent a UPI collect request and said it was needed to process my refund."], 6, 2),
        ("400050", "url", "https://bandra-invest.example/join", "investment-group", "Fake website",
         ["Fake investment group promised 15% monthly returns and stopped withdrawals.",
          "They showed a fake portfolio and asked for a 20% tax before withdrawal.",
          "WhatsApp group admin asked for more deposits after a small initial payout.",
          "The app showed profits but every withdrawal needed a new fee.",
          "They claimed SEBI registration but gave no registration number."], 7, 5),
        ("110016", "phone", "+919876500001", "digital-arrest", "Phone call",
         ["Police uniform video call demanded money for a drugs parcel in my name.",
          "They said my Aadhaar was linked to a money laundering case and threatened arrest.",
          "Fake CBI officer kept me on a video call and asked for a transfer.",
          "They demanded ₹3 lakh to close a fake drugs case."], 7, 4),
        ("500081", "phone", "+919876500002", "job-offer", "SMS or WhatsApp",
         ["Work from home job asked for a deposit before sending tasks.",
          "Telegram recruiter demanded money for a laptop and training kit.",
          "They promised daily payouts but asked for a registration fee first."], 7, 3),
        ("600020", "phone", "+919876500003", "lottery-prize", "SMS or WhatsApp",
         ["Prize SMS asked for a processing fee and bank details.",
          "They said I won a car and needed to pay insurance first."], 7, 2),
        ("411014", "phone", "+919876500004", "loan-app-harassment", "Phone call",
         ["Loan app threatened my contacts after a small loan.",
          "They demanded repayment at ten times the amount and sent threats.",
          "The app accessed my contact list and blackmailed my family."], 7, 3),
        ("700091", "phone", "+919876500005", "sextortion", "Phone call",
         ["Video call was recorded and the caller demanded money to not share it.",
          "They threatened to send an edited video to my contacts unless I paid."], 7, 2),
        ("380015", "phone", "+919876500006", "otp-call", "Phone call",
         ["Fake bank call asked for an OTP to stop a fraudulent transaction.",
          "They said my debit card was blocked and asked for the OTP.",
          "Caller claimed to be from the fraud team and asked for my CVV."], 7, 3),
        ("302017", "url", "https://jaipur-kyc.example/verify", "fake-kyc-link", "Fake website",
         ["KYC link asked for my bank password and OTP.",
          "The page copied my bank's login screen and asked for card details."], 7, 2),
        ("226010", "phone", "+919876500007", "courier-customs", "Phone call",
         ["Parcel held at customs, pay a fine on UPI.",
          "They claimed a courier with illegal goods was in my name."], 7, 2),
        ("682030", "phone", "+919876500008", "fake-customer-care", "Phone call",
         ["Fake customer care asked me to install a screen sharing app.",
          "They asked for a refund OTP and then tried to debit my account."], 7, 2),
    ]

    for pincode, kind, value, scam_type, channel, notes, days, count in clusters:
        for index in range(count):
            add(
                kind,
                value,
                pincode,
                scam_type,
                channel,
                notes[index % len(notes)],
                days * 1440 + index * 37,
                f"seed_{pincode}_{index:02d}",
                f"10{index}.{int(pincode[-3:]) % 250}.{index + 1}",
                amount=0,
            )

    # Two-report and one-report examples so masking is visible in the UI.
    add("phone", "+919876509999", "560102", "otp-call", "Phone call",
        "Caller asked for an OTP to cancel a fake transaction.", 3 * 1440, "seed_two_01", "117.20.1")
    add("phone", "+919876509999", "560034", "otp-call", "Phone call",
        "Fake bank fraud team asked me to read out the OTP.", 4 * 1440, "seed_two_02", "117.20.2")
    add("upi", "scammer.pay@okhdfcbank", "560038", "upi-refund-qr", "UPI request",
        "Asked me to scan a QR code to receive a refund.", 2 * 1440, "seed_one_01", "117.20.3")
    add("url", "https://sbi-kyc-secure.in/verify", "560102", "fake-kyc-link", "Fake website",
        "Fake SBI KYC page asked for my net banking password.", 2 * 1440, "seed_one_02", "117.20.4")
    add("sender_id", "VK-SCAMID", "560102", "lottery-prize", "SMS or WhatsApp",
        "Prize SMS asked for a processing fee.", 2 * 1440, "seed_one_03", "117.20.5")

    trust_engine.invalidate()
    return {
        "reports": inserted,
        "cases": len(created_cases),
        "identifiers": len(created_cases),
    }
