"""Trust rules that decide how much each report counts.

The goal is asymmetric: one person, one Wi-Fi or one copy-pasted message must
never be able to label a business as a scam, while a genuine wave of unrelated
people writing in their own words should still be believed.

Signals used for every report
-----------------------------
1. Reporter history     - new accounts count less than reporters whose earlier
                          reports were corroborated by other people.
2. Note quality         - a personal description counts more than an empty or
                          copy-pasted one.
3. Network identity     - many accounts on one IP prefix in 24h collapse into
                          one person.
4. Coordination         - a large, sudden, low-quality burst is down-weighted.
5. Junk rejection       - invalid identifiers never reach the scoring stage.

Credibility scores are internal evidence signals only. Community report
volume never creates a public accusation or a VERIFIED status. Public lookup
returns NOT_VERIFIED whenever community reports exist, until an identifier
is independently verified through the trusted verification registry.
"""

from __future__ import annotations

import re
import threading
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field
from typing import Any

from .areas import verified_entry
from .identifiers import mask_value

TRUSTED_Q = 0.33
CREDIBLE_Q = 0.20

_GENERIC_TOKENS = {
    "scam", "scammer", "fraud", "fake", "call", "caller", "number", "spam",
    "bad", "test", "testing", "hello", "hi", "yes", "no", "money", "lost",
    "blocked", "reported", "report", "please", "beware", "alert", "cheat",
    "cheated", "cheating", "unknown", "suspicious", "this", "that", "is", "a",
    "the", "and", "to", "from", "was", "it", "on", "for", "of", "in", "my",
}

_PERSONAL_SIGNALS = (
    "police", "parcel", "courier", "customs", "otp", "upi", "whatsapp",
    "video", "said", "asked", "told", "bank", "account", "link", "qr",
    "refund", "job", "loan", "electricity", "prize", "lottery", "aadhaar",
    "pan", "card", "cvv", "pin", "rupees", "rs.", "₹", "arrest", "cbi",
    "officer", "delivery", "payment", "transfer", "kyc", "investment",
    "profit", "task", "deposit", "disconnect", "blackmail", "video call",
)

_JUNK_NOTES = {
    "test", "testing", "asdf", "asdfasdf", "qwerty", "abc", "xyz", "12345",
    "123456", "aaaa", "xxxx", "none", "nil", "n/a", "na",
}


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def normalise_note(note: str) -> str:
    text = (note or "").lower().strip()
    text = re.sub(r"https?://\S+", " link ", text)
    text = re.sub(r"\s+", " ", text)
    return text


def _note_quality(norm: str, duplicate: bool) -> float:
    if not norm:
        return 0.50
    if norm in _JUNK_NOTES:
        return 0.08
    if duplicate:
        return 0.12

    tokens = norm.split()
    if len(norm) < 8 or len(tokens) < 2:
        return 0.35
    if all(token.strip(".,!?;:()[]\"'") in _GENERIC_TOKENS for token in tokens):
        return 0.30

    if len(norm) >= 40 and len(tokens) >= 8:
        base = 0.90
    elif len(norm) >= 20:
        base = 0.80
    elif len(norm) >= 10:
        base = 0.70
    else:
        base = 0.55

    if any(signal in norm for signal in _PERSONAL_SIGNALS):
        base = min(0.95, base + 0.05)
    if re.search(r"\d", norm):
        base = min(0.97, base + 0.03)
    return base


@dataclass
class ReportScore:
    report: dict[str, Any]
    identity: str
    q: float
    reporter_trust: float
    note_quality: float
    ip_multiplier: float
    burst_multiplier: float
    mass_multiplier: float
    duplicate_note: bool


@dataclass
class Assessment:
    identifier_type: str
    identifier_value: str
    verdict: str
    report_count: int
    distinct_reporters: int
    trusted_reporters: int
    average_trust: float
    first_seen: str | None
    last_seen: str | None
    scam_type: str
    display_value: str
    challenged: bool
    verified: dict[str, str] | None
    evidence: list[dict[str, Any]]
    scores: list[ReportScore] = field(default_factory=list)
    score_by_report_id: dict[str, ReportScore] = field(default_factory=dict)

    def lookup_payload(self, advice: dict[str, Any] | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "verdict": self.verdict,
            "report_count": self.report_count,
            "distinct_reporters": self.distinct_reporters,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "scam_type": self.scam_type,
            "display_value": self.display_value,
            "evidence": self.evidence,
            "challenged": self.challenged,
            # Extra fields are explicitly allowed by the PRD and make the UI honest.
            "trusted_reporters": self.trusted_reporters,
            "average_trust": round(self.average_trust, 2),
            "hidden": self.display_value != self.identifier_value,
            "verified_business": self.verified["belongs_to"] if self.verified else None,
        }
        if advice is not None:
            payload["advice"] = advice
        return payload


class TrustEngine:
    """Caches a scored view of the database; invalidated on every write."""

    def __init__(self, db: Any):
        self.db = db
        self._lock = threading.RLock()
        self._built = False
        self._reports: list[dict[str, Any]] = []
        self._by_identifier: dict[tuple[str, str], list[dict[str, Any]]] = {}
        self._identities: dict[tuple[str, str], set[str]] = {}
        self._reporter_identifiers: dict[str, set[tuple[str, str]]] = {}
        self._reporter_corroborated: dict[str, set[tuple[str, str]]] = {}
        self._reporter_flagged: dict[str, int] = {}
        self._sybil_identity: dict[str, str] = {}
        self._ip_entries: dict[tuple[tuple[str, str], str], list[tuple[float, str]]] = {}
        self._ip_reporters_global: dict[str, set[str]] = {}
        self._challenged_keys: set[tuple[str, str]] = set()
        self._assessment_cache: dict[tuple[str, str], Assessment] = {}

    # -- cache management --------------------------------------------------
    def invalidate(self) -> None:
        with self._lock:
            self._built = False
            self._assessment_cache.clear()

    def _ensure(self) -> None:
        with self._lock:
            if not self._built:
                self._build()

    def _build(self) -> None:
        reports = self.db.all_reports()
        # Phone reports with uploaded SMS evidence that is mismatched or
        # inconclusive are retained for audit but excluded from public trust
        # scoring, counts, and map aggregation.
        reports = [
            r for r in reports
            if not (
                r.get("identifier_type") == "phone"
                and r.get("sms_evidence_status") in {"MISMATCHED", "INCONCLUSIVE"}
            )
        ]
        challenges = self.db.challenges()
        challenged_keys = {
            (c["identifier_type"], c["identifier_value"])
            for c in challenges
            if c["status"] == "under_review"
        }

        by_identifier: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
        for report in reports:
            key = (report["identifier_type"], report["identifier_value"])
            by_identifier[key].append(report)

        ident_ips: dict[tuple[str, str], dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
        ip_entries: dict[tuple[tuple[str, str], str], list[tuple[float, str]]] = defaultdict(list)
        ip_reporters_global: dict[str, set[str]] = defaultdict(set)
        sybil_identity: dict[str, str] = {}

        for key, rows in by_identifier.items():
            for row in rows:
                ip = row["ip_prefix"] or "unknown"
                ident_ips[key][ip].add(row["reporter_id"])
                ip_entries[(key, ip)].append((float(row["occurred_ts"]), row["reporter_id"]))
                ip_reporters_global[ip].add(row["reporter_id"])
            for ip, reporter_ids in ident_ips[key].items():
                if len(reporter_ids) >= 3:
                    for reporter_id in reporter_ids:
                        sybil_identity.setdefault(reporter_id, "ip:" + ip)

        def identity_of(reporter_id: str) -> str:
            return sybil_identity.get(reporter_id, "rid:" + reporter_id)

        identities: dict[tuple[str, str], set[str]] = {
            key: {identity_of(row["reporter_id"]) for row in rows}
            for key, rows in by_identifier.items()
        }

        reporter_identifiers: dict[str, set[tuple[str, str]]] = defaultdict(set)
        reporter_corroborated: dict[str, set[tuple[str, str]]] = defaultdict(set)
        reporter_flagged: dict[str, int] = defaultdict(int)

        for key, rows in by_identifier.items():
            verified = verified_entry(*key)
            challenged = key in challenged_keys
            corroborated = len(identities[key]) >= 3 and not verified
            for reporter_id in {row["reporter_id"] for row in rows}:
                reporter_identifiers[reporter_id].add(key)
                if corroborated:
                    reporter_corroborated[reporter_id].add(key)
            if verified:
                for row in rows:
                    reporter_flagged[row["reporter_id"]] += 1

        with self._lock:
            self._reports = reports
            self._by_identifier = dict(by_identifier)
            self._identities = identities
            self._reporter_identifiers = dict(reporter_identifiers)
            self._reporter_corroborated = dict(reporter_corroborated)
            self._reporter_flagged = dict(reporter_flagged)
            self._sybil_identity = sybil_identity
            self._ip_entries = dict(ip_entries)
            self._ip_reporters_global = dict(ip_reporters_global)
            self._challenged_keys = challenged_keys
            self._assessment_cache.clear()
            self._built = True

    # -- scoring helpers ---------------------------------------------------
    def _reporter_trust(self, reporter_id: str, current_key: tuple[str, str]) -> float:
        identifiers = self._reporter_identifiers.get(reporter_id, set()) - {current_key}
        corroborated = self._reporter_corroborated.get(reporter_id, set()) - {current_key}
        flagged = self._reporter_flagged.get(reporter_id, 0)
        if flagged >= 2:
            return 0.20
        if len(corroborated) >= 5 and len(identifiers) >= 3:
            return 1.00
        if len(corroborated) >= 2 and len(identifiers) >= 2:
            return 0.90
        if len(identifiers) >= 2:
            return 0.75
        if len(identifiers) == 1:
            return 0.65
        return 0.60

    def _ip_multiplier(self, report: dict[str, Any], key: tuple[str, str]) -> float:
        ip = report["ip_prefix"] or "unknown"
        rows = self._ip_entries.get((key, ip), [])
        ts = float(report["occurred_ts"])
        reporter_ids = {
            reporter_id
            for other_ts, reporter_id in rows
            if abs(other_ts - ts) <= 86400
        }
        if len(reporter_ids) >= 3:
            per_identifier = 0.35
        elif len(reporter_ids) == 2:
            per_identifier = 0.75
        else:
            per_identifier = 1.00

        global_reporters = len(self._ip_reporters_global.get(ip, set()))
        if global_reporters >= 8:
            global_multiplier = 0.50
        elif global_reporters >= 4:
            global_multiplier = 0.80
        else:
            global_multiplier = 1.00
        return min(per_identifier, global_multiplier)

    def _note_qualities(self, rows: list[dict[str, Any]]) -> tuple[list[float], list[bool]]:
        qualities: list[float] = []
        duplicates: list[bool] = []
        prior_hashes: set[str] = set()
        # Near-duplicate comparisons are bounded to the most recent 200 notes;
        # exact duplicates are still detected across the full identifier history.
        recent_tokens: deque[set[str]] = deque(maxlen=200)
        for row in rows:
            norm = row["note_norm"] or ""
            note_hash = row.get("note_hash") or ""
            duplicate = bool(norm and note_hash in prior_hashes)
            tokens = set(norm.split())
            if norm and not duplicate and len(tokens) >= 5:
                for prior_tokens in recent_tokens:
                    if len(prior_tokens) < 5:
                        continue
                    union = tokens | prior_tokens
                    if union and len(tokens & prior_tokens) / len(union) >= 0.82:
                        duplicate = True
                        break
            if norm:
                prior_hashes.add(note_hash)
                recent_tokens.append(tokens)
            qualities.append(_note_quality(norm, duplicate))
            duplicates.append(duplicate)
        return qualities, duplicates

    def _burst_multipliers(
        self,
        key: tuple[str, str],
        rows: list[dict[str, Any]],
        note_qualities: list[float],
        duplicates: list[bool],
    ) -> list[float]:
        if not rows:
            return []
        # Rows arrive sorted by occurred_ts from the database. A burst of
        # first-time reporters is a coordination signal even when attackers
        # vary their wording. It is down-weighted, never treated as proof of
        # fraud; genuine incident waves can still be reviewed independently.
        times = [float(row["occurred_ts"]) for row in rows]
        reporter_ids = [row["reporter_id"] for row in rows]

        def is_new(reporter_id: str) -> bool:
            return len(self._reporter_identifiers.get(reporter_id, set()) - {key}) == 0

        multipliers: list[float] = []
        # Prefix sums make each sliding-window statistic O(1), rather than
        # rescanning up to 24 hours of reports for every report.
        new_flags = [int(is_new(reporter_id)) for reporter_id in reporter_ids]
        def prefix(values):
            out = [0]
            for value in values:
                out.append(out[-1] + value)
            return out
        p_new = prefix(new_flags)
        p_dup = prefix([int(value) for value in duplicates])
        p_quality = prefix(note_qualities)
        start15 = start60 = start24 = 0
        for i, ts in enumerate(times):
            while times[start15] < ts - 900:
                start15 += 1
            while times[start60] < ts - 3600:
                start60 += 1
            while times[start24] < ts - 86400:
                start24 += 1

            count15 = i + 1 - start15
            count60 = i + 1 - start60
            count24 = i + 1 - start24
            new15 = (p_new[i + 1] - p_new[start15]) / max(1, count15)
            new60 = (p_new[i + 1] - p_new[start60]) / max(1, count60)
            new24 = (p_new[i + 1] - p_new[start24]) / max(1, count24)
            dup15 = (p_dup[i + 1] - p_dup[start15]) / max(1, count15)
            dup60 = (p_dup[i + 1] - p_dup[start60]) / max(1, count60)
            avg_q15 = (p_quality[i + 1] - p_quality[start15]) / max(1, count15)
            avg_q60 = (p_quality[i + 1] - p_quality[start60]) / max(1, count60)

            multiplier = 1.0
            # Very dense, mostly first-time reporting is strongly discounted.
            if count15 >= 8 and new15 >= 0.8:
                multiplier = min(multiplier, 0.35 if dup15 >= 0.3 or avg_q15 < 0.65 else 0.45)
            if count60 >= 15 and new60 >= 0.8:
                multiplier = min(multiplier, 0.35 if dup60 >= 0.4 or avg_q60 < 0.60 else 0.45)
            # A large same-day cohort is also suspicious as a coordination
            # pattern even if each participant rewrites the message.
            if count24 >= 20 and new24 >= 0.8:
                multiplier = min(multiplier, 0.45)
            multipliers.append(multiplier)
        return multipliers

    def _mass_multiplier(
        self,
        key: tuple[str, str],
        rows: list[dict[str, Any]],
        note_qualities: list[float],
        duplicates: list[bool],
    ) -> tuple[float, set[str]]:
        """A large cohort of brand-new accounts with scripted notes is one campaign."""
        if len(rows) < 10:
            return 1.0, set()
        reporter_ids = [row["reporter_id"] for row in rows]
        new_ids = {
            reporter_id
            for reporter_id in reporter_ids
            if len(self._reporter_identifiers.get(reporter_id, set()) - {key}) == 0
        }
        new_ratio = len(new_ids) / max(1, len(set(reporter_ids)))
        dup_ratio = sum(1 for d in duplicates if d) / max(1, len(duplicates))
        avg_q = sum(note_qualities) / max(1, len(note_qualities))
        if new_ratio >= 0.8 and (dup_ratio >= 0.4 or avg_q < 0.60):
            return 0.45, new_ids
        return 1.0, new_ids

    # -- public API --------------------------------------------------------
    def assess(self, identifier_type: str, identifier_value: str) -> Assessment:
        key = (identifier_type, identifier_value)
        with self._lock:
            cached = self._assessment_cache.get(key)
            if cached is not None:
                return cached
        self._ensure()
        with self._lock:
            cached = self._assessment_cache.get(key)
            if cached is not None:
                return cached
            rows = list(self._by_identifier.get(key, []))
            verified = verified_entry(identifier_type, identifier_value)
            challenged = key in self._challenged_keys

            note_qualities, duplicates = self._note_qualities(rows)
            burst_multipliers = self._burst_multipliers(key, rows, note_qualities, duplicates)
            mass_multiplier, new_ids = self._mass_multiplier(key, rows, note_qualities, duplicates)

            type_counts = Counter(row["scam_type"] for row in rows)
            channel_counts = Counter(row["channel"] for row in rows)
            top_type_raw = type_counts.most_common(1)[0][0] if type_counts else "other"
            top_channel = channel_counts.most_common(1)[0][0] if channel_counts else "Something else"

            scores: list[ReportScore] = []
            for index, row in enumerate(rows):
                reporter_trust = self._reporter_trust(row["reporter_id"], key)
                ip_multiplier = self._ip_multiplier(row, key)
                mass_for_report = mass_multiplier if row["reporter_id"] in new_ids else 1.0
                bonus = 0.0
                if row["scam_type"] == top_type_raw:
                    bonus += 0.03
                if row["channel"] == top_channel:
                    bonus += 0.02
                q = _clamp(
                    reporter_trust
                    * note_qualities[index]
                    * ip_multiplier
                    * burst_multipliers[index]
                    * mass_for_report
                    + bonus,
                    0.02,
                    1.0,
                )
                scores.append(
                    ReportScore(
                        report=row,
                        identity=self._sybil_identity.get(row["reporter_id"], "rid:" + row["reporter_id"]),
                        q=q,
                        reporter_trust=reporter_trust,
                        note_quality=note_qualities[index],
                        ip_multiplier=ip_multiplier,
                        burst_multiplier=burst_multipliers[index],
                        mass_multiplier=mass_for_report,
                        duplicate_note=duplicates[index],
                    )
                )

            identity_best: dict[str, float] = {}
            for score in scores:
                identity_best[score.identity] = max(identity_best.get(score.identity, 0.0), score.q)
            trusted = {identity: q for identity, q in identity_best.items() if q >= TRUSTED_Q}
            average_trust = (sum(trusted.values()) / len(trusted)) if trusted else 0.0

            # PRD-compatible public verdicts. A single/weak report is only
            # SUSPICIOUS; KNOWN_SCAM requires at least three distinct
            # reporter identities plus a credible trust signal. A disputed identifier is never
            # labelled KNOWN_SCAM while the business challenge is under review.
            if verified is not None:
                verdict = "VERIFIED_BUSINESS"
            elif not rows:
                verdict = "NO_REPORTS"
            elif challenged:
                verdict = "SUSPICIOUS"
            elif len(identity_best) >= 3 and len(trusted) >= 1 and average_trust >= 0.50:
                verdict = "KNOWN_SCAM"
            else:
                verdict = "SUSPICIOUS"

            distinct_reporters = len(identity_best)
            # Reveal a masked identifier only after three independently
            # scored, credible reporter identities (not merely three accounts).
            if verified is not None or len(trusted) >= 3:
                display_value = identifier_value
            else:
                display_value = mask_value(identifier_type, identifier_value)

            if rows:
                first_seen = rows[0]["occurred_at"]
                last_seen = rows[-1]["occurred_at"]
            else:
                first_seen = last_seen = None

            weighted_types: Counter[str] = Counter()
            for score in scores:
                if score.q >= TRUSTED_Q or not trusted:
                    weighted_types[score.report["scam_type"]] += score.q
            scam_type = weighted_types.most_common(1)[0][0] if weighted_types else "other"

            evidence = [
                {
                    "occurred_at": row["occurred_at"],
                    "channel": row["channel"],
                    "scam_type": row["scam_type"],
                    "pincode": row["pincode"],
                }
                for row in reversed(rows[-5:])
            ]

            assessment = Assessment(
                identifier_type=identifier_type,
                identifier_value=identifier_value,
                verdict=verdict,
                report_count=len(rows),
                distinct_reporters=distinct_reporters,
                trusted_reporters=len(trusted),
                average_trust=average_trust,
                first_seen=first_seen,
                last_seen=last_seen,
                scam_type=scam_type,
                display_value=display_value,
                challenged=challenged,
                verified=verified,
                evidence=evidence,
                scores=scores,
                score_by_report_id={score.report["report_id"]: score for score in scores},
            )
            self._assessment_cache[key] = assessment
            return assessment

    def scored_reports(self, since_ts: float | None = None) -> list[tuple[dict[str, Any], ReportScore]]:
        """Every report with its credibility, used by /map and /alerts."""
        self._ensure()
        result: list[tuple[dict[str, Any], ReportScore]] = []
        with self._lock:
            keys = list(self._by_identifier.keys())
        for key in keys:
            assessment = self.assess(*key)
            for row in self._by_identifier.get(key, []):
                if since_ts is not None and float(row["occurred_ts"]) < since_ts:
                    continue
                score = assessment.score_by_report_id.get(row["report_id"])
                if score is not None:
                    result.append((row, score))
        return result

    def credible_reports(self, since_ts: float | None = None) -> list[tuple[dict[str, Any], ReportScore]]:
        return [
            (row, score)
            for row, score in self.scored_reports(since_ts)
            if score.q >= CREDIBLE_Q
        ]
