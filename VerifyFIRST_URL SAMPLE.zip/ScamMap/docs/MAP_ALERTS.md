# Live map alerts

ScamMap now shows live alert cards directly over the map, plus a matching alert list in the map's right-hand column. The map uses a light pastel surface with vivid pink, orange, purple, yellow and green status accents.

## What appears

- **Highest activity:** the area with the most recent credible reports, shown when at least 3 independent reporter identities support the activity.
- **Sudden spike:** at least 5 credible reports in the current 7-day window, at least 3 independent reporter identities, and at least 3 times the previous 7-day report count.
- **New scam pattern:** a scam category not seen in the preceding 30 days, supported by at least 3 independent reporter identities in the current 7-day window.
- **Normal activity:** no pop-up is generated.

The thresholds are conservative prototype defaults. They can be tuned after testing with real, labelled data. An alert indicates unusual community reporting, not proof of criminal activity.

## Live refresh and map expiry

- While the map page is open, the browser refreshes `/map?days=7` and `/alerts` every 15 seconds.
- The map's active heat layer is limited to the latest 7 days. Reports older than 30 days are not used for active alerts either. The preceding 7 days and the rest of the 30-day history are only used as comparison context for spike and new-pattern detection.
- Clicking a floating alert or a right-column alert selects its area marker and refreshes the area detail card.
- Alert counts use credible reports and distinct internal reporter identities; reporter names and exact locations are never exposed.

## API

`GET /alerts` returns map-ready alert objects with `type`, `pincode`, `locality`, `city`, counts, comparison values and `generated_at`. Alert types are `HIGHEST_ACTIVITY`, `SPIKE`, and `NEW_TYPE`. If no area crosses the thresholds, the response contains an empty `alerts` array.

## Tests

Run from the `scam-map` directory:

```powershell
.\.venv\Scripts\python.exe -m pytest -q tests\test_security_controls.py
```

The tests cover highest activity/new scam alerts, normal-area suppression, and exclusion of old reports from the active map.
