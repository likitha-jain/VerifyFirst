from app.report_match_model import assess_report_match

def test_auxiliary_report_match_model_is_advisory():
    result = assess_report_match(
        "Your bank account will be blocked. Verify now.",
        "Your bank account will be blocked. Verify now.",
        "+91 01234 56789",
        "+91 01234 56789",
    )
    assert result["available"] is True
    assert result["assessment"] == "MATCH_CANDIDATE"
    assert result["advisory_only"] is True

def test_obvious_text_and_sender_mismatch_is_flagged_for_review():
    result = assess_report_match(
        "Your bank account will be blocked. Verify now.",
        "Your courier parcel is on hold. Pay a delivery fee.",
        "+91 01234 56789",
        "+91 09876 54321",
    )
    assert result["assessment"] == "MISMATCH_CANDIDATE"
    assert result["sender_conflict"] is True
    assert result["advisory_only"] is True
