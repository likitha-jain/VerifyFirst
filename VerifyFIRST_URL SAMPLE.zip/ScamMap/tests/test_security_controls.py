import json
from fastapi.testclient import TestClient

from app.main import Settings, create_app


def make_client(tmp_path):
    app = create_app(
        Settings(
            data_dir=tmp_path,
            license_file=tmp_path / "license.json",
            private_key_file=None,
            demo_mode=True,
        )
    )
    return TestClient(app)


def sample_report(reporter_id):
    return {
        "identifier_type": "phone",
        "identifier_value": "9876543210",
        "occurred_at": "2026-10-31T12:00:00+05:30",
        "reporter_id": reporter_id,
        "channel": "Phone call",
        "scam_type": "otp-call",
        "pincode": "560100",
        "note": "Bank caller requested OTP 123456 and asked me to call 9876543210.",
    }


def test_five_reports_per_anonymous_session_per_day(tmp_path):
    client = make_client(tmp_path)
    session = client.get("/report-session")
    assert session.status_code == 200
    assert session.json()["remaining"] == 5

    for index in range(5):
        response = client.post("/reports", json=sample_report(f"reporter-{index}"))
        assert response.status_code == 201
        assert response.json()["verification_status"] == "NOT_VERIFIED"
        assert response.json()["reports_remaining_today"] == 4 - index

    blocked = client.post("/reports", json=sample_report("reporter-six"))
    assert blocked.status_code == 429
    assert blocked.json()["error"] == "DAILY_SESSION_LIMIT"


def test_report_receipt_redacts_otp_and_phone(tmp_path):
    client = make_client(tmp_path)
    client.get("/report-session")
    response = client.post("/reports", json=sample_report("reporter-redaction"))
    assert response.status_code == 201
    summary = response.json()["report_summary"]
    assert "OTP [redacted]" in summary
    assert "[phone number]" in summary
    assert "123456" not in summary
    assert "9876543210" not in summary


def test_community_reports_never_create_public_suspicious_verdict(tmp_path):
    client = make_client(tmp_path)
    client.get("/report-session")
    client.post("/reports", json=sample_report("reporter-one"))
    lookup = client.get("/lookup", params={"value": "9876543210", "type": "phone"})
    assert lookup.status_code == 200
    assert lookup.json()["verdict"] == "SUSPICIOUS"


def test_coordinated_first_time_reporter_burst_is_downweighted():
    from app.trust import TrustEngine

    class EmptyDatabase:
        pass

    engine = TrustEngine(EmptyDatabase())
    start = 1_800_000_000
    rows = [
        {"occurred_ts": start + index * 20, "reporter_id": f"new-reporter-{index}"}
        for index in range(40)
    ]
    # Each report has detailed, distinct wording, so this tests burst detection
    # rather than copy-paste detection.
    scores = engine._burst_multipliers(
        ("phone", "9876543210"),
        rows,
        [0.95] * len(rows),
        [False] * len(rows),
    )
    assert min(scores) <= 0.45


def test_map_alerts_surface_highest_activity_and_new_scam_pattern(tmp_path):
    from datetime import datetime, timezone

    app = create_app(
        Settings(data_dir=tmp_path, license_file=tmp_path / "license.json", private_key_file=None, demo_mode=True)
    )
    for index in range(3):
        client = TestClient(app)
        client.get("/report-session")
        payload = sample_report(f"independent-{index}")
        payload["identifier_value"] = f"98765432{index:02d}"
        payload["occurred_at"] = datetime.now(timezone.utc).isoformat()
        response = client.post("/reports", json=payload)
        assert response.status_code == 201

    alerts = TestClient(app).get("/alerts").json()["alerts"]
    assert alerts[0]["type"] == "HIGHEST_ACTIVITY"
    assert alerts[0]["locality"] == "Electronic City"
    assert any(item["type"] == "NEW_TYPE" and item["scam_type"] == "otp-call" for item in alerts)


def test_normal_area_does_not_generate_live_alert(tmp_path):
    from datetime import datetime, timezone

    app = create_app(
        Settings(data_dir=tmp_path, license_file=tmp_path / "license.json", private_key_file=None, demo_mode=True)
    )
    client = TestClient(app)
    client.get("/report-session")
    payload = sample_report("one-normal-report")
    payload["occurred_at"] = datetime.now(timezone.utc).isoformat()
    assert client.post("/reports", json=payload).status_code == 201
    assert TestClient(app).get("/alerts").json()["alerts"] == []


def test_reports_older_than_30_days_are_not_on_live_map(tmp_path):
    from datetime import datetime, timedelta, timezone

    app = create_app(
        Settings(data_dir=tmp_path, license_file=tmp_path / "license.json", private_key_file=None, demo_mode=True)
    )
    client = TestClient(app)
    client.get("/report-session")
    payload = sample_report("old-report")
    payload["occurred_at"] = (datetime.now(timezone.utc) - timedelta(days=35)).isoformat()
    assert client.post("/reports", json=payload).status_code == 201
    assert TestClient(app).get("/map?days=7").json()["clusters"] == []
    assert TestClient(app).get("/alerts").json()["alerts"] == []


def test_admin_endpoints_require_token(tmp_path):
    app = create_app(Settings(data_dir=tmp_path, license_file=tmp_path / "license.json", private_key_file=None, demo_mode=True, admin_token="strong-test-token"))
    client = TestClient(app)
    assert client.post("/admin/reset").status_code == 401
    assert client.get("/admin/challenges").status_code == 401
    assert client.post("/admin/reset", headers={"X-Admin-Token": "wrong"}).status_code == 401
    assert client.get("/admin/challenges", headers={"X-Admin-Token": "strong-test-token"}).status_code == 200

def test_cors_rejects_unlisted_origin(tmp_path):
    app = create_app(Settings(data_dir=tmp_path, license_file=tmp_path / "license.json", private_key_file=None, demo_mode=True, cors_origins=("https://scammap.example",)))
    client = TestClient(app)
    response = client.options("/reports", headers={"Origin": "https://evil.example", "Access-Control-Request-Method": "POST"})
    assert response.headers.get("access-control-allow-origin") != "https://evil.example"

def test_sms_report_extracts_identifiers_and_supports_similar_lookup(tmp_path):
    from datetime import datetime, timezone
    client = make_client(tmp_path)
    client.get("/report-session")
    sms = "Your bank KYC is blocked. Visit https://secure-kyc-example.com/verify and call 9876543210. Reply urgently."
    payload = sample_report("ignored")
    payload.pop("identifier_type")
    payload.pop("identifier_value")
    payload["message_text"] = sms
    payload["occurred_at"] = datetime.now(timezone.utc).isoformat()
    response = client.post("/reports", json=payload)
    assert response.status_code == 201, response.text
    analysis = response.json()["sms_analysis"]
    assert analysis["submitted"] is True
    assert any(item["type"] == "url" for item in analysis["extracted_identifiers"])
    lookup = client.get("/lookup", params={"message": "Your bank KYC is blocked. Visit https://secure-kyc-example.com/verify and call 9876543210. Reply urgently."})
    assert lookup.status_code == 200
    assert lookup.json()["similar_messages"] == 0  # no screenshot evidence means not publicly verified



def test_url_lookup_includes_optional_virustotal_status_when_not_configured(tmp_path):
    client = make_client(tmp_path)
    response = client.get("/lookup", params={"value": "https://example.com", "type": "url"})
    assert response.status_code == 200
    payload = response.json()
    assert payload["identifier_type"] == "url"
    assert payload["url_intelligence"]["provider"] == "VirusTotal"
    assert payload["url_intelligence"]["status"] == "not_configured"
    # External intelligence is supplemental and must not alter the community verdict.
    assert payload["verdict"] == "NO_REPORTS"


def _sms_screenshot(sender_number: str, body_lines: list[str]) -> bytes:
    from io import BytesIO
    from PIL import Image, ImageDraw, ImageFont

    image = Image.new("RGB", (1000, 1200), "white")
    draw = ImageDraw.Draw(image)
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", 26)
    except OSError:
        font = ImageFont.load_default()
    draw.text((30, 35), f"SMS from {sender_number}", fill="black", font=font)
    for index, line in enumerate(body_lines):
        draw.text((30, 320 + index * 55), line, fill="black", font=font)
    output = BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()


def test_sms_screenshot_sender_mismatch_is_excluded_from_number_lookup(tmp_path):
    from datetime import datetime, timezone

    client = make_client(tmp_path)
    client.get("/report-session")
    sms = "Your bank KYC is blocked. Visit https://secure-kyc-example.com/verify and call 9876543210. Reply urgently."
    payload = sample_report("ignored")
    payload["identifier_type"] = "phone"
    payload["identifier_value"] = "9876543210"
    payload["message_text"] = sms
    payload["occurred_at"] = datetime.now(timezone.utc).isoformat()
    report = client.post("/reports", json=payload)
    assert report.status_code == 201, report.text

    screenshot = _sms_screenshot(
        "9123456789",
        [
            "Your bank KYC is blocked.",
            "Visit https://secure-kyc-example.com/verify",
            "and call 9876543210. Reply urgently.",
        ],
    )
    uploaded = client.post(
        f"/sms/evidence/{report.json()['report_id']}",
        content=screenshot,
        headers={"Content-Type": "image/png"},
    )
    assert uploaded.status_code == 200, uploaded.text
    assert uploaded.json()["evidence_status"] == "MISMATCHED"

    lookup = client.get("/lookup", params={"value": "9876543210", "type": "phone"})
    assert lookup.status_code == 200
    assert lookup.json()["verdict"] == "NO_REPORTS"
    assert lookup.json()["report_count"] == 0
    assert lookup.json()["evidence_filtered"] is True


def test_sms_screenshot_matching_text_and_sender_counts_as_evidence(tmp_path):
    from datetime import datetime, timezone

    client = make_client(tmp_path)
    client.get("/report-session")
    sms = "Your bank KYC is blocked. Visit https://secure-kyc-example.com/verify and call 9876543210. Reply urgently."
    payload = sample_report("ignored")
    payload["identifier_type"] = "phone"
    payload["identifier_value"] = "9876543210"
    payload["message_text"] = sms
    payload["occurred_at"] = datetime.now(timezone.utc).isoformat()
    report = client.post("/reports", json=payload)
    assert report.status_code == 201, report.text

    screenshot = _sms_screenshot(
        "9876543210",
        [
            "Your bank KYC is blocked.",
            "Visit https://secure-kyc-example.com/verify",
            "and call 9876543210. Reply urgently.",
        ],
    )
    uploaded = client.post(
        f"/sms/evidence/{report.json()['report_id']}",
        content=screenshot,
        headers={"Content-Type": "image/png"},
    )
    assert uploaded.status_code == 200, uploaded.text
    assert uploaded.json()["evidence_status"] == "MATCHED"

    lookup = client.get("/lookup", params={"value": "9876543210", "type": "phone"})
    assert lookup.status_code == 200
    assert lookup.json()["verdict"] == "SUSPICIOUS"
    assert lookup.json()["report_count"] == 1

    # SMS similarity results require accepted screenshot evidence and must not
    # disclose the reported phone number in the public response.
    sms_lookup = client.get("/lookup", params={"message": sms})
    assert sms_lookup.status_code == 200
    assert sms_lookup.json()["similar_messages"] == 1
    assert "9876543210" not in json.dumps(sms_lookup.json())


def test_rate_limiter_supports_endpoint_limits_and_prunes(tmp_path):
    from app.main import RateLimiter

    limiter = RateLimiter(reporter_limit=30, ip_limit=120, window_seconds=600)
    assert limiter.allow_key("lookup:127.0.0.1", 2, 60) is True
    assert limiter.allow_key("lookup:127.0.0.1", 2, 60) is True
    assert limiter.allow_key("lookup:127.0.0.1", 2, 60) is False
    assert limiter.allow_key("evidence:127.0.0.1", 1, 600) is True


def test_json_endpoint_rejects_oversized_body(tmp_path):
    client = make_client(tmp_path)
    response = client.post(
        "/challenges",
        content=b'{"claimant_name":"' + (b"x" * (65 * 1024)) + b'"}',
        headers={"Content-Type": "application/json"},
    )
    assert response.status_code == 400
    assert "64 KB" in response.json()["error"]


def test_coordinated_sms_burst_quarantines_reports_instead_of_counting_volume(tmp_path):
    import json
    import time
    from app.db import Database

    db = Database(tmp_path / "burst.db")
    now = time.time()
    text_hash = "same-normalized-sms-fingerprint"
    perceptual_hashes = [
        "0000000000000000",
        "ffffffffffffffff",
        "aaaaaaaaaaaaaaaa",
        "5555555555555555",
        "3333333333333333",
    ]
    report_ids = []

    for index in range(5):
        report_id = f"report_{index}"
        report_ids.append(report_id)
        conn = db.connect()
        try:
            with conn:
                conn.execute(
                    "INSERT INTO reports (report_id, case_id, occurred_at, occurred_ts, reported_at, "
                    "reporter_id, ip_prefix, channel, scam_type, identifier_type, identifier_value, "
                    "pincode, locality, city, created_ts) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (report_id, "case_same", "2026-11-01", now, "2026-11-01", f"anon:session_{index}",
                     "127.0.0.0/24", "sms", "phishing", "phone", "9000012345",
                     "560001", "Test Area", "Bengaluru", now),
                )
                conn.execute(
                    "INSERT INTO sms_messages (report_id, case_id, message_text, normalized_text, text_hash, extracted_identifiers, created_ts) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (report_id, "case_same", "Fake bank alert", "fake bank alert", text_hash, "[]", now),
                )
        finally:
            conn.close()

        db.insert_sms_evidence({
            "evidence_id": f"evidence_{index}",
            "report_id": report_id,
            "image_hash": f"sha256_{index}",
            "file_name": f"{index}.png",
            "image_format": "PNG",
            "image_size": 1024,
            "image_width": 500,
            "image_height": 700,
            "metadata_json": json.dumps({"perceptual_hash": perceptual_hashes[index]}),
            "ocr_text": "Fake bank alert",
            "status": "MATCHED",
            "reason": "TEXT_AND_SENDER_MATCH",
            "created_ts": now + index,
        })

    conn = db.connect()
    try:
        statuses = [row["status"] for row in conn.execute(
            "SELECT status FROM sms_evidence ORDER BY report_id"
        ).fetchall()]
        reasons = [row["reason"] for row in conn.execute(
            "SELECT reason FROM sms_evidence ORDER BY report_id"
        ).fetchall()]
    finally:
        conn.close()

    assert statuses == ["INCONCLUSIVE"] * 5
    assert reasons == ["COORDINATED_BURST_REVIEW"] * 5


def test_nearest_area_uses_builtin_area_data_and_returns_locality_only(tmp_path):
    client = make_client(tmp_path)
    response = client.post("/areas/nearest", json={"latitude": 12.9116, "longitude": 77.6473})
    assert response.status_code == 200
    payload = response.json()
    assert payload["area"]["locality"] == "HSR Layout"
    assert payload["area"]["city"] == "Bengaluru"
    assert payload["precision"] == "area"
    assert "latitude" not in payload and "longitude" not in payload


def test_nearest_area_rejects_invalid_and_out_of_coverage_coordinates(tmp_path):
    client = make_client(tmp_path)
    invalid = client.post("/areas/nearest", json={"latitude": 120, "longitude": 77})
    assert invalid.status_code == 400
    outside = client.post("/areas/nearest", json={"latitude": 51.5074, "longitude": -0.1278})
    assert outside.status_code == 404


def test_judge_compat_accepts_simulated_reporter_identity_without_cookie(tmp_path):
    app = create_app(Settings(
        data_dir=tmp_path,
        license_file=tmp_path / "license.json",
        private_key_file=None,
        demo_mode=True,
        judge_api_compat=True,
    ))
    client = TestClient(app)
    payload = sample_report("judge-reporter-001")
    payload["ip_prefix"] = "103.21.58"
    payload["report_id"] = "rep_judge_001"
    response = client.post("/reports", json=payload)
    assert response.status_code == 201, response.text
    lookup = client.get("/lookup", params={"type": "phone", "value": "9876543210"})
    assert lookup.status_code == 200
    assert lookup.json()["verdict"] in {"SUSPICIOUS", "KNOWN_SCAM"}


def test_judge_compat_reset_works_without_admin_token(tmp_path):
    app = create_app(Settings(
        data_dir=tmp_path,
        license_file=tmp_path / "license.json",
        private_key_file=None,
        demo_mode=True,
        judge_api_compat=True,
    ))
    client = TestClient(app)
    payload = sample_report("judge-reporter-reset")
    payload["ip_prefix"] = "103.21.59"
    payload["report_id"] = "rep_judge_reset"
    assert client.post("/reports", json=payload).status_code == 201
    reset = client.post("/admin/reset")
    assert reset.status_code == 200, reset.text
    assert reset.json()["ok"] is True
    assert client.get("/lookup", params={"type": "phone", "value": "9876543210"}).json()["verdict"] == "NO_REPORTS"


def test_lookup_uses_exact_prd_verdict_values(tmp_path):
    client = make_client(tmp_path)
    assert client.get("/lookup", params={"type": "phone", "value": "9876543210"}).json()["verdict"] == "NO_REPORTS"
    client.get("/report-session")
    payload = sample_report("one-reporter")
    assert client.post("/reports", json=payload).status_code == 201
    assert client.get("/lookup", params={"type": "phone", "value": "9876543210"}).json()["verdict"] == "SUSPICIOUS"


def test_judge_compat_many_independent_reporters_can_reach_known_scam(tmp_path):
    from datetime import datetime, timedelta, timezone

    app = create_app(Settings(
        data_dir=tmp_path,
        license_file=tmp_path / "license.json",
        private_key_file=None,
        demo_mode=True,
        judge_api_compat=True,
    ))
    client = TestClient(app)
    base = datetime.now(timezone.utc) - timedelta(hours=4)
    for index in range(5):
        payload = sample_report(f"judge-reporter-{index}")
        payload.update({
            "ip_prefix": f"103.21.{50 + index}",
            "report_id": f"rep_judge_independent_{index}",
            "occurred_at": (base + timedelta(minutes=index * 30)).isoformat(),
            "note": f"I received a suspicious bank OTP call asking for confidential account verification, incident reference {index}.",
        })
        response = client.post("/reports", json=payload)
        assert response.status_code == 201, response.text
    lookup = client.get("/lookup", params={"type": "phone", "value": "9876543210"})
    assert lookup.json()["verdict"] == "KNOWN_SCAM", lookup.json()
