# ScamMap – Sample URLs for Testing

This file documents URL examples already present in the supplied ScamMap prototype's seed data and synthetic messaging/report-match datasets.

> **Safety and accuracy:** These are test fixtures, not a verified threat feed. Their inclusion in ScamMap does not prove that a real website is malicious. The `.example` and `.test` domains are reserved for documentation/testing and are not live scam websites. The `.in` URLs below are seed-data examples only and have not been independently verified.

## 1. Seed URLs (`app/seed.py`)

| URL | Seed scenario |
|---|---|
| `http://www.sbi-kyc-verify.in/update?utm=sms` | Fake KYC link scenario |
| `https://profit-invest-group.example/app` | Investment-group scenario |
| `https://bandra-invest.example/join` | Investment-group scenario |
| `https://jaipur-kyc.example/verify` | Fake KYC link scenario |
| `https://sbi-kyc-secure.in/verify` | Fake KYC link scenario |

## 2. Synthetic messaging dataset URLs (`data/ml/ScamMap_Messaging_Test_Dataset_50.csv`)

| URL | Synthetic message scenario |
|---|---|
| `http://bank-kyc-update.example/verify` | Bank/KYC impersonation |
| `http://parcel-fee.example/pay` | Delivery/customs fee |
| `http://power-bill.example/settle` | Utility-payment impersonation |
| `http://fastag-check.example/kyc` | FASTag impersonation |
| `http://sim-care.example/verify` | SIM/Aadhaar phishing |
| `http://delivery-fix.example/address` | Delivery-link phishing |
| `http://rewards-claim.example` | Card-data/reward phishing |
| `http://secure-account.example/unlock` | Credential phishing |

## 3. Synthetic report-match dataset URLs (`data/ml/report_match_dataset/manifest.csv`)

| URL | Synthetic report scenario |
|---|---|
| `http://bank-kyc-example.test` | Repeated KYC-warning message cluster |
| `http://parcel-example.test/update` | Repeated courier-fee message cluster |

## 4. Safe reference URLs

| URL | Purpose |
|---|---|
| `https://www.google.com` | General safe-site comparison (live external service) |
| `https://example.com` | Reserved example domain |

## 5. How to test

1. Run the ScamMap application locally.
2. Open the URL lookup feature.
3. Paste one URL at a time and submit it.
4. Record the returned classification and any available threat-intelligence result.
5. If VirusTotal is configured, remember that external lookups may send the submitted URL to VirusTotal under its service terms.

Do not visit suspicious-looking URLs just to test them. Use the reserved `.example` and `.test` samples for safe demonstrations. Treat VirusTotal and community reports as intelligence signals, not definitive proof.
